/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80016
 Source Host           : localhost:3306
 Source Schema         : myblogs_bak

 Target Server Type    : MySQL
 Target Server Version : 80016
 File Encoding         : 65001

 Date: 12/11/2020 17:12:05
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for __efmigrationshistory
-- ----------------------------
DROP TABLE IF EXISTS `__efmigrationshistory`;
CREATE TABLE `__efmigrationshistory`  (
  `MigrationId` varchar(95) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ProductVersion` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`MigrationId`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of __efmigrationshistory
-- ----------------------------
INSERT INTO `__efmigrationshistory` VALUES ('20190321050816_Init', '2.2.3-servicing-35854');

-- ----------------------------
-- Table structure for advertisement
-- ----------------------------
DROP TABLE IF EXISTS `advertisement`;
CREATE TABLE `advertisement`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ImageUrl` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `ThumbImgUrl` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `Weight` int(11) NOT NULL DEFAULT 1,
  `Price` decimal(10, 2) NOT NULL DEFAULT 0.00,
  `Types` varchar(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `ViewCount` int(11) NOT NULL DEFAULT 0,
  `CategoryIds` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `CreateTime` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
  `UpdateTime` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
  `Status` int(11) NOT NULL DEFAULT 1,
  `DisplayCount` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 46 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of advertisement
-- ----------------------------
INSERT INTO `advertisement` VALUES (2, 'Mac 清理优化工具 MacBooster 限时特惠终生版6折最低仅需54元', '在过去，提到 Mac 清理，CleanMyMac 基本是首选。不过该系列的价格逐年攀升，使得同样功能全面、高性价比的 MacBooster 7 更容易得人心。活动期间，MacBooster 终身全系列 6 折，单设备授权仅售 54 元 —— 不到 CleanMyMac 的四分之一。', 'https://partner.lizhi.io/ldqk/macbooster', 'https://partner-cdn.lizhi.io/api/www//uploads/[pt]macbooster_40off_600x3002x.png', 'https://git.imweb.io/ldqk0/imgbed/raw/master/2020/01/09/sdruczu3m29t.png', 1, 300.00, '2,3,4', 180, '15,42,35,45,43,2', '2019-10-24 21:49:48', '2020-03-02 21:38:49', 1, 0);
INSERT INTO `advertisement` VALUES (3, '下载利器-Internet Download Manager 原价169元，优惠94元终身授权/49元一年授权', 'IDM下载器是国内外优秀下载工具，支持IE, Firefox, Chrome等所有浏览器，兼容所有Windows平台。最具特色功能如续传功能，支持恢复因为断线、网络问题、计算机宕机等故障导致中断的下载任务。Internet Download Manager的续传功能可以恢复因为断线、网络问题、计算机当机甚至无预警的停电导致下传到一半的软件。', 'https://partner.lizhi.io/ldqk/idm', 'https://git.imweb.io/ldqk/imgbed/raw/master/2018/2/5ccbdd95a5103.jpg', 'https://git.imweb.io/ldqk/imgbed/raw/master/2019/10/28/s6k4zyx8i70h.jpg', 1, 300.00, '1,2,3,4', 1910, '2,43,45,18,35,42,15', '2019-10-24 21:49:48', '2020-03-02 21:39:13', 1, 0);
INSERT INTO `advertisement` VALUES (4, '94元买正版 Mac 顶级应用 PDF Expert', 'PDF Expert 是 macOS 上一款知名的 PDF 编辑工具。它集阅读、创建、编辑批注等功能于一身，但仍轻巧易用，美观的设计与 macOS 本身相得益彰，一经发布便获得众多好评，多次被 Apple 编辑推荐。\nPDF Expert 的国内日常售价为 169 元。即日起，领取专属优惠券，最终价格仅需94 元。', 'https://partner.lizhi.io/ldqk/pdf_expert_for_mac', 'https://git.imweb.io/ldqk/imgbed/raw/master/5cdab76b1080e39714.png', 'https://git.imweb.io/ldqk0/imgbed/raw/master/2020/01/09/sdrums0u89hd.png', 1, 300.00, '1', 641, '15,43,45,18,35', '2019-10-24 21:49:48', '2020-03-02 21:39:36', 1, 0);
INSERT INTO `advertisement` VALUES (5, '去广告神器——AdGuard Premium，十周年促销低至67元', 'AdGuard 已是广告拦截领域的当红专家，能在电脑端与移动端 (iOS 与 Android) 提供超高质量的广告净化能力，同时操作简单。现逢 10 周年优惠，最低 72 元，领券还可优惠。', 'https://partner.lizhi.io/ldqk/adguard', 'https://git.imweb.io/ldqk/imgbed/raw/master/20190621/6369670327565747794529766.jpg', 'https://gd1.alicdn.com/imgextra/i4/2/O1CN01zpz2mC20IM7skBPkq_!!2-item_pic.png', 1, 300.00, '1,2,3,4', 1917, '43,45,18,35,42,15', '2019-10-24 21:49:48', '2020-03-02 21:39:55', 1, 0);
INSERT INTO `advertisement` VALUES (8, '博主正式开始对外承接DIY电竞显示器业务，27/32寸显示器，2k/4k/165Hz/IPS/gsync', '博主正式开始承接2k电竞显示器diy定制业务，对标四大金刚，价格2000人民币左右，感兴趣的私我。 \n自主生产的超高性价比的diy显示器，对标大金刚，小金刚等，一半的价格，完美的体验，M270KCJ-K7B，M270DAN02.6，LM315WR1-SSB1，M270QAN02.2，LM340UW5-SSA1，M350QVR01.1。', '/1582', 'https://gd1.alicdn.com/imgextra/i1/82940726/TB2JcI.gpuWBuNjSspnXXX1NVXa_!!82940726.jpg_400x400.jpg', 'https://gd1.alicdn.com/imgextra/i1/82940726/TB2JcI.gpuWBuNjSspnXXX1NVXa_!!82940726.jpg_400x400.jpg', 9, 1000.00, '2,3,4', 1391, NULL, '0001-01-01 00:00:00', '2020-01-04 19:59:57', 1, 0);
INSERT INTO `advertisement` VALUES (9, 'NTFS for Mac 助手，高性价比 Mac 读写 NTFS 移动硬盘工具', 'NTFS for Mac 助手（下文简称 NTFS 助手）专注于补齐 Mac 读写常见硬盘的能力，软件简单易用，售价十分亲民。适合日常使用的家庭版连同类产品的零头都不到，只需 36 元就可以让 Mac 电脑轻松读写常见的 NTFS 移动硬盘。用于商业用途、读写速度更快的专业版也只需 66 元。', 'https://partner.lizhi.io/ldqk/aibotech_ntfs_for_mac', 'https://git.imweb.io/ldqk0/imgbed/raw/master/2020/01/09/sdruhnm0ldkx.png', 'https://git.imweb.io/ldqk/imgbed/raw/master/20191024/6370755430985800006032459.png', 1, 300.00, '2,3,4', 532, '43,45,18,35,42,15', '0001-01-01 00:00:00', '2020-03-02 21:40:10', 1, 0);
INSERT INTO `advertisement` VALUES (11, '墙裂，秒开YouTube 4k，支持Netflix，超高性价比稳定v2ray加速服务', '超高性价比稳定v2ray加速服务，国内优化中转，Google Facebook Instagram等秒开无卡顿，YouTube 4K视频无压力，Netflix/TVB/Hulu/HBO 等流媒体访问解锁', 'https://go.qianglie.cc/aff.php?aff=597', 'https://git.imweb.io/ldqk/imgbed/raw/master/20191024/6370755480531100006264023.png', 'https://git.imweb.io/ldqk0/imgbed/raw/master/2020/02/02/sg69lrtm6j29.jpg', 1, 1300.00, '2,3,4', 4364, NULL, '0001-01-01 00:00:00', '2020-02-19 09:53:22', 1, 0);
INSERT INTO `advertisement` VALUES (18, '3300元起，享受27寸4k 144Hz IPS 世界顶配液晶显示器', '目前世界顶级配置的27寸4k 144Hz IPS 友达M270QAN02.2面板，对标型号：pg27uq、x27、xv273k电竞+设计显示器，豪华配置，至尊体验！', '/1662', NULL, 'https://gd2.alicdn.com/imgextra/i3/0/O1CN01p3P8ya1fr4D3gV0GG_!!0-item_pic.jpg', 1, 1000.00, '2,3,4', 1748, NULL, '2019-11-06 23:11:03', '2020-02-26 19:50:22', 1, 0);
INSERT INTO `advertisement` VALUES (21, '搬瓦工VPS - 一款性价比较高的便宜VPS主机', '搬瓦工，因其官网网站标识是BandwagonHost，有点类似BanWaGong的拼写，所以我们国内的站长喜欢称作为搬瓦工VPS。搬瓦工VPS是一款性价比较高的便宜VPS主机，且适合入门级网友学习Linux和建站用途。', 'https://bandwagonhost.com/aff.php?aff=54564', NULL, 'https://git.imweb.io/ldqk/imgbed/raw/master/2019/11/11/s7wyttej00zl.png', 1, 77.00, '2,3,4', 480, '8,31', '2019-11-11 15:37:49', '2020-03-02 21:43:11', 14, 0);
INSERT INTO `advertisement` VALUES (23, '正版Windows10大额优惠来袭！150元优惠码：maswin10', 'Windows 10 的设计旨在为您提供跨越不同设备的无缝体验。速度快而灵敏。您甚至可以与支持人员免费在线聊天或获得实时电话支持。\n使用优惠券，还能再减150元，优惠码：maswin10', 'https://apsgo.com/store/product/windows-10', 'https://git.imweb.io/ldqk/imgbed/raw/master/20191223/sc2gixqjf7r4.png', 'https://git.imweb.io/ldqk/imgbed/raw/master/2019/11/18/s8murx0ynls1.png', 1, 150.00, '1,2,3,4', 1376, '2,43,45,18,35,42,15', '2019-11-18 21:47:46', '2020-03-02 21:42:15', 1, 0);
INSERT INTO `advertisement` VALUES (25, 'Wise Care 365 Pro 系统优化清理软件 -1PC终身版仅需 99 元！优惠码：ldqkWise30', '清理注册表和磁盘垃圾文件，保护个人隐私记录，提高电脑使用安全。优化系统、提高Windows系统运行速度最好的选择！提高 Windows 电脑速度的安全、稳定的解决方案 -让你的电脑时刻保持巅峰状态。软购商城1PC终身版仅需 99 元！优惠码：ldqkWise30', '/1671', 'https://git.imweb.io/si/imgbed/raw/master/2020/01/15/secwk8xueqkh.png', 'https://apsgo.com/wp-content/uploads/2019/08/APSGO-wise_care_365_logo.png', 1, 150.00, '1,2,3,4', 793, '43,45,18,35,42,15', '2019-12-04 11:32:45', '2020-03-02 21:42:29', 1, 0);
INSERT INTO `advertisement` VALUES (26, '官方正版绑定账户 AdGuard 广告拦截隐私保护软件 -3设备授权', 'AdGuard 广告拦截隐私保护软件 -3设备授权 由本站和 APSGO 软购商城推荐的官方正版特价！终身版！一次购买终身使用！', '/1687', 'https://git.imweb.io/ldqk/imgbed/raw/master/20191203/sa3sv1ikl6gw.gif', 'https://git.imweb.io/ldqk/imgbed/raw/master/20191203/sa3sv1ikl6gw.gif', 1, 150.00, '2,3,4', 330, '43,45,18,35,15,42', '2019-12-18 10:32:04', '2020-03-02 21:42:45', 1, 0);
INSERT INTO `advertisement` VALUES (29, '1700元即可享有四大金刚同等配置的电竞显示器，M270KCJ-K7B', '新款支持2k@165Hz+10bit+HDR+freesync/gsync同时开启，满血的gsync！同时解决上一代发热严重的问题，功耗更低，更加节能！DIY界率先突破技术障碍！超越四大金刚！', '/1635', 'https://gitee.com/masuit_admin/images/raw/master/2020/01/01/6371349603260156253056514.jpg', 'https://gd1.alicdn.com/imgextra/i1/82940726/TB2JcI.gpuWBuNjSspnXXX1NVXa_!!82940726.jpg_400x400.jpg', 1, 1000.00, '2,3,4', 695, NULL, '2020-01-01 17:27:55', '2020-02-26 19:50:35', 1, 0);
INSERT INTO `advertisement` VALUES (30, '类似MathType的数学公式编辑器AxMath，正版仅需30元', '数学公式编辑器 AxMath 也是一款比较不错的公式编辑器，AxMath 是一款专业的公式编辑器及科学计算软件，集公式编辑、排版及科学计算于一身 。可完美取代同类软件 MathType，具有 MathType 所有功能，并在此基础上略有不同。领劵下单正版仅需一顿午饭钱！', 'https://partner.lizhi.io/ldqk/axmath', 'null', 'https://git.imweb.io/ldqk/imgbed/raw/master/20191213/sb2xe15ra6tc.gif', 1, 300.00, '2,3,4', 274, '43,45,18,35,42,15', '2020-01-07 21:57:21', '2020-03-02 21:40:28', 1, 0);
INSERT INTO `advertisement` VALUES (33, '跳槽必备——.NET Core微服务架构最佳实践视频教程', '.NET Core云原生微服务架构的开发，不仅涉及到.NET Core重要组件的知识，还涉及到DDD、远程调用RPC、熔断限流、网关、身份认证、安全等微服务架构的各个方面，同时也要求技术人员对 DevOps 协作模式有一定的掌握。', 'https://time.geekbang.org/course/intro/272?code=MHK3LHxWvGL4ePqkSw1hPOpc7vXikQsuhaplMQBPaX8%3D', 'https://git.imweb.io/guomo/imgbed/raw/master/2020/01/13/se69eyy49xxc.jpg', 'https://git.imweb.io/guomo/imgbed/raw/master/2020/01/13/se69eyy49xxc.jpg', 1, 360.00, '2,3,4', 213, '34,7,41,6,28,38', '2020-01-13 19:01:49', '2020-03-02 21:37:18', 1, 0);
INSERT INTO `advertisement` VALUES (35, 'web前端全链路性能优化实战视频教程', '对于一个网站来说，保持用户访问的活跃度是至关重要的，页面加载是否够快，操作响应是否及时，直接影响着用户的体验感。通过各种优化策略和优化方法，提高前端代码执行效率，便是前端性能优化的本质。不过，它并不只是前端的事情，这是一个需要在全链路上进行研究和解决的难题。', 'https://time.geekbang.org/course/intro/100041001?code=fQ1pXX0JK2yeNQnNmLczWRQNMjGobC2mnU0n0w8m%2FEQ%3D', 'null', 'https://static001.geekbang.org/misc/posters/1291721/87997aa66ddfc6b5807aedbc171fc448.jpg', 1, 360.00, '2,3,4', 169, '32,6,28', '2020-01-19 21:34:45', '2020-03-02 21:37:43', 1, 0);
INSERT INTO `advertisement` VALUES (36, '买正版软件，上数码荔枝！', '数码荔枝专注于分享最新鲜优质的正版软件，更加合理实惠的价格和更优质的服务，领取和本站联合的专属优惠券，立减5元。', 'https://partner.lizhi.io/ldqk/cp', 'https://git.imweb.io/ldqk/imgbed/raw/master/2020/02/11/sh0tck434mwx.png', 'https://git.imweb.io/si/imgbed/raw/master/2020/02/11/sh0smjl8m8e9.png', 1, 300.00, '1,2,3,4', 842, NULL, '2020-01-25 09:56:44', '2020-02-19 09:52:46', 1, 0);
INSERT INTO `advertisement` VALUES (37, '公益机场速鹰666，每日签到免费领流量', '真正大鸡场，100多个节点，V2ray节点50多个。港台美日新均有白嫖节点，每日签到送1-7G流量。多条BGP中转/Azure/Dmit/HKT/Hinet/多点IPLC/保证高端用户使用需求。', 'https://suying666.net/auth/register?code=BZe8', 'null', 'https://i.ytimg.com/vi/X-iKhFXqOy8/maxresdefault.jpg', 1, 800.00, '2,3,4', 455, NULL, '2020-02-02 21:52:37', '2020-02-29 13:49:51', 1, 0);
INSERT INTO `advertisement` VALUES (38, 'JavaEE Spring框架核心编程思想大讲堂视频教程，共239讲', '时至今日，Spring 在 Java 生态系统与就业市场上，...\n\n极客时间版权所有: https://time.geekbang.org/course/intro/100042601?code=-NUPKqjMJ-LjE3xPlm9yqdHBAcxAX40b6QByNxfNRPA%3D', 'https://time.geekbang.org/course/intro/100042601?code=-NUPKqjMJ-LjE3xPlm9yqdHBAcxAX40b6QByNxfNRPA%3D', 'https://static001.geekbang.org/misc/posters/1291721/6d1786c55647a7d8a1bd4135d9a684ec.jpg', 'https://static001.geekbang.org/misc/posters/1291721/6d1786c55647a7d8a1bd4135d9a684ec.jpg', 1, 360.00, '2,3,4', 78, '34,32,41,28,6', '2020-02-18 21:50:50', '2020-03-02 21:38:07', 1, 0);
INSERT INTO `advertisement` VALUES (39, '文件传输、存储不限速，选奶牛快传！前 100 名 8 折优惠，最低 74 元起！', '牛快传是一款在线文件传输 / 存储工具，不像传统网盘那样操作繁琐复杂，只需打开网页拖拽文件，即可快速上传，轻松生成下载链接。还可将链接加密、设置有效期及下载次数，充分满足个性化分享的需求。更重要的是，下载没有速度限制。\n目前上新期间，前 100 名享 8 折，前 500 名 8.5 折，前 2000 名 9 折，额外赠送 30 天会员时长。', 'https://partner.lizhi.io/ldqk/cowtransfer', 'https://git.imweb.io/si/imgbed/raw/master/2020/02/27/simwpnd1tzwh.png', 'https://gitee.com/masuit_admin/images/raw/master/2020/02/27/simwslw0xz41.png', 1, 300.00, '1,2,3,4', 327, '43,45,18,35,42,15', '2020-02-27 19:29:33', '2020-03-02 21:41:22', 1, 0);
INSERT INTO `advertisement` VALUES (40, '流媒体视频下载工具 Downie 4 上新，限时特惠仅需 50 元', 'macOS 平台出色的视频下载工具 Downie，现在迎来了 4.0 的大版本更新。软件支持超过 1000 个视频站点，YouTube、爱奇艺、土豆、Bilibili、网易云音乐等，它都能下载。\n即日起至 2020 年 3 月 3 日，Downie 4 上新限时 7 折，领取合作伙伴专属优惠券，下单 Downie 4 还能再减 5 元，到手价只需 50 元。', 'https://partner.lizhi.io/ldqk/downie', 'https://masuit.oss-cn-beijing.aliyuncs.com/2020/02/27/simwwu4i5yip.png', 'https://git.imweb.io/ldqk0/imgbed/raw/master/2020/02/27/simx2euzwv0h.png', 1, 300.00, '1,2,3,4', 167, '43,45,18,35,42,15', '2020-02-27 19:32:53', '2020-03-02 21:41:38', 14, 0);
INSERT INTO `advertisement` VALUES (41, '跨平台局域网文件共享工具，轻松面对面传文件，仅需 34 元起', '面对面分享文件的软件有很多，但是想找到一款稳定、快速、跨平台的工具，并没有那么容易。Feem 横跨 Mac / Win / Linux / iOS / Android 多个平台，支持局域网及 WiFi 直连，无需网络便能互传文件、文字、链接，无大小限制可断点续传，甚至比苹果的 AirDrop 更强大。', 'https://partner.lizhi.io/ldqk/feem', 'https://masuit.oss-cn-beijing.aliyuncs.com/2020/02/27/simx7eaztfr5.png', 'https://git.imweb.io/si/imgbed/raw/master/2020/02/27/simxc7nq4vsx.png', 1, 300.00, '1,2,3,4', 324, '43,45,18,35,42,15', '2020-02-27 19:36:04', '2020-03-02 21:41:50', 1, 0);
INSERT INTO `advertisement` VALUES (42, 'Fences – 栅栏式分区高效管理图标，美化 Windows 桌面', 'Fences 是知名开发商 Stardock 为 Windows 用户打造的一款经典的桌面管理工具。Fences 通过在桌面自由创建可命名的半透明区域给图标分组，并且在你不需要时隐藏它们。Fences 还具备自动组织、记忆布局、创建桌面分页和文件夹快捷入口等功能，让你管理桌面更加省心。', 'https://partner.lizhi.io/ldqk/fences', 'https://www-cdn.lizhi.io/wp-content/uploads/2019/04/lzfences_2240x840.png', 'null', 1, 300.00, '1', 471, '43,45,18,35,42,15', '2020-02-27 19:42:03', '2020-03-02 21:42:00', 1, 0);
INSERT INTO `advertisement` VALUES (43, 'Re0x  提供小众高质量的v2ray/ssr网络中继服务', 'Re0x 上线的海外节点均为高质量独享 VPS，无大量部署低成本 AWS、Azure、GCP 薅的羊毛机；国内节点均为高优先级出口 NAT，上海电信 CN2 和上海联通 AS4837；具备良好的稳定性和可持续发展性。', 'https://v2.re0x.org/auth/register?code=xAm8', 'null', 'https://git.imweb.io/ldqk/imgbed/raw/master/2020/02/29/sisr6grdpblt.png', 1, 900.00, '2,3,4', 228, NULL, '2020-02-29 10:48:08', '2020-02-29 13:49:43', 1, 0);
INSERT INTO `advertisement` VALUES (44, 'JetBrains All Products Pack[Mac/Win]编程开发工具集正版授权', '获取所有桌面产品，包括 IntelliJ IDEA Ultimate、ReSharper Ultimate 和其他 IDE。\nIntelliJ IDEA Ultimate - 这款全方位的工具集用于基于 JVM 的 Web、移动和企业开发\nReSharper Ultimate - Visual Studio 扩展、分析器和独立的跨平台 .NET IDE\n其他 IDE – 包括 AppCode、CLion、Datalore、DataGrip、GoLand、PhpStorm、Pycharm、Rider、RubyMine 和 WebStorm', 'https://partner.lizhi.io/ldqk/jetbrains_all', NULL, 'https://gd4.alicdn.com/imgextra/i1/881336826/O1CN01swowmL20IM8EWRz3E_!!881336826.png', 1, 300.00, '2,3,4', 55, '38,34,7,41,45,35,6,28,32', '2020-03-03 14:26:10', '2020-03-03 14:26:10', 1, 0);
INSERT INTO `advertisement` VALUES (45, 'IntelliJ IDEA Ultimate[Mac/Win]正版授权，低至999元/年', 'IntelliJ在业界被公认为优秀的Java开发平台之一，在智能代码助手、代码自动提示、重构、J2EE支持、Ant、JUnit、CVS整合、代码审查、 创新的GUI设计等方面表现突出,并支持基于Android平台的程序开发。', 'https://partner.lizhi.io/ldqk/intelliJ_idea_ultimate', 'null', 'https://gd3.alicdn.com/imgextra/i3/881336826/O1CN01t9KQKT20IM8DiMkOi_!!881336826.png', 1, 300.00, '2,3,4', 19, '38,34,7,41,45,6,28', '2020-03-03 14:28:02', '2020-03-03 14:28:32', 1, 0);
INSERT INTO `advertisement` VALUES (46, 'VisualStudio神级插件——Resharper Ultimate正版授权599元起！', '如果你是一名.NET开发人员，但是你却不使用ReSharper，那么你就不是一个合格的码农了，因为这是一个强大的神器，你值得拥有！开发效率绝对提升N倍！目前本站已和数码荔枝进行合作推广，正版授权低至￥599！！！', 'https://partner.lizhi.io/ldqk/resharper_ultimate', NULL, 'https://gd3.alicdn.com/imgextra/i1/881336826/O1CN01wfap6n20IM8Abz9VI_!!881336826.png', 1, 300.00, '2,3,4', 13, '38,34,7,41,45,6', '2020-03-04 14:07:28', '2020-03-04 14:07:28', 1, 0);

-- ----------------------------
-- Table structure for broadcast
-- ----------------------------
DROP TABLE IF EXISTS `broadcast`;
CREATE TABLE `broadcast`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Email` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `ValidateCode` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `UpdateTime` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `SubscribeType` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1192 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of broadcast
-- ----------------------------

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Name` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `ParentId` int(11) NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ParentId`(`ParentId`) USING BTREE,
  CONSTRAINT `category_ibfk_1` FOREIGN KEY (`ParentId`) REFERENCES `category` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 46 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (1, 1, '默认分类', '默认的分类', NULL);
INSERT INTO `category` VALUES (2, 1, '操作系统', 'Windows硬盘系统和RamOS系统', NULL);
INSERT INTO `category` VALUES (4, 1, '影视精品', '博主珍藏的精品电影和电视剧', NULL);
INSERT INTO `category` VALUES (6, 1, '程序开发', '开发者学习教程', NULL);
INSERT INTO `category` VALUES (7, 1, '开发工具', '开发者常用工具', NULL);
INSERT INTO `category` VALUES (8, 1, '网上学科', '科学上网是科学的利用网络去解决生活中的实际问题以及学术研究等，简称科学上网，是有计划性，有目标的上网。联外网不是“科学上网”。', NULL);
INSERT INTO `category` VALUES (13, 1, '共享文献', NULL, NULL);
INSERT INTO `category` VALUES (14, 1, '其他', NULL, NULL);
INSERT INTO `category` VALUES (15, 1, '绿色软件', '没有捆绑，没有烦人的广告，没有臃肿的身材，不收用户一分钱，不以盈利为目的！', NULL);
INSERT INTO `category` VALUES (17, 1, '硬件知识', NULL, NULL);
INSERT INTO `category` VALUES (18, 1, '玩机分享', '实用的搞机技巧', NULL);
INSERT INTO `category` VALUES (20, 1, '生活随笔', NULL, NULL);
INSERT INTO `category` VALUES (28, 1, '视频教程', '各大编程语言学习视频', NULL);
INSERT INTO `category` VALUES (30, 1, '科技前沿', NULL, NULL);
INSERT INTO `category` VALUES (31, 1, '网络安全', NULL, NULL);
INSERT INTO `category` VALUES (32, 1, '前端杂谈', NULL, NULL);
INSERT INTO `category` VALUES (34, 1, '后端技术', '后端开发者充电', NULL);
INSERT INTO `category` VALUES (35, 1, '生产力工具', NULL, NULL);
INSERT INTO `category` VALUES (38, 1, '.NET开发技术', '微软大法好！.NET好！退Java、php保平安！', NULL);
INSERT INTO `category` VALUES (41, 1, '开源项目', '博主自主研发的开源项目', NULL);
INSERT INTO `category` VALUES (42, 1, '稀缺资源', '互联网上仅存的稀缺资源，不收取任何费用，仅用于个人研究和使用，发扬互联网分享精神，专注收藏与分享。', NULL);
INSERT INTO `category` VALUES (43, 1, '曝光台', '专门曝光一些流氓公司，毒瘤公司，以及一些社会垃圾，坚决和社会毒瘤作斗争！秉承务实求真的态度以及客观评价，让更多人了解真相，防止上当受骗！', NULL);
INSERT INTO `category` VALUES (44, 1, 'DIY显示器', '自主生产的超高性价比的diy显示器，对标大金刚，小金刚等，一半的价格，完美的体验，M270KCJ-K7B，M270DAN02.6，LM315WR1-SSB2，M270QAN02.3，M350QVR01.1。', NULL);
INSERT INTO `category` VALUES (45, 1, '正版软件', '优惠实用的小软件，提高工作效率', NULL);
INSERT INTO `category` VALUES (46, 1, '安卓软件', NULL, NULL);

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `NickName` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Email` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `QQorWechat` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ParentId` int(11) NOT NULL,
  `PostId` int(11) NOT NULL,
  `CommentDate` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `Browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `OperatingSystem` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `IsMaster` bit(1) NOT NULL DEFAULT b'0',
  `VoteCount` int(11) NOT NULL DEFAULT 0,
  `AgainstCount` int(11) NOT NULL DEFAULT 0,
  `IP` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `IX_Comment_PostId`(`PostId`) USING BTREE,
  CONSTRAINT `FK_Comment_Post_PostId` FOREIGN KEY (`PostId`) REFERENCES `post` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 9673 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES (8055, 5, 'Mr_Robot', '1@1.cn', NULL, '0.0&nbsp; 支持DTS5.1&nbsp; 想那些DTS7.1等等&nbsp; 什么的高级格式，是什么软件能做出来那', 0, 1676, '2019-11-22 18:43:46.484125', 'Chrome 63.0.3239.132', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8216, 5, '8813526', '1@1.cn', NULL, '现在很少用这类软件了。', 0, 1685, '2019-12-03 09:25:00.939453', 'Chrome 70.0.3538.102', 'OS X 10.14.1 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8232, 5, '8813526', '1@1.cn', NULL, '<p>我就是通过本站购买的正版，永久授权！</p><p><img src=\"https://pic1.superbed.cn/item/5de70508f1f6f81c50747843.jpg\"></p>', 0, 1687, '2019-12-04 09:01:14.388671', 'Chrome 70.0.3538.102', 'OS X 10.14.1 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8238, 5, '端木', '1@1.cn', NULL, '<p><span>官方授权平台，绑定账户，用着很放心！还是adguard好用，简单实用，免得操心</span></p>', 0, 1687, '2019-12-04 11:14:24.943359', 'Chrome 78.0.3904.108', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8242, 5, '爱读书', '1@1.cn', NULL, '<p><a style=\"text-align: center\"></a></p><h2 class=\"padding-bot10\">AdGuard<span>&nbsp;官方前几天个人终身版（3设备）半价优惠，94.95元</span></h2>', 0, 1687, '2019-12-04 13:26:39.195312', 'Chrome 74.0.3729.169', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8254, 5, 'Mr_Robot', '1@1.cn', NULL, '<p>138.哎，现在还没钱买</p>', 0, 1687, '2019-12-04 17:32:15.202148', 'Chrome 63.0.3239.132', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8271, 5, '未寒', '1@1.cn', NULL, '官网买了家庭版9设备，终身授权，$23.99', 0, 1687, '2019-12-05 11:26:14.792968', 'Chrome 78.0.3904.108', 'Windows 10 64-bit', b'0', 2, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8437, 5, '五月', '1@1.cn', NULL, '24$ 怎么买的', 8271, 1687, '2019-12-15 18:28:14.507812', 'Chrome 79.0.3945.79', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8442, 5, '懒得勤快', '1@1.cn', NULL, '$24≈￥167&gt;￥138', 8437, 1687, '2019-12-15 19:12:14.348632', 'Chrome 79.0.3945.79', 'Windows 10 64-bit', b'1', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8490, 5, '8813526', '1@1.cn', NULL, '我一直在找破解版的。<img src=\"https://masuit.com/Assets/layui/images/face/4.gif\"><img src=\"https://masuit.com/Assets/layui/images/face/2.gif\">', 0, 1698, '2019-12-18 08:47:51.467773', 'Safari 11.1.2', 'OS X 10.11.6', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8492, 5, '懒得勤快', '1@1.cn', NULL, '站内有', 8490, 1698, '2019-12-18 09:09:09.873046', 'Chrome 79.0.3945.79', 'Windows 10 64-bit', b'1', 1, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8497, 5, 'Hi时光', '1@1.cn', NULL, '<p><span>站长 购买用优惠券报 优惠券\"ldqkidm30\" 不存在！</span></p><p><span><br></span></p>', 0, 1680, '2019-12-18 09:22:08.144531', 'Chrome 79.0.3945.79', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8498, 5, '懒得勤快', '1@1.cn', NULL, '可以用了', 8497, 1680, '2019-12-18 09:35:38.541992', 'Chrome 79.0.3945.88', 'Windows 10 64-bit', b'1', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8501, 5, '端木', '1@1.cn', NULL, '终身版本只需99元，物美价廉', 0, 1680, '2019-12-18 10:39:21.207031', 'Chrome 79.0.3945.79', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8566, 5, 'czx', '1@1.cn', NULL, '千万别买，骗人的，用的腾讯，百度，谷歌的端口，端口使用费是要自己购买的，并且，这个不是主要的，主要的是，你付完费，根本得不到软件，注意专业版不是市面上下到的，不知道这个怎么获得。<br>', 0, 1704, '2019-12-21 19:02:03.289062', 'Firefox 71.0', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8567, 5, '懒得勤快', '1@1.cn', NULL, '你买过了？', 8566, 1704, '2019-12-21 19:03:29.320312', 'Chrome 79.0.3945.88', 'Windows 10 64-bit', b'1', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8568, 5, '懒得勤快', '1@1.cn', NULL, '如果有这种情况的话，请尽快反馈相关证据，方便我这边及时采取相应措施', 8566, 1704, '2019-12-21 19:07:14.727539', 'Chrome 79.0.3945.88', 'Windows 10 64-bit', b'1', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8569, 5, 'czx', '1@1.cn', NULL, '刚刚买完，我没事闲的，乱攻击人', 0, 1704, '2019-12-21 19:09:32.005859', 'Firefox 71.0', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8570, 5, '懒得勤快', '1@1.cn', NULL, '<p>麻烦提供下相关证据啊，<span>方便我这边及时采取相应措施</span></p>', 8569, 1704, '2019-12-21 19:12:47.331054', 'Chrome 79.0.3945.88', 'Windows 10 64-bit', b'1', 1, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8572, 5, '懒得勤快', '1@1.cn', NULL, '<p>代理方给的回应</p><p><img src=\"https://masuit.oss-cn-beijing.aliyuncs.com/20191221/sbw9nggr00zk.png\"></p>', 8566, 1704, '2019-12-21 19:29:52.176757', 'Chrome 79.0.3945.88', 'Windows 10 64-bit', b'1', 1, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8585, 5, 'iFish', '1@1.cn', NULL, '这个软件调用的三方接口吧。收费似乎有点儿……', 0, 1704, '2019-12-22 15:59:59.504882', 'Chrome 81.0.4003.0', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8591, 5, '未寒', '1@1.cn', NULL, '切换到阿根廷区域', 8437, 1687, '2019-12-23 09:39:36.384765', 'Chrome 80.0.3987.16', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8593, 5, '小铅笔', '1@1.cn', NULL, '<p>天若&nbsp;OCR&nbsp;我从一开始吾爱论坛的开源版本，一致用到现在的付费版本，是个良心软件。感觉评论区里面对于收费问题有点误会的样子，建议在文章里面附个图&nbsp;<a href=\"https://tianruoocr.cn/server/price.php\">https://tianruoocr.cn/server/price.php</a></p><p><img src=\"https://i.loli.net/2019/12/23/9UlV3pIT42HmPMu.png\"></p>', 0, 1704, '2019-12-23 15:12:51.629882', 'Chrome 78.0.3904.108', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8837, 5, '米弗', '1@1.cn', NULL, '试过几个版本，每过一段时间提示“密钥已被吊销”，请问有破解彻底的版本么？', 8492, 1698, '2020-01-09 17:16:12.380859', 'Chrome 79.0.3945.88', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8897, 5, '五月', '1@1.cn', NULL, '$24 家庭版啊 不是个人啊', 8442, 1687, '2020-01-13 15:57:43.295898', 'Chrome 78.0.3904.87', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (8898, 5, '五月', '1@1.cn', NULL, '切IP？', 8591, 1687, '2020-01-13 15:58:07.782226', 'Chrome 78.0.3904.87', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (9060, 5, '小马', '1@1.cn', NULL, '360既视感。。。。', 0, 1671, '2020-02-04 14:22:34.308593', 'Chrome 81.0.4042.0', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (9061, 5, '懒得勤快', '1@1.cn', NULL, '所以人家叫365', 9060, 1671, '2020-02-04 14:23:03.743164', 'Chrome 79.0.3945.130', 'Windows 10 64-bit', b'1', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (9076, 5, 'AAY', '1@1.cn', NULL, '用俄文的', 8837, 1698, '2020-02-04 20:36:38.460937', 'Chrome 79.0.3945.130', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);
INSERT INTO `comment` VALUES (9163, 5, 'UClinux', '1@1.cn', NULL, '用注册机。然后hosts屏蔽验证地址就好了。', 8837, 1698, '2020-02-09 00:58:20.177734', 'Chrome 74.0.3729.169', 'Windows 10 64-bit', b'0', 0, 0, NULL, NULL);

-- ----------------------------
-- Table structure for donate
-- ----------------------------
DROP TABLE IF EXISTS `donate`;
CREATE TABLE `donate`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `NickName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Email` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `QQorWechat` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Amount` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Via` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `DonateTime` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of donate
-- ----------------------------
INSERT INTO `donate` VALUES (2, 1, '雪夜享旅行', NULL, NULL, '￥18.00', '支付宝', '2017-09-24 00:00:00.000000');
INSERT INTO `donate` VALUES (3, 1, '立足现在，展望未来', NULL, NULL, '￥19.00', 'QQ二维码', '2017-10-08 00:00:00.000000');
INSERT INTO `donate` VALUES (4, 0, '生于忧患', NULL, NULL, '网站服务器', '香港云服务器', '2017-10-09 00:00:00.000000');
INSERT INTO `donate` VALUES (5, 0, '```````', NULL, NULL, '￥5.00', '微信', '2017-10-12 00:00:00.000000');
INSERT INTO `donate` VALUES (8, 0, 'AMD Ryzen 忠实拥蹙', NULL, NULL, '￥30.00', '支付宝', '2017-11-03 20:20:00.000000');
INSERT INTO `donate` VALUES (9, 0, ' 山 那 边 ', NULL, NULL, '￥8.00', 'QQ空间打赏', '2017-11-24 00:00:00.000000');
INSERT INTO `donate` VALUES (10, 0, '*婧波', NULL, NULL, '￥0.5', '支付宝', '2017-12-24 00:00:00.000000');
INSERT INTO `donate` VALUES (11, 0, '雪夜享旅行', NULL, NULL, '￥20.18', '支付宝', '2018-01-01 00:00:00.000000');
INSERT INTO `donate` VALUES (12, 0, '星月浅-伊晴雪雨陌轩', NULL, NULL, '￥12.00', 'QQ红包', '2018-01-07 00:00:00.000000');
INSERT INTO `donate` VALUES (13, 0, 'Paul Lee', NULL, NULL, '￥0.55', 'QQ二维码', '2018-01-11 00:00:00.000000');
INSERT INTO `donate` VALUES (14, 0, 'xkjs.org', NULL, NULL, '￥0.88', '微信二维码', '2018-02-03 00:00:00.000000');
INSERT INTO `donate` VALUES (15, 0, '*磊', NULL, NULL, '￥10.00', '支付宝', '2018-04-06 00:00:00.000000');

-- ----------------------------
-- Table structure for fastshare
-- ----------------------------
DROP TABLE IF EXISTS `fastshare`;
CREATE TABLE `fastshare`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Link` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Sort` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 40 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of fastshare
-- ----------------------------
INSERT INTO `fastshare` VALUES (16, 0, '稀缺资源统一下载地址页-gitlab', '/misc/5', 1);
INSERT INTO `fastshare` VALUES (24, 0, '跟着组织走，电报群：https://t.me/masuit', 'https://t.me/masuit', 1);
INSERT INTO `fastshare` VALUES (35, 0, '各位说zippyshare下载时弹广告的，麻烦给你的浏览器去下广告！', '/1584', 15);
INSERT INTO `fastshare` VALUES (37, 0, 'zippyshare自动下载的油猴脚本', 'https://greasyfork.org/zh-CN/scripts/6981-zippyshare-auto-download-0-4-march-2019', 16);
INSERT INTO `fastshare` VALUES (40, 0, '最近老是接到很多访客投诉说本站资源报毒的问题，这种问题请添加到允许信任就可以了。本站所提供的任何二进制文件均不具备权威性，如需体验官方正版，请从相应的官网渠道下载，请悉知！村通网并不可怕。如果九年义务教育还看不懂报毒的英文的话，请购买正版。信杀软，无破解！', '/n/74', 3);

-- ----------------------------
-- Table structure for internalmessage
-- ----------------------------
DROP TABLE IF EXISTS `internalmessage`;
CREATE TABLE `internalmessage`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Link` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Time` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `Read` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6812 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of internalmessage
-- ----------------------------

-- ----------------------------
-- Table structure for leavemessage
-- ----------------------------
DROP TABLE IF EXISTS `leavemessage`;
CREATE TABLE `leavemessage`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL,
  `NickName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `PostDate` datetime(6) NOT NULL,
  `Email` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `QQorWechat` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `ParentId` int(11) NOT NULL,
  `Browser` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `OperatingSystem` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `IsMaster` bit(1) NOT NULL,
  `IP` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `IX_Date`(`PostDate`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1325 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of leavemessage
-- ----------------------------
INSERT INTO `leavemessage` VALUES (38, 5, '誓不落伍', '网站有点花俏，字数还不够<img src=\"/Assets/layui/images/face/5.gif\">', '2017-09-12 14:55:38.000000', '1@1.cn', NULL, 0, 'Chrome 59.0.3071.86', 'Windows 10 64-bit', b'0', NULL, NULL);
INSERT INTO `leavemessage` VALUES (40, 5, 'foxicreat', '网盘链接好多都失效了，怎么回事。求相关链接', '2017-09-22 09:39:52.000000', '1@1.cn', NULL, 0, 'Chrome 56.0.2924.87', 'Windows Server 2008 R2 / 7 64-bit', b'0', NULL, NULL);
INSERT INTO `leavemessage` VALUES (41, 5, '懒得勤快', '链接失效都会修改重新发布的，注意关注下最新动态', '2017-09-28 13:59:33.000000', '1@1.cn', 'admin@masuit.com', 40, 'Chrome 63.0.3205.2', 'Windows 8.1 64-bit', b'1', NULL, NULL);
INSERT INTO `leavemessage` VALUES (42, 5, '懒得勤快', '网站做的比较草率，后期会慢慢优化', '2017-09-28 14:00:02.000000', '1@1.cn', 'admin@masuit.com', 38, 'Chrome 63.0.3205.2', 'Windows 8.1 64-bit', b'1', NULL, NULL);

-- ----------------------------
-- Table structure for links
-- ----------------------------
DROP TABLE IF EXISTS `links`;
CREATE TABLE `links`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Except` bit(1) NOT NULL DEFAULT b'0',
  `Recommend` bit(1) NOT NULL DEFAULT b'0',
  `Weight` int(11) NOT NULL DEFAULT 0,
  `UpdateTime` timestamp(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `Recommend`(`Recommend`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 177 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of links
-- ----------------------------
INSERT INTO `links` VALUES (2, 1, 'github', 'https://github.com/ldqk', b'1', b'1', 1566, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (9, 1, '顾建伟博客', 'http://www.xkjs.org/', b'0', b'0', 80, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (43, 1, '硅云', 'https://www.vpsor.cn/aff?affid=29236', b'1', b'0', 69, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (57, 1, '田珊珊博客', 'http://www.tianshan277.com/my-friends.html', b'0', b'0', 68, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (58, 1, '梁钟霖博客', 'https://www.liangzl.com/get-friend-link.html', b'0', b'0', 632, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (59, 14, '宋子宪博客', 'https://www.52xbc.cn', b'0', b'0', 87, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (61, 1, '健旺博客', 'http://www.256it.com/', b'0', b'0', 108, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (62, 1, '穆子龙', 'https://www.muzilong.cn', b'0', b'0', 86, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (63, 1, '曾小晨', 'http://www.imain.net', b'0', b'0', 88, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (66, 1, '游魂博客', 'https://www.iyouhun.com/', b'0', b'0', 86, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (69, 1, '李胜利', 'http://www.lishengli.com', b'0', b'0', 78, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (73, 1, '七日间', 'https://www.heminghui.top', b'0', b'0', 72, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (74, 1, '二丫讲梵', 'http://www.eryajf.net', b'0', b'0', 185, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (77, 1, '袁志蒙博客', 'http://blog.yzmcms.com/', b'0', b'0', 209, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (92, 1, 'L&H Site', 'http://l2h.site/', b'0', b'0', 84, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (95, 1, 'ChromeFor浏览器插件下载中心', 'https://www.chromefor.com/links/', b'0', b'0', 242, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (99, 1, 'DeTechn Blog', 'https://www.detechn.com', b'0', b'0', 183, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (102, 1, '脑袋瓜子', 'https://www.naodai.org', b'1', b'0', 1063, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (103, 1, '华梦博客', 'https://52huameng.com/links.html', b'0', b'0', 157, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (106, 1, '吾勇士', 'https://wuyongshi.top/links.html', b'0', b'0', 74, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (110, 14, '边小丰博客', 'http://www.bianxiaofeng.com', b'0', b'0', 81, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (111, 1, '分享巴中', 'https://www.sharexbar.com/', b'0', b'0', 126, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (112, 1, '陈冬冬', 'http://www.chendd.cn', b'0', b'0', 91, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (115, 1, '博客园-Edison Zhou', 'https://www.cnblogs.com/edisonchou/', b'1', b'0', 181, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (125, 1, '童话镇 ', 'https://www.loadream.com/', b'0', b'0', 283, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (127, 1, '无名的碎语', 'https://www.4jax.net/log/', b'0', b'0', 124, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (128, 1, 'Sanshi', 'http://www.sanshi30.cn/about.html', b'0', b'0', 85, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (132, 1, 'Szx\'s Blog', 'https://www.songzixian.com/links.html', b'0', b'0', 116, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (136, 1, '刘旭博客', 'http://www.liuxuseo.cn', b'0', b'0', 83, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (139, 1, '虾米的蜗居', 'https://woj.app', b'0', b'0', 102, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (140, 1, 'Gopher博客', 'https://chunlife.top/', b'0', b'0', 76, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (143, 1, 'java菜市场', 'https://www.javaweb.shop', b'0', b'0', 103, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (148, 1, '何智政个人博客', 'https://hzz.cool/blog', b'0', b'0', 131, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (151, 1, 'touwoyimuli', 'https://touwoyimuli.github.io/archives/', b'0', b'0', 92, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (153, 1, '蛋码农', 'https://www.dancoder.cn/', b'0', b'0', 86, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (155, 1, '马王天地', 'http://www.goodym.cn/', b'0', b'0', 77, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (156, 1, '江湖人士', 'https://jhrs.com', b'0', b'0', 125, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (157, 1, 'The HowarZheng\'s Blog', 'https://howarzheng.com/friends/', b'0', b'0', 79, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (158, 1, '玛特笔记', 'https://www.mamt.cn/pages/links.html', b'0', b'0', 166, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (160, 14, '蒋金泽的博客', 'http://www.zeee.vip/app/home/index/about.html', b'0', b'0', 94, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (161, 1, '清风博客', 'https://www.skyfinder.cc', b'0', b'0', 162, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (164, 1, '大道至简博客', 'https://www.yunted.com/', b'1', b'0', 108, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (165, 1, 'Dotnet9', 'https://dotnet9.com', b'0', b'0', 2, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (166, 1, 'NET牛人', 'https://www.netnr.com', b'0', b'0', 36, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (167, 1, '因特极点\'s Blog', 'http://blog.interjd.tech/', b'0', b'0', 10, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (168, 1, '学逆向论坛', 'https://www.xuenixiang.com/', b'0', b'0', 3, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (169, 1, '人工博客', 'https://www.94rg.com/', b'0', b'0', 4, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (170, 1, '52abp', 'https://www.52abp.com/', b'0', b'0', 37, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (171, 1, '吾皇千睡博客', 'http://16tao.cn/', b'0', b'0', 0, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (172, 1, 'Git开源网', 'https://gitoscc.com/', b'0', b'0', 3, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (173, 1, '佛系软件', 'https://www.foxirj.com', b'0', b'0', 46, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (174, 1, '墙裂', 'https://go.qianglie.cc/aff.php?aff=597', b'1', b'0', 0, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (175, 1, '速鹰666', 'https://suying666.net/auth/register?code=BZe8', b'1', b'0', 0, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (176, 1, 're0x', 'https://v2.re0x.org/auth/register?code=xAm8', b'1', b'0', 0, '2020-09-12 11:22:32');
INSERT INTO `links` VALUES (177, 1, 'LynnGuo666', 'https://bbs.lynnguo666.site', b'0', b'0', 2, '2020-09-12 11:22:32');

-- ----------------------------
-- Table structure for loginrecord
-- ----------------------------
DROP TABLE IF EXISTS `loginrecord`;
CREATE TABLE `loginrecord`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `IP` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `LoginTime` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `Province` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `PhysicAddress` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `LoginType` int(11) NOT NULL DEFAULT 0,
  `UserInfoId` int(11) NOT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `IX_LoginRecord_UserInfoId`(`UserInfoId`) USING BTREE,
  CONSTRAINT `FK_LoginRecord_UserInfo_UserInfoId` FOREIGN KEY (`UserInfoId`) REFERENCES `userinfo` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 141 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of loginrecord
-- ----------------------------

-- ----------------------------
-- Table structure for menu
-- ----------------------------
DROP TABLE IF EXISTS `menu`;
CREATE TABLE `menu`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Icon` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Url` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sort` int(11) NOT NULL DEFAULT 1,
  `ParentId` int(11) NOT NULL,
  `MenuType` int(11) NOT NULL,
  `NewTab` bit(1) NOT NULL DEFAULT b'0',
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `Sort`(`Sort`) USING BTREE,
  INDEX `ParentId`(`ParentId`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 78 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of menu
-- ----------------------------
INSERT INTO `menu` VALUES (2, 1, '📚分类', NULL, '#', 20, 0, 1, b'0');
INSERT INTO `menu` VALUES (3, 1, '🎨专题', NULL, '#', 30, 0, 2, b'0');
INSERT INTO `menu` VALUES (4, 1, '🔬黑科技', NULL, '#', 40, 0, 3, b'0');
INSERT INTO `menu` VALUES (5, 1, '投稿', NULL, '/post/publish', 62, 0, 0, b'0');
INSERT INTO `menu` VALUES (6, 1, '留言和反馈', NULL, '/msg', 50, 0, 0, b'0');
INSERT INTO `menu` VALUES (7, 1, '技术杂谈', NULL, '#', 210, 2, 1, b'0');
INSERT INTO `menu` VALUES (9, 1, '资源分享', NULL, '#', 220, 2, 1, b'0');
INSERT INTO `menu` VALUES (10, 1, '程序人生', NULL, '#', 230, 2, 1, b'0');
INSERT INTO `menu` VALUES (11, 1, '杂七杂八', NULL, '#', 240, 2, 1, b'0');
INSERT INTO `menu` VALUES (13, 1, '玩机分享', NULL, '/cat/18', 2129, 7, 1, b'0');
INSERT INTO `menu` VALUES (14, 1, '科技前沿', NULL, '/cat/30', 2130, 7, 1, b'0');
INSERT INTO `menu` VALUES (16, 1, '硬件知识', NULL, '/cat/17', 2140, 7, 1, b'0');
INSERT INTO `menu` VALUES (17, 1, '网络安全', NULL, '/cat/31', 2150, 7, 1, b'0');
INSERT INTO `menu` VALUES (19, 1, '科学上网', NULL, '/cat/8', 2210, 9, 1, b'0');
INSERT INTO `menu` VALUES (20, 1, '视频教程', NULL, '/cat/28', 2220, 9, 1, b'0');
INSERT INTO `menu` VALUES (21, 1, '操作系统', NULL, '/cat/2', 2230, 9, 1, b'0');
INSERT INTO `menu` VALUES (23, 1, '前端杂谈', NULL, '/cat/32', 2361, 10, 1, b'0');
INSERT INTO `menu` VALUES (28, 1, '后端技术', NULL, '/cat/34', 2350, 10, 1, b'0');
INSERT INTO `menu` VALUES (29, 1, '开发工具', NULL, '/cat/7', 2360, 10, 1, b'0');
INSERT INTO `menu` VALUES (30, 1, '生产力工具', NULL, '/cat/35', 2231, 9, 1, b'0');
INSERT INTO `menu` VALUES (33, 1, '关于', NULL, '/about', 90, 0, 0, b'0');
INSERT INTO `menu` VALUES (42, 1, '网站公告', NULL, '/notice', 2429, 11, 1, b'0');
INSERT INTO `menu` VALUES (43, 1, '免责声明', NULL, '/disclaimer', 2429, 11, 1, b'0');
INSERT INTO `menu` VALUES (44, 1, '友情链接', NULL, '/links', 2428, 11, 1, b'0');
INSERT INTO `menu` VALUES (46, 1, '科学上网', 'https://git.imweb.io/ldqk/imgbed/raw/master/2018/2/5cc29f212a28f.gif', '/c/1', 351, 3, 2, b'0');
INSERT INTO `menu` VALUES (48, 1, '开源项目', 'https://git.imweb.io/ldqk/imgbed/raw/master/2018/2/5cc29f21dab23.jpg', '/c/2', 310, 3, 2, b'0');
INSERT INTO `menu` VALUES (49, 1, '生产力工具', 'https://git.imweb.io/ldqk/imgbed/raw/master/2018/2/5ccbdd60cf93b.jpg', '/c/4', 340, 3, 2, b'0');
INSERT INTO `menu` VALUES (50, 1, '根据经纬度查询地理位置', NULL, '/tools/pos', 410, 4, 3, b'0');
INSERT INTO `menu` VALUES (51, 1, '查询IP地址详细地理信息', NULL, '/tools/ip', 420, 4, 3, b'0');
INSERT INTO `menu` VALUES (55, 1, '绿色软件', NULL, '/cat/15', 1, 9, 1, b'0');
INSERT INTO `menu` VALUES (58, 1, '💰打赏', NULL, '/donate', 49, 0, 0, b'0');
INSERT INTO `menu` VALUES (59, 1, '详细地理位置转经纬度', NULL, '/tools/addr', 430, 4, 3, b'0');
INSERT INTO `menu` VALUES (60, 1, '资源福利', 'https://git.imweb.io/ldqk/imgbed/raw/master/20190613/129805093.jpg', '/c/5', 350, 3, 2, b'0');
INSERT INTO `menu` VALUES (66, 1, '稀缺资源', 'https://git.imweb.io/ldqk/imgbed/raw/master/2018/2/5ccbdd621ef9d.jpg', '/c/6', 360, 3, 2, b'0');
INSERT INTO `menu` VALUES (68, 1, 'jetbrains资源', 'https://git.imweb.io/ldqk/imgbed/raw/master/2018/2/5ccbdd6296f00.jpg', '/c/7', 370, 3, 2, b'0');
INSERT INTO `menu` VALUES (69, 1, 'Rss', NULL, '/rss', 9999, 0, 0, b'1');
INSERT INTO `menu` VALUES (70, 1, '🤑🥵🥶🧐🥳', NULL, 'http://183.91.54.237:7080/masuit/soft/tree/master', 49, 0, 0, b'1');
INSERT INTO `menu` VALUES (71, 1, '💻电竞显示器💻', NULL, '/cat/44', 10, 0, 0, b'1');
INSERT INTO `menu` VALUES (72, 1, 'DMCA', NULL, '/misc/10', 2450, 11, 1, b'1');
INSERT INTO `menu` VALUES (73, 1, '隐私声明', NULL, '/misc/11', 2460, 11, 1, b'0');
INSERT INTO `menu` VALUES (74, 1, '稀缺资源', NULL, '#', 219, 2, 1, b'0');
INSERT INTO `menu` VALUES (75, 1, '曝光台', NULL, '/cat/43', 2510, 74, 1, b'1');
INSERT INTO `menu` VALUES (76, 1, '稀缺资源', NULL, '/cat/42', 2520, 74, 1, b'0');
INSERT INTO `menu` VALUES (77, 1, '.NET开发技术', NULL, '/cat/38', 2340, 10, 1, b'0');
INSERT INTO `menu` VALUES (78, 1, '开源项目', NULL, '/cat/41', 2305, 10, 1, b'0');

-- ----------------------------
-- Table structure for misc
-- ----------------------------
DROP TABLE IF EXISTS `misc`;
CREATE TABLE `misc`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `PostDate` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `ModifyDate` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 12 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of misc
-- ----------------------------
INSERT INTO `misc` VALUES (3, 8, '博客项目简介', '<p><span style=\"font-size: 20px; color: rgb(255, 0, 0);\">从项目之初开始就准备开源的，但出于安全考虑，所以博主为了确保有足够的安全性以及高性能，距今已经开发了一年多，在这期间也没有出现过任何的安全事故，所以准正式开源，为了项目后期的更加完善，欢迎大家发现并提交bug及体验方面的优化，感谢大家一直以来的关注和支持。提交bug，请移步：<a href=\"https://github.com/ldqk/Masuit.MyBlogs/issues\" target=\"_blank\" textvalue=\"https://github.com/ldqk/Masuit.MyBlogs/issues\">https://github.com/ldqk/Masuit.MyBlogs/issues</a></span></p><h3 style=\"box-sizing: border-box; font-family: 微软雅黑, Tahoma, Helvetica, SimSun, sans-serif; line-height: 36px; color: rgb(51, 51, 51); margin: 10px 0px 6px; font-size: 24px; padding: 0px 0px 2px 7px; border-width: 0px 0px 1px 5px; border-top-style: initial; border-right-style: initial; border-bottom-style: solid; border-left-style: solid; border-top-color: initial; border-right-color: initial; border-bottom-color: rgb(221, 221, 221); border-left-color: rgb(53, 161, 0); border-image: initial; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; vertical-align: baseline; white-space: normal;user-select: text !important;\">项目简介</h3><p>运行环境：WindowsServer2012+.NET&nbsp;Framework 4.6+<br></p><p>开发工具：VisualStudio2017</p><p>开发语言：C# 7.0</p><p>项目简介：主流的博客系统都是基于wordpress的，而博主作为一名技术控，wordpress完全不能满足我的需求，而.NET的文章系统，比如Orchard、umbraco也不好用，所以就自主研发出了这套博客系统。</p><p>客户端环境：Chrome43以上版本浏览器，Firefox30以上版本浏览器，不支持IE全系列</p><h3 style=\"white-space: normal; box-sizing: border-box; font-family: 微软雅黑, Tahoma, Helvetica, SimSun, sans-serif; line-height: 36px; color: rgb(51, 51, 51); margin: 10px 0px 6px; font-size: 24px; padding: 0px 0px 2px 7px; border-width: 0px 0px 1px 5px; border-top-style: initial; border-right-style: initial; border-bottom-style: solid; border-left-style: solid; border-top-color: initial; border-right-color: initial; border-bottom-color: rgb(221, 221, 221); border-left-color: rgb(53, 161, 0); border-image: initial; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; vertical-align: baseline; user-select: text !important;\">技术栈</h3><p>前端页面：<br></p><ol class=\" list-paddingleft-2\" style=\"list-style-type: decimal;\"><li><p>基于bootstrap3布局</p></li><li><p>ueditor+layedit富文本编辑器<br></p></li><li><p>notie提示栏+sweetyalert弹窗+layui组件</p></li><li><p>angularjs</p></li></ol><p><br></p><p>后台管理页：<br></p><ol class=\" list-paddingleft-2\" style=\"list-style-type: decimal;\"><li><p>angularjs单一页面应用程序</p></li><li><p>material布局风格</p></li><li><p>highchart+echart图表组件</p></li><li><p>ng-table表格插件</p></li><li><p>material风格angular-filemanager文件管理器</p></li></ol><p><br></p><p>后台程序：</p><ol class=\" list-paddingleft-2\" style=\"list-style-type: decimal;\"><li><p>基于asp.net&nbsp;mvc5+EntityFramework6&nbsp;CodeFirst+n层架构</p></li><li><p>Aspose.Word实现Word文档上传转为html代码<br></p></li><li><p>hangfire实现分布式任务调度</p></li><li><p>Redis分布式Session和缓存</p></li><li><p>Z.EntityFramework.Plus实现数据访问层的高性能数据库批量操作</p></li><li><p>automapper实现多种实体间的相互映射和转换<br></p></li><li><p>Masuit.Tools实现.NET框架库功能扩展</p></li><li><p>autofac实现项目整体的依赖注入</p></li><li><p>基于ModelFirst实现CodeFirst的代码自动生成<br></p></li><li><p>实现EntityFramework的一级缓存和二级缓存<br></p></li><li><p>HtmlSanitizer实现html代码的防XSS攻击<br></p></li><li><p>FluentScheduler实现简单的任务调度(因为简单任务没必要用到hangfire)和高频的任务调度(hangfire的任务调度频率最小是1min)</p></li><li><p>Lucene.Net+第三方NLP接口实现网站文章的全文检索</p></li><li><p>通过Masuit.Tools实现精准IP定位</p></li><li><p>结合angular-filemanager实现web端文件管理器，可以直接管理网站所在服务器的任何文件</p></li><li><p>SignalR+Masuit.Tools实现服务器的实时性能监控<br></p></li><li><p>swagger实现开放接口的接口文档<br></p></li><li><p>主流互联网项目的安全架构，对恶意请求进行智能过滤和拦截，对恶意刷流量的访客进行过滤</p></li><li><p>主流互联网项目的数据库优化方案，目前网站已经有超50w的数据量，在这台2核2GB的服务器上，网站依然运行快速稳定，内存使用保持在1.5GB左右，CPU使用率保持在10%以下</p></li></ol><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2018/4/87c01ec7gy1ft52plhrb4j20y20ld0u9.jpg\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2018/4/87c01ec7gy1ft52png842j20sj0fq3zs.jpg\"><br></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2018/4/87c01ec7gy1ft52pqlf52j21kw0fzdhw.jpg\"></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2018/4/87c01ec7gy1ft52pt1hr9j21kw0mdjwt.jpg\"></p><h3 style=\"white-space: normal; box-sizing: border-box; font-family: 微软雅黑, Tahoma, Helvetica, SimSun, sans-serif; line-height: 36px; color: rgb(51, 51, 51); margin: 10px 0px 6px; font-size: 24px; padding: 0px 0px 2px 7px; border-width: 0px 0px 1px 5px; border-top-style: initial; border-right-style: initial; border-bottom-style: solid; border-left-style: solid; border-top-color: initial; border-right-color: initial; border-bottom-color: rgb(221, 221, 221); border-left-color: rgb(53, 161, 0); border-image: initial; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-stretch: inherit; vertical-align: baseline; user-select: text !important;\">主要功能</h3><p>文章发布<br></p><p>文章历史版本</p><p>访客精确分析</p><p>搜索记录分析</p><p>网站硬件性能实时监控</p><p>hangfire任务监控</p><p>服务器磁盘文件管理</p><p>无级菜单管理</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2018/4/87c01ec7gy1ft52pwfvpoj21kw0nqjy2.jpg\"></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2018/4/87c01ec7gy1ft52pymwinj21kw0s80wh.jpg\"></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2018/4/87c01ec7gy1ft52q0crg7j21880wn0wz.jpg\"></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2018/4/87c01ec7gy1ft52q28m4dj21kw0pkdk3.jpg\"></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2018/4/87c01ec7gy1ft52q427zzj21kw0ltjwk.jpg\"></p><p>前台页的功能，大家自己去体验吧。</p><p><br></p>', '2018-06-14 21:35:39.000000', '2019-10-19 17:40:48.959200');
INSERT INTO `misc` VALUES (4, 8, '侵删联系', '<h3 style=\"text-align: center;\">声明</h3><p>1、出于传递信息之目的，故本站可能会误刊发损害或影响“您”的合法权益，请“您”积极与我们联系处理；</p><p>2、因时间、精力有限，我们无法一一核实每一条消息的真实性，但我们会在发布之前尽最大努力来核实这些信息；</p><p>3、无论出于何种目的要求本站删除内容，“您”均需要提供相关证明，否则不予处理；</p><h3 style=\"text-align: center;\">主体要求</h3><p>4、无论是因我站侵权还是刊发内容可能影响到“您”的权益，所有删除、修改请求仅允许直接权利人申请;</p><p>5、“您”如果希望删除、修改内容，首先“您”必须是直接权利人且必须可以提供相关证明文件;</p><p>6、非直接权利人例如关联公司、朋友等，需持有直接权利人的授权证明;</p><h3 style=\"text-align: center;\">处理流程</h3><p>7、所需材料:直接权利人的证明文件、权利人给予处理人的授权文件、删改请求文件，以上文件均需加盖公章（文件请在本页底部下载附件）；</p><p>8、填写完成上述文件后请打印并加盖公章后将扫描件发送至 ：admin@masuit.com</p><p>9、注意 : 仅上述邮箱接受删改请求、仅支持通过邮箱联系(便于日后查证)</p><h3>注：</h3><p>1、为保证本站正常运作，凡是无法提供完整证明文件的请求本站一律不予处理，请谅解;</p><p>2、因时间精力有限，凡是无法提供完整证明文件的请求本站均不会回复邮件，请谅解;</p><p>3、符合删改条件的请求本站会在72小时内进行处理，无论是否按照“您”的要求删改页面，我们均会通过邮件回复“您”;</p><p><span style=\"color: rgb(255, 0, 0);\">4、本站不接受任何付费删帖、亦未授权任何代理公司负责删帖，请勿轻信任何谣传谨防上当受骗！</span></p><p><span style=\"color: rgb(255, 0, 0);\">5.&nbsp; 在您提醒本站删帖前，本站不接受任何法律控诉</span></p><h3>国家版权局发布的示范格式：</h3><p>《要求删除或断开链接侵权网络内容的通知》：<a href=\"http://kg.qq.com/document/rights/001.pdf\" target=\"_blank\" textvalue=\"http://kg.qq.com/document/rights/001.pdf\">http://kg.qq.com/document/rights/001.pdf</a></p><p>《要求删除或断开链接侵权网络内容的通知》填写说明：<a href=\"http://kg.qq.com/document/rights/002.pdf\" target=\"_blank\" textvalue=\"http://kg.qq.com/document/rights/002.pdf\">http://kg.qq.com/document/rights/002.pdf</a></p><p><span style=\"color: rgb(255, 0, 0);\">请按照此通知格式填写发至站长的邮箱，资料不完整着一律不予受理</span></p><p><br></p>', '2018-09-30 15:27:09.000000', '2020-02-14 20:48:51.758789');
INSERT INTO `misc` VALUES (5, 8, '稀缺资源统一下载地址页', '<p><span style=\"font-size: 24px; color: rgb(255, 0, 0);\">所有用马克丁充当收会员费下载的借口，为了钱，不要脸！</span></p><p>gitlab仓库集合大全，选择其中<span style=\"color: rgb(255, 0, 0);\">任意一个</span>仓库即可：</p><p><a href=\"http://183.91.54.237:7080/masuit/soft/tree/master\" target=\"_blank\" textvalue=\"http://183.91.54.237:7080/masuit/soft/tree/master\">http://183.91.54.237:7080/masuit/soft/tree/master</a></p><p><br></p><p style=\"white-space: normal;\"><a href=\"https://www.fxxkmakeding.xyz/\" target=\"_blank\" textvalue=\"https://www.fxxkmakeding.xyz/\">https://www.fxxkmakeding.xyz/</a></p><p style=\"white-space: normal;\"><a href=\"https://delivery.yuntu.dev/makeding\" target=\"_blank\" textvalue=\"https://delivery.yuntu.dev/makeding\">https://delivery.yuntu.dev/makeding<br></a></p><p>resilio sync只读密钥：BVZOZL7LF4MJMX5KTR7YGR6APKOZESFFD</p><p><span style=\"color: rgb(255, 0, 0);\"><br></span></p><p><span style=\"color: rgb(255, 0, 0);\">如果有其他小伙伴做了镜像的，欢迎到此共享！<br></span></p><p>一个被和谐了，还有很多个，本页持续更新。</p><p>其他稀缺资源：<a href=\"https://yun.naodai.org/Software/\" target=\"_blank\" textvalue=\"https://yun.naodai.org/Software/\">https://yun.naodai.org/Software/</a><br></p>', '2018-11-04 14:00:20.000000', '2020-01-21 22:06:52.362304');
INSERT INTO `misc` VALUES (7, 8, '部分已转移到onedrive的学习资源下载', '<p><span style=\"font-size: 20px; color: rgb(255, 0, 0);\">因两个百度网盘账号完全被限制住，没办法再继续通过百度云分享资源，所以本页将作为大家贡献onedrive下载链接过渡专用。同时希望有其他办法的伙伴们，能尽快提供新的解决方案。</span></p><p>部分Python和部分JavaEE视频（感谢 @华夏城）：<a href=\"https://emmmmmm-my.sharepoint.com/:f:/g/personal/gdxbianchen_emmmmmm_onmicrosoft_com/EtvE0dGM-6BAtV6xDWReIVkBNPkiz32YeiDMvH7RfhfF6g?e=HvxvzZ\" target=\"_blank\" textvalue=\"https://emmmmmm-my.sharepoint.com/:f:/g/personal/gdxbianchen_emmmmmm_onmicrosoft_com/EtvE0dGM-6BAtV6xDWReIVkBNPkiz32YeiDMvH7RfhfF6g?e=HvxvzZ\">https://emmmmmm-my.sharepoint.com/:f:/g/personal/gdxbianchen_emmmmmm_onmicrosoft_com/EtvE0dGM-6BAtV6xDWReIVkBNPkiz32YeiDMvH7RfhfF6g?e=HvxvzZ</a></p>', '2019-09-10 08:55:04.624539', '2019-09-10 14:58:41.780789');
INSERT INTO `misc` VALUES (10, 8, 'DMCA', '<p style=\"text-align: center;\"><img src=\"https://git.imweb.io/ldqk0/imgbed/raw/master/2019/10/31/s6u1ztelmubk.jpgresize=300%252C169\"></p><p>很抱歉，如果本站侵犯了你的公司的任何权利。首先，我们不在服务器上托管任何文件。所有文件均由第三方站点托管和管理，因此，如果文件有任何问题，请先尝试与这些网站联系，如果内容存在问题，我们也会将其修改或删除。</p><p>本站符合17 U.S.C. §512条和《数字千年版权法案》( DMCA)。我们的政策是回应任何侵权通知，并根据《数字千年版权法案》(DMCA)和其他适用的知识产权法律采取适当的措施。如果您的受版权保护的内容已发布在本站上，或者通过搜索引擎返回了受版权保护的材料的链接，并且您希望删除该材料，则必须提供书面通讯，其中详细说明了以下部分中列出的信息。请注意，如果您虚假陈述我们网站上列出的侵犯版权的信息，您将承担赔偿责任（包括费用和律师费）。我们建议您首先与律师联系以寻求法律帮助。</p><p><span style=\"color: rgb(255, 0, 0);\">您的版权侵权主张中必须包含以下内容：</span></p><p>•提供被授权人代表涉嫌侵权的专有权所有人行事的证据。</p><p>•提供足够的联系信息，以便我们与您联系。您还必须包括一个有效的电子邮件地址。</p><p>•您必须充分详细地声明声称受到侵权的受版权保护的作品，并包括至少一个搜索词，在该搜索词下材料会出现在masuit.com中。</p><p>•声明投诉方有善意的信念，认为以投诉的方式使用该材料未经版权所有者，其代理人或法律的授权。</p><p>•声明通知中的信息准确无误，并受到伪证处罚，声明申诉方被授权代表据称受到侵犯的专有权的所有人行事。</p><p>•必须由授权人员签署，以代表据称受到侵犯的专有权的所有者行事。</p><p><br></p><p>将书面侵权通知发送到以下地址，并将电子邮件通知发送至admin@masuit.com。</p><p>由于我们的搜索引擎存在问题，我们不能保证所有内容都会被删除，请向我们提供指向每个出版物的直接链接，这些链接侵犯了您的权利。只有在这种情况下，我们才能保证删除所有内容。</p><p>请在1-2个工作日内收到电子邮件回复。请注意，通过电子邮件将您的投诉发送给其他方（例如我们的Internet服务提供商）将不会加快您的请求，并可能由于投诉未正确提交而导致响应延迟。</p><p>但是除此之外，我们始终会谨慎处理dmca消息，如果收到这样的消息，我们将尽快采取适当的措施。我们尊重每家公司及其工作，因此，我们将尽全力帮助100％的解决此类问题。</p>', '2019-10-31 17:55:59.656400', '2020-01-13 17:49:28.530273');
INSERT INTO `misc` VALUES (11, 8, '隐私声明', '<p>感谢您访问本网站和关注。</p><h3 style=\"text-align: center;\">我们尊重您的隐私</h3><p>在本站的业务流程中，非常注重在处理您的个人数据的同时保护您的隐私。我们将根据相应的法律规定，对本网站收集的个人数据进行保密存储。本站对数据保护和信息安全有着严格的要求。本网站中可能包含其它第三方网站的链接，这些链接不受本隐私声明保护，我们建议您在访问这些网站及/或服务前首先了解第三方的隐私声明。</p><h3 style=\"text-align: center;\">收集和处理个人数据</h3><p>在您访问本网站的时候，网站服务器会自动记录您的互联网服务供应商的名称、您通过哪个网站访问、您实际访问的网站、以及您访问的日期和时长。可能会使用cookie和活动脚本（如JavaScript）来追踪访问者的偏好，并相应优化本网站。您可以将浏览器设置为在收到cookie时通知您或拒绝接受cookie。请注意，如果您关闭cookie，那么绝大多数网站的特定栏目可能都会无法正常工作。除非您自愿提供，例如在注册、调查、竞争或执行合同的情况下提供，否则我们不会保存其他个人数据。</p><p>被动信息征集和使用当您浏览网站时，网站可能会使用各种技术，在您未主动提供的情况下搜集某些信息。我们以及我们的第三方服务提供商会以各种方式被动搜集和使用信息，包括：</p><p>- 通过您的浏览器：大多数浏览器都会搜集某些信息，如您的媒体访问控制 (MAC) 地址、计算机类型（Windows 或 Macintosh）、屏幕分辨率、操作系统版本以及互联网浏览器类型和版本。我们可能会搜集类似信息，比如，如果您使用移动设备访问网站，我们会搜集您的设备类型和标识之类。</p><p>- 使用 cookies：Cookies 是直接保存在您所使用的电脑中的信息片段。通过 Cookies，可以搜集诸如浏览器类型、浏览网站所用的时间、访问页面、语言首选项等信息。我们以及我们的服务提供商使用这些信息的原因在于出于安全目的，加快导航、更有效地显示信息，以及在使用网站的同时实现体验个性化。 我们还会使用 cookies 来识别您的电脑或设备，这样能使您在网站使用时更加方便，比如记住您的购物车中已经有哪些东西。此外，我们还利用 cookies 来搜集网站使用率方面的统计信息，以便不断改进网站的设计和功能，了解各人的使用习惯，并帮助我们解决这方面的问题。Cookies 还可以让我们了解哪些广告或产品最合乎您的兴趣，并当您浏览网站时将其显示出来。我们也可能会在网站广告中使用 cookies 来跟踪消费者对我们的广告的反应。</p><p>您可以按照浏览器的使用说明拒绝接收这些 cookies；不过，如果您选择不接受，在使用网站的过程中可能会有所不便。您还可能无法收到那些您所感兴趣和需要的广告或其他产品。如欲了解 cookies 方面的更多内容，请访问&nbsp;<a href=\"http://www.allaboutcookies.org/\" target=\"_blank\" data-cms-ai=\"0\">http://www.allaboutcookies.org</a>。</p><p>- 使用 Flash cookies：使用 Adobe Flash 技术（包括 Flash 本地存储对象，简称“Flash LSOs”）让我们能够提供更符合您需求的信息，便于您进一步访问和使用网站，并搜集和保存更多您在网站使用方面的信息。如果您不希望在电脑中保存 Flash LSO，您可以调整 Flash 播放器的设置，用&nbsp;<a href=\"http://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager07.html\" target=\"_blank\" data-cms-ai=\"0\">Website Storage Settings Panel</a>&nbsp;中的工具来阻止 Flash LSO 保存。 您还可以进入&nbsp;<a href=\"http://www.macromedia.com/support/documentation/en/flashplayer/help/settings_manager03.html\" target=\"_blank\" data-cms-ai=\"0\">Global Storage Settings Panel</a>&nbsp;并按照操作说明来管理 Flash LSO，其中的说明包括：如何删除现有的 Flash LSO（在 Macromedia 网站中被称为“信息”），如何防止在未询问您的情况下将 Flash LSO 存入您的电脑中，以及（对于 Flash Player 8 和更高版本）如何在您浏览网页时阻止本网页操作人员之外的人发来的 Flash LSO 等。需要注意的是，限制 Flash Player 接受 Flash LSO 可能会影响某些 Flash 应用的功能，其中可能包括网站或在线内容所使用的 Flash 应用。</p><p>- 使用像素标签（pixel tag）、网站信标（web beacon或clear GIFs）或其他类似技术：这些技术可能用在某些网页和 HTML 格式的电子邮件信息中，用于跟踪网站用户和电子邮件收件人的行动，衡量营销活动的效果，并对网站的使用率和响应速度进行综合统计。</p><p>- 在线行为广告：使用 cookies、像素标签（pixel tag）、网站信标（web beacon或clear GIFs）或其他类似技术，让我们的第三方供应商在您访问本网站或其他网站或在互联网使用联网功能时，播放关于我方产品和服务的广告。这些供应商可能会将像素标签、网站信标或类似技术植入网站、其他网站或联网功能，并能在您访问本网站或其他网站或使用联网功能时，植入和识别第三方 cookies。 他们可能会根据您在访问本网站或其他网站或使用联网功能时所留下的信息，播放您可能感兴趣的产品和服务广告。</p><p>- IP 地址：您所使用的电脑的 IP 地址是由互联网服务提供商（ISP）自动分配的。当用户访问本网站时，我们的服务器会自动识别 IP 地址，并将其与访问时间和访问的页数一起记录在日志文件中。搜集 IP 地址是互联网上的通行做法，很多网站都是自动进行的。我们使用 IP 地址的目的包括计算网站使用率、帮助诊断服务器问题、网站管理等。</p><p>- 设备信息：我们可能会搜集移动设备方面的信息，如设备的唯一标识。</p><h3 style=\"text-align: center;\">个人数据的使用和披露以及用途规定</h3><p>本站只会将您的个人数据用于网站技术管理、用户体验优化、产品调查等用途，并且仅在必要范围内使用。未经您的许可，我们不会向本站以外的第三方披露您的个人数据。但在下列情况下，我们可能会向本站以外第三方披露您的个人数据：</p><p>（1）获得您的事先同意；</p><p>（2）合法并可执行的法令、法律、传票或其他法规（总称“法令”）要求披露；</p><p>（3）为保障本站合法权利和利益，例如伪调查、恶意使用本站功能、预防和处理欺诈以及安全问题进行披露。</p><h3 style=\"text-align: center;\">安全</h3><p>本站使用了多种安全措施来保护我们拥有的数据不会被操纵、丢失、破坏，防止未经授权的人员访问并组织未经授权的披露。本站将随着新技术的发展不断更新安全程序。</p><h3 style=\"text-align: center;\">服务条款</h3><p>1.本站内容仅提供除中国大陆以外地区的华人华侨同胞交流学习，其他地区请根据当地法律法规酌情考虑使用本站内容。</p><p>2.本站所有内容任何人均可共同参与编辑，本站不对任何内容承担相关的责任和权利。</p><h3 style=\"text-align: center;\">选择自由</h3><p>本站将可能使用您的数据来向您通知本站的相关订阅数据和服务并在适当情况下征求您的意见。您可以自愿参加这样的活动。如果您不同意参加，您可以随时告知我们，我们将相应禁止使用您的数据。</p><h3 style=\"text-align: center;\">修订</h3><p>本站将不时修订本隐私声明，并将在网站显著位置发布相关修订通知，您可以随时访问。</p><h3 style=\"text-align: center;\">联系方式</h3><p>如果您需要了解任何信息，欢迎提出建议，或投诉个人数据处理问题，您可以联系站长。尽管本站已尽力保证数据及时准确，但如果存在任何错误数据，我们将根据您的要求为您更正该信息。</p><p><br></p>', '2019-10-31 18:08:04.978400', '2019-11-07 23:18:24.169718');
INSERT INTO `misc` VALUES (12, 8, '百度网盘学习资料下载地址更新页', '<p style=\"text-align: center;\"><img src=\"https://masuit.oss-cn-beijing.aliyuncs.com/2020/02/20/shwibae8yl8g.jpg\"></p><p><strong><span style=\"font-size: 20px; color: rgb(255, 0, 0);\">请仔细阅读以下内容，若未仔细阅读以下内容私信的问题一律不回复！</span></strong></p><p style=\"text-align: left;\"><span style=\"font-size: 20px;\">请务必使用<span style=\"font-size: 20px; color: rgb(255, 0, 0);\">最新版</span>的<span style=\"font-size: 20px; color: rgb(255, 0, 0);\">百度网盘app</span>扫描上面的二维码即可进群，若无法扫描二维码，可尝试手动输入上面的<span style=\"font-size: 20px; color: rgb(255, 0, 0);\">群号</span>添加。<br></span></p><p style=\"text-align: left;\"><span style=\"font-size: 20px;\">进群后资料自取，因为每个群只能容纳200人，建议找到自己想要的资料后，转存到自己的网盘上，然后退群，将来再有需要时可重新加群取资料，请尽量把名额留给其他更有需要的人。</span></p><p style=\"text-align: left;\"><span style=\"font-size: 20px;\">如果上面的二维码无法添加，请通过QQ：</span><a href=\"https://wpa.qq.com/msgrd?v=3&uin=3444764617&site=qq&menu=yes\" target=\"_blank\" style=\"text-decoration: underline; font-size: 20px;\"><span style=\"font-size: 20px;\">3444764617</span></a><span style=\"font-size: 20px;\">或邮箱：</span><a href=\"https://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=admin@masuit.com\" target=\"_blank\" style=\"text-decoration: underline; font-size: 20px;\"><span style=\"font-size: 20px;\">admin@masuit.com</span></a><span style=\"font-size: 20px;\">私信联系我（需注明二维码无法添加，附上截图）。</span></p><p style=\"text-align: left;\"><span style=\"font-size: 20px;\">注意：<span style=\"font-size: 20px;\">正常情况下群内会有以下两个文件夹，</span>如果群里有丢失资源，请在群里留言备注，我看到消息后会补档的，私信一律不回复和处理！</span></p><p style=\"text-align: center;\"><span style=\"font-size: 20px;\"><img src=\"https://git.imweb.io/guomo/imgbed/raw/master/2019/12/24/sc6q2ptgegow.png\"></span></p><p style=\"text-align: left;\"><span style=\"font-size: 20px; text-decoration: underline;\">博主个人精力有限，无法及时的照顾到每一个人，<span style=\"text-decoration: underline; font-size: 20px; color: rgb(255, 0, 0);\">请保持耐心</span>，不要催如果你连最基本的耐心都没有，那你不是一个适合学习的人，将来也不会是一个合格的程序员！！！</span></p><p style=\"text-align: left;\"><span style=\"color: rgb(255, 0, 0); font-size: 20px;\">百度网盘群只作为编程类学习资源的分享用途，请合理使用群资源，因网盘每个群名额有限，请有真实需要的才加，每人只能添加一个群，感谢大家的配合和理解！</span></p><p style=\"text-align: left;\"><span style=\"color: rgb(255, 0, 0); font-size: 20px;\"><br></span></p><p style=\"text-align: left;\"><span style=\"color: rgb(255, 0, 0); background-color: rgb(255, 255, 0); font-size: 24px;\">若发现同一id出现在1个群以上的，将拉黑处理！</span></p>', '2019-12-22 16:37:28.952148', '2020-02-20 09:55:28.795898');

-- ----------------------------
-- Table structure for notice
-- ----------------------------
DROP TABLE IF EXISTS `notice`;
CREATE TABLE `notice`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `PostDate` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `ModifyDate` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `ViewCount` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `ModifyDate`(`ModifyDate`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 87 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of notice
-- ----------------------------
INSERT INTO `notice` VALUES (22, 8, '特别说明', '<p><span style=\"font-size: 18px;\">本站所有下载资源<span style=\"color: rgb(255, 0, 0);\">不收任何费用</span>，网站提供的自愿</span><a href=\"/donate\" target=\"_blank\" style=\"font-size: 18px; text-decoration: underline;\"><span style=\"font-size: 18px;\">打赏或捐赠</span></a><span style=\"font-size: 18px;\">仅为网站服务支持，<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">鄙视一切薅完正版商羊毛又薅老百姓99元的行为。</span>一切二次收费都是个人谋取暴利的借口，欢迎有能力的朋友共享稀缺资源，可在</span><a href=\"http://masuit.com/post/publish\" target=\"_self\" textvalue=\"http://masuit.com/post/publish\" style=\"font-size: 18px; text-decoration: underline;\"><span style=\"font-size: 18px;\">http://masuit.com/post/publish</span></a><span style=\"font-size: 18px;\">进行投稿，互联网分享精神，专注收藏与分享。你薅群众，我就薅你。<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">所有软件下载均为个人使用，请勿用于商业用途！</span>支持正版请一定<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">认准官网</span>，所谓的中文官网如果页脚标注为<span style=\"color: rgb(255, 0, 0); font-size: 20px;\">“苏州XXX”</span>的均为盗版官网！</span></p>', '2018-05-30 19:43:08.000000', '2018-10-28 16:51:05.000000', 11927);
INSERT INTO `notice` VALUES (48, 8, '关于破解！', '<p><span style=\"font-size: 18px;\">很多网友经常反映说在这儿下载的有些软件被<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">数字卫士、企鹅管家、Defender</span>等杀软报毒，博主在此强调一下，既然是破解软件，那就不免会有一些杀软报毒的情况，<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">站内99%以上的软件都是经过博主亲自测试过再分享出来的，博主自用杀软为火绒</span>。</span></p><p><span style=\"font-size: 18px;\">有些软件也是博主深度使用的，诸如：TeamViewer、KMS激活工具、PrimoCache、aida64、腾讯QQ等，我用着到目前是没出现过任何问题的，但也并<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">不保证在你的机器上不会出问题，博主也不是专职做软件测试，不能保证权威，使用破解软件造成的任何损失后果自负</span>，毕竟是破解软件，如果心存疑虑，建议还是<a href=\"https://partner.lizhi.io/ldqk/cp\" target=\"_blank\">购买正版</a>享受官方支持服务！</span></p><p><span style=\"font-size: 18px;\">或许你们也会说Defender是微软自家的，没有谁比微软更了解自己，但报毒的几句英文信息请仔细分析一下，<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">村通网并不可怕。如果九年义务教育还看不懂报毒的英文的话，那还是<a href=\"https://partner.lizhi.io/ldqk/cp\" target=\"_blank\">购买正版</a>吧</span>！</span></p>', '2019-05-19 17:59:02.660000', '2019-06-24 09:59:01.481186', 184524);
INSERT INTO `notice` VALUES (50, 8, '关于网站下载资源分发的决定', '<p>经过了大家几天的投票，共1033人参与投票决定，既然是大家共同决定的，那就尊重大家的选择，以占有率决定，后期的资源分发如下决定：</p><p>1.100MB以下的资源-&gt;<span style=\"color: rgb(255, 0, 0);\">蓝奏云</span>；</p><p>2.大于100MB-&gt;<span style=\"color: rgb(255, 0, 0);\">百度云</span>；</p><p>3.小于100MB的敏感资源-&gt;<span style=\"color: rgb(255, 0, 0);\">gaylab</span>；</p><p>4.大于100MB的敏感资源-&gt;<span style=\"color: rgb(255, 0, 0);\">OneDrive或百度云</span>；</p><p>既然大家这么信任百度云，那后期的大资源还是放百度云吧，怎么下载就各显神通吧</p><p><img src=\"https://masuit.oss-cn-beijing.aliyuncs.com/20190601/rrshafb2v9j4.png\"/></p>', '2019-06-01 23:18:19.719418', '2019-06-01 23:20:19.833161', 4809);
INSERT INTO `notice` VALUES (52, 8, '关于网站下载资源分发的重新决定', '<p><span style=\"font-size: 18px;\">综合</span><a href=\"/n/50\" target=\"_blank\" style=\"font-size: 18px; text-decoration: underline;\"><span style=\"font-size: 18px;\">上次的投票结果</span></a><span style=\"font-size: 18px;\">，最新的源分发如下决定：</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">1.100MB以下的资源-&gt;<span style=\"color: rgb(255, 0, 0);\">蓝奏云</span>；</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">2.100MB到1GB的资源-&gt;<span style=\"color: rgb(255, 0, 0); font-size: 18px;\">mirrored或zippyshare</span>；</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">3.大于1GB的资源-&gt;<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">OneDrive</span>；</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">4.小于100MB的敏感资源-&gt;<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">gaylab</span>；</span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\">5.<span style=\"font-size: 18px;\">100MB到1GB的</span><span style=\"font-size: 18px;\">敏感资源-&gt;</span><span style=\"font-size: 18px; color: rgb(255, 0, 0);\"><span style=\"color: rgb(255, 0, 0); font-size: 18px;\">mirrored<span style=\"color: rgb(255, 0, 0); font-size: 18px;\">或zippyshare</span></span></span><span style=\"font-size: 18px;\">；</span></span></p><p style=\"white-space: normal;\"><span style=\"font-size: 18px;\"><span style=\"font-size: 18px;\">6.大于1GB的</span>敏感资源-&gt;<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">OneDrive(优先)或百度云(当无法下载转存到onedrive的时候)</span>；</span></p><p><span style=\"font-size: 18px;\">温馨提示：</span><span style=\"font-size: 18px; color: rgb(255, 0, 0);\">当资源的大小在500MB~1GB的时候，还是可以考虑分卷上传到<span style=\"color: rgb(255, 0, 0); font-size: 18px;\">mirrored</span><span style=\"color: rgb(255, 0, 0); font-size: 18px;\">或</span><span style=\"color: rgb(255, 0, 0); font-size: 18px;\">zippyshare</span>的。</span></p><p><span style=\"font-size: 18px; color: rgb(255, 0, 0);\">另外，</span><span style=\"font-size: 18px;\"><a href=\"https://chrome.google.com/webstore/detail/adblock/gighmmpiobklfepjocnamgkkbiglidom?hl=zh-CN\" target=\"_blank\"><span style=\"font-size: 24px;\">老是有人说mirrored或zippyshare下载时弹广告的，麻烦给你的浏览器去下广告！</span></a></span><span style=\"font-size: 18px; color: rgb(255, 0, 0);\"><span style=\"color: rgb(255, 0, 0); font-size: 24px;\">字太小你们总是眼瞎的！</span></span><span style=\"font-size: 24px; color: rgb(255, 0, 0);\">这么大的字再看不见那是真眼瞎了！</span></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20190605/6369533832717773441174362.png\"></p>', '2019-06-05 13:38:51.302734', '2019-06-19 10:05:52.433135', 73513);
INSERT INTO `notice` VALUES (59, 8, '继续公开处刑', '<p><span style=\"font-size: 20px;\">继上次QQ号是<span style=\"font-size: 20px; color: rgb(255, 0, 0);\">1741780042</span>冒充博主本人进行倒卖FL&nbsp;Studio被大家公开处刑之后，有网友继续深入了解到，与此关联的还有QQ：<span style=\"font-size: 20px; color: rgb(255, 0, 0);\">2103201633</span>和<span style=\"font-size: 20px; color: rgb(255, 0, 0);\">3441999729</span>，经断定，是同一个人，连头像和个性签名都一样，且都是新注册的小号，所以，大家继续来搞他吧！</span></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20190812/6370124948325760004352814.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20190812/6370124966406160006253255.png\"></p>', '2019-08-12 23:34:47.742400', '2019-08-12 23:34:47.742400', 68406);
INSERT INTO `notice` VALUES (70, 8, '求资源收录', '<p><span style=\"font-size: 20px;\">目前本站还未收录的软件，希望有资源的老哥些可以分享下。</span></p><p><strong><span style=\"color: rgb(255, 0, 0); font-size: 18px;\">1.imindmap 11</span></strong></p><p><strong><span style=\"color: rgb(255, 0, 0); font-size: 18px;\">2.</span></strong><strong><span style=\"color: rgb(255, 0, 0); font-size: 18px;\">Ear&nbsp;Master 7</span></strong></p>', '2019-10-02 22:57:22.456875', '2020-01-13 11:30:07.762695', 357957);
INSERT INTO `notice` VALUES (74, 8, '信杀软，无破解！', '<p><span style=\"font-size: 18px;\">最近老是接到很多访客投诉说本站资源报毒的问题，这种问题请添加到允许信任就可以了。<span style=\"color: rgb(255, 0, 0);\">本站所提供的任何二进制文件均不具备权威性</span>，如需体验官方正版，请从相应的官网渠道下载，请悉知！村通网并不可怕。如果九年义务教育还看不懂报毒的英文的话，请购买正版。信杀软，无破解！</span><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191124/s980e0hxup6o.png\"></p>', '2019-11-24 20:07:53.389875', '2019-12-29 11:23:19.875000', 18859);
INSERT INTO `notice` VALUES (75, 8, '喜报！', '<p><span style=\"font-size: 18px;\">因博主个人精力有限，所以为了照顾更多的小白朋友，本站目前已经跟<span style=\"color: rgb(255, 0, 0); font-size: 24px;\">百度</span>和<span style=\"color: rgb(255, 0, 0); font-size: 20px;\">Google</span>两大公司达成深度和长期的合作关系，将来大家在本站遇到的任何问题，均可随时随地的使用这两家公司提供的服务帮助解决你的问题，并且大多数时候能够秒解你的问题，关键还是<span style=\"color: rgb(255, 0, 0); font-size: 20px;\">免费</span>的哦！如果他们最后实在是解决不了你的问题，再向本站站长寻求帮助，<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">在你询问之前，也请先尝试本站的站内搜索以及自己动手尝试一下</span>，理解万岁！</span></p><p><span style=\"font-size: 20px;\">百度：</span><a href=\"https://www.baidu.com/\" target=\"_blank\" textvalue=\"https://www.baidu.com/\" style=\"font-size: 20px; text-decoration: underline;\"><span style=\"font-size: 20px;\">https://www.baidu.com/</span></a></p><p><span style=\"font-size: 20px;\">Google：</span><a href=\"https://www.google.com/\" target=\"_blank\" textvalue=\"https://www.google.com/\" style=\"font-size: 20px; text-decoration: underline;\"><span style=\"font-size: 20px;\">https://www.google.com/</span></a></p>', '2019-12-06 23:01:33.409179', '2020-02-17 23:55:33.444336', 158355);
INSERT INTO `notice` VALUES (78, 8, '作死公告！', '<p><span style=\"font-size: 18px;\">因博主圣诞期间在网站首页推送了一段<a href=\"/n/77\" target=\"_blank\">哲♂学性♂诞小视频</a>，未能准确预估视频流量，导致网站OSS图床流量耗尽，所以网站的<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">部分图片</span>在本月接下来的几天中将<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">无法正常显示</span>，升级流量费用太<span style=\"font-size: 18px; color: rgb(255, 0, 0);\">贵</span>，也懒得搬图片，坐等明年恢复吧。</span></p><p style=\"text-align: center;\"><img src=\"https://git.imweb.io/guomo/imgbed/raw/master/2019/12/25/scb2i1f2lvcw.jpg\"></p>', '2019-12-25 23:02:53.612304', '2019-12-29 11:23:26.849609', 26126);
INSERT INTO `notice` VALUES (87, 8, '你希望每篇文章页内放妹子图么？', '<p>你希望每篇文章页内放妹子图么？来投票表决，收集1000条反馈！</p><p><a href=\"http://hk.mikecrm.com/ApcC4R3\" target=\"_blank\" textvalue=\"http://hk.mikecrm.com/ApcC4R3\">http://hk.mikecrm.com/ApcC4R3</a></p>', '2020-03-07 20:33:23.619140', '2020-03-07 20:33:23.619140', 5238);

-- ----------------------------
-- Table structure for post
-- ----------------------------
DROP TABLE IF EXISTS `post`;
CREATE TABLE `post`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Author` varchar(24) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ProtectContent` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `PostDate` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `ModifyDate` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `IsFixedTop` bit(1) NOT NULL DEFAULT b'0',
  `CategoryId` int(11) NOT NULL,
  `Email` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Modifier` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `ModifierEmail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `Label` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `Keyword` varchar(256) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `VoteUpCount` int(11) NOT NULL DEFAULT 0,
  `VoteDownCount` int(11) NOT NULL DEFAULT 0,
  `AverageViewCount` double NOT NULL DEFAULT 0,
  `TotalViewCount` int(11) NOT NULL DEFAULT 0,
  `IP` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `DisableComment` bit(1) NOT NULL DEFAULT b'0',
  `DisableCopy` bit(1) NOT NULL DEFAULT b'0',
  `LimitMode` tinyint(4) NULL DEFAULT NULL,
  `Regions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `ExceptRegions` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `IX_Post_CategoryId`(`CategoryId`) USING BTREE,
  CONSTRAINT `FK_Post_Category_CategoryId` FOREIGN KEY (`CategoryId`) REFERENCES `category` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of post
-- ----------------------------
INSERT INTO `post` VALUES (1671, 5, '永久使用及更新！Wise Care 365 Pro 系统优化清理软件 -软购商城1PC终身版仅需 99 元！', '懒得勤快', '<p style=\"text-align: center;\"><img src=\"https://git.imweb.io/si/imgbed/raw/master/2020/01/09/sdrzglp5vn5s.jpg\" class=\"meizi\"></p><p style=\"text-align: center;\">▲赵惟依</p><p>Wise Care 365 Windows 系统清理和加速工具，由本站和 APSGO 软购商城推荐的官方正版特价！终身版！一次购买终身使用！</p><p>清理注册表和磁盘垃圾文件，保护个人隐私记录，提高电脑使用安全。优化系统、提高Windows系统运行速度最好的选择！提高 Windows 电脑速度的安全、稳定的解决方案 -让你的电脑时刻保持巅峰状态。</p><figure><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191204/sa6fk844pvk0.png\"></figure><h3>全球超过 70,000,000 用户</h3><p>智慧清理产品 – 稳定，安全，加快 Windows 运行速度。</p><h3>实时保护系统</h3><p>实时保护注册表不被其他程序未经许可地秘密修改。例如阻止程序更改您的浏览器主页，阻止任何不需要的新应用程序添加到 Windows 启动项，阻止其他程序更改默认浏览器。</p><h3>多功能清理</h3><p>Wise Care 365 绝对是数十亿 Windows 用户提高电脑性能释放磁盘空间的首选工具。它可以清理无效的 Windows 注册表项，清除无用的文件，下载历史记录，浏览历史记录，无效快捷方式，浏览历史，缓存，Cookie，密码，Windows 组件和具有特定扩展名的文件。它还为高级用户提供可定制的清理选项。</p><h3>系统优化</h3><p>Wise Care 365 通过系统优化 、磁盘碎片整理、Windows 注册表整理和管理启动项里的进程与服务等对电脑进行全方面的优化。随着时间的推移，您的计算机的磁盘驱动器和注册表将变得混乱。Wise Care 365 可以对磁盘和注册表进行碎片整理，使其有条不紊，从而使您的计算机运行更快，更稳定。您会惊讶于被它灭掉碎片的速度如此之快。许多程序在您启动计算机时在后台默默运行。 Wise Care 365 可以帮助您禁用掉您不需要的程序，从而避免它们消耗您宝贵的系统资源，并以此提高 PC 的启动速度。</p><h3>隐私保护</h3><p>Wise Care 365 里的隐私擦除，磁盘擦除和文件粉碎工具可以全方面保护用户隐私不被盗取。隐私擦除功能会删除计算机操作的任何痕迹，如浏览历史和访问的文件，使得您执行的任何计算机操作都将被保密。磁盘擦除功能可防止第三方恢复已删除的数据。文件粉碎功能可以彻底删除文件，以便它们永远不能被恢复。</p><h3>系统和硬件监控</h3><p>系统监视可以显示计算机的所有基本信息。进程监视为用户提供了一个清晰而整洁的列表，列出了用户和系统运行的所有进程，用户可以关闭任何不需要的过程，使 PC 运行更流畅。硬件概述为用户提供所有关键硬件组件的简明详细的信息，让用户对自己的计算机一目了然。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191204/sa6fk844pvk1.png\"></p><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><p>本次活动由本站联合软购正版软件商城共同举办！！</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p><span style=\"color: rgb(255, 0, 0);\">Wise Care 365 Pro 1年1台电脑：官方原价：69.00元&nbsp;联合软购商城特价活动价：49.00 元！</span></p></li><li><p><span style=\"color: rgb(255, 0, 0);\">Wise Care 365 Pro 永久版1台电脑：官方原价：483.00元&nbsp;联合软购商城特价活动价：99.00 元！</span></p></li></ul><h3>独家专属30元优惠券：优惠码：ldqkWise30</h3><p>软购商城特价购买地址：&nbsp;<a href=\"https://apsgo.com/store/product/wise-care-365-pro/?id=2\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/wise-care-365-pro/?id=2\">https://apsgo.com/store/product/wise-care-365-pro/?id=2</a></p>', NULL, '2019-11-18 12:23:38.166867', '2020-02-18 23:28:09.125976', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, 'null', 0, 0, 13.342139891093474, 1484, '222.209.11.130', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1675, 5, '官方授权正版 PDF Reader Pro for Mac PDF编辑阅读工具软件', '懒得勤快', '<p>PDF Reader Pro for Mac PDF编辑阅读工具软件 由本站和 APSGO 软购商城推荐的官方正版特价！终身版！一次购买终身使用！</p><p>PDF Reader Pro 是一款功能齐全且强大的 All In One PDF阅读和编辑软件。支持PDF阅读、批注、PDF编辑、PDF格式转换、创建PDF、OCR、创建/填写表单和签署合同、合并/拆分PDF文件、加密保护等，满足您的所有PDF文档需求。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy0c703vuo.png\"></p><p>PDF Reader Pro 比预览 APP 功能更丰富强大，比 Adobe 专业 PDF软件更轻量级和易于使用。PDF Reader Pro界面简洁清晰，您可以轻松在您的Mac电脑上查看，注释，管理页面，插入图片，链接，页眉页脚，水印，添加/编辑大纲，导出注释，打印，将PDF转换为Word/Excel/PPT等可编辑的文件格式等，是一款专业又精致轻便的PDF编辑器。</p><p>PDF Reader Pro支持 Mac, iPad, iPhone, Android, Windows 等平台，随时随地处理PDF文件，提高工作效率。PDF Reader Pro for Mac为目前Mac AppStore中下载量最多的PDF类软件。</p><p>PDF Reader Pro 支持7天免费试用，专门的教育折扣和批量购买优惠。</p><p>PDF Reader Pro 深受全球7千万用户的喜爱，是处理PDF文件的PDF专家。</p><h3>主要功能：</h3><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>高效阅读<br style=\"box-sizing: border-box;\">– 多页签，单窗口打开多个PDF文件，方便切换，对比阅读<br style=\"box-sizing: border-box;\">– 全屏阅读，或页面适应，水平/垂直方向滑动阅读页面，设置页面自动滚动等查看文件<br style=\"box-sizing: border-box;\">– 夜间模式 – 支持自定义阅读背景颜色，日间，夜间，护眼等主题自由切换，舒适眼睛<br style=\"box-sizing: border-box;\">– 幻灯片模式演示您PDF文件，将您的PDF以PPT的形式呈现<br style=\"box-sizing: border-box;\">– 创建，编辑和搜索大纲/目录，跳转指定页面，轻松浏览整个文件<br style=\"box-sizing: border-box;\">– 为PDF的特定页面或部分添加书签，支持书签跳转指定页面</p></li></ul><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy0l98chkw.png\"></p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>轻松注释<br style=\"box-sizing: border-box;\">– 基础注释: 高亮、下划线、删除线、手绘，形状（矩形/圆形/箭头/直线）等标记文件内容，可连续添加标注，支持更改注释颜色，透明度，粗细等属性<br style=\"box-sizing: border-box;\">– 批注工具: 文本框、便签、签名等标注PDF，随时记录想法，摘要<br style=\"box-sizing: border-box;\">– 签名: 使用触控板，键盘或图片创建签名，可创建多个签名<br style=\"box-sizing: border-box;\">– 图章: 添加标准图章(APPROVED/FINAL等)、自定图片图章或文字图章、动态图章，让您的文件更专业，更安全<br style=\"box-sizing: border-box;\">– 链接: 添加URL网页超链接，email邮箱或者文档页码，可根据需要编辑链接<br style=\"box-sizing: border-box;\">– 表格: 创建/绘制表格，轻松编辑表格数据</p></li></ul><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy0qsnqneo.png\"></p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><ul style=\"list-style-type: square;\" class=\"custom_dash list-paddingleft-1\"><li class=\"list-dash list-dash-paddingleft\"><p>填写Form表单<br style=\"box-sizing: border-box;\">– 创建和编辑表单。创建可填写的PDF表单，例如按钮，复选框，单选按钮，列表框和下拉列表等<br style=\"box-sizing: border-box;\">– 处理由Adobe Acrobat创建的静态PDF表单，如税务单，发票，简历等</p></li></ul><li><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy0w9xpyio.png\"></p></li><ul style=\"list-style-type: square;\" class=\"custom_dash list-paddingleft-1\"><li class=\"list-dash list-dash-paddingleft\"><p>PDF格式转换<br style=\"box-sizing: border-box;\">– 离线将PDF转换为Microsoft Word（.docx），PowerPoint（.pptx），Excel（.xlsx），RTF，HTML，文本，图像，CSV等. 支持本地转换，无需联网<br style=\"box-sizing: border-box;\">– 将从Scanner扫描仪导入的图片或和TXT等格式文件转换为PDF文档</p></li></ul><li><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy061xle68.png\"></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy061xle68.png\"></p></li><ul style=\"list-style-type: square;\" class=\"custom_dash list-paddingleft-1\"><li class=\"list-dash list-dash-paddingleft\"><p>页面编辑/重组<br style=\"box-sizing: border-box;\">– 合并和拆分: 将一个文件拆分为多个文件或多个页面合并为一个新的PDF<br style=\"box-sizing: border-box;\">– 提取: 选中单个或多个页面，提取保存为新的PDF文件。可直接拖出到桌面自动保存<br style=\"box-sizing: border-box;\">– 插入: 将另一个文件（整个文件或特定页面范围）插入到现有文件，保存为新文件<br style=\"box-sizing: border-box;\">– 旋转，删除，倒序，替换和复制页面</p></li><li class=\"list-dash list-dash-paddingleft\"><p>PDF编辑<br style=\"box-sizing: border-box;\">– 水印: 添加/移除水印，自定义文字，颜色，字号，旋转角度，位置等，确保您文件安全性和专业性<br style=\"box-sizing: border-box;\">– 页眉和页脚/页码: 使用自定义的页码标记PDF文档的每一个页面。更改字符串中的字体类型，大小，颜色和位置等<br style=\"box-sizing: border-box;\">– Bates贝茨码: 从您的法律文件中识别和检索信息。添加唯一的前缀或后缀，可以是数字，案例号，公司名称或日期<br style=\"box-sizing: border-box;\">– 小册子: 小册子将您的页面并列并重新排序，无论您使用何种打印机，<br style=\"box-sizing: border-box;\">都可以进行小册子打印<br style=\"box-sizing: border-box;\">– 海报: 将大型PDF页面分成打印成多个小页面<br style=\"box-sizing: border-box;\">– 多页: 您可以将一张纸打印为多页PDF<br style=\"box-sizing: border-box;\">– 创建PDF副本，使他人无法编辑您的文件</p></li></ul><li><p>OCR识别<br style=\"box-sizing: border-box;\">– 将扫描的PDF文件或图片转换为可编辑的PDF或TXT文件。支持50多种语言，99%以上的准确率。需要网络访问</p></li></ul><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy0j8lsrnk.png\"></p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><ul style=\"list-style-type: square;\" class=\"custom_dash list-paddingleft-1\"><li class=\"list-dash list-dash-paddingleft\"><p>文件安全<br style=\"box-sizing: border-box;\">– 加密保护: 设置PDF密码保护敏感文档，并且可以设置编辑，复制，修改或打印等PDF权限设置</p></li><li class=\"list-dash list-dash-paddingleft\"><p>PDF容量压缩<br style=\"box-sizing: border-box;\">– 减小PDF大小，使文档更轻便</p></li><li class=\"list-dash list-dash-paddingleft\"><p>TTS（文字转语音）<br style=\"box-sizing: border-box;\">– 使用文本转语音（TTS），让PDF Reader Pro Edition使用40多种不同语言为您阅读文档，简化阅读</p></li><li class=\"list-dash list-dash-paddingleft\"><p>分享<br style=\"box-sizing: border-box;\">– 只需点击一下，即可将文件上传到Dropbox，iCloud Drive等</p></li></ul><li><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy0snviadc.png\"></p></li></ul><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><p>本次活动由本站联合软购正版软件商城共同举办！！</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>PDF Reader Pro for Mac PDF编辑阅读工具软件，官方原价：423元，联合软购特价仅需：170元（用券后）！一次购买终身使用！</p></li></ul><h3>独家专属10元优惠券：ldqk10</h3><p>软购商城特价购买地址：<a href=\"https://apsgo.com/store/product/pdfreaderpro/?id=2\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/pdfreaderpro/?id=2\">https://apsgo.com/store/product/pdfreaderpro/?id=2</a></p>', NULL, '2019-11-22 13:47:49.452875', '2020-03-05 17:49:05.015625', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, 'pdf', 0, 0, 8.617164851703558, 924, '172.68.253.81', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1676, 5, '官方正版授权特价！威力导演 18 极致版/旗舰版 视频剪辑工具软件', '懒得勤快', '<p style=\"text-align: center;\"><img src=\"https://git.imweb.io/si/imgbed/raw/master/2020/01/24/sf8gffncmio0.jpg\">▲米妮大萌萌</p><hr><p>威力导演 18 由本站和 APSGO 软购商城推荐的官方正版特价！终身版！一次购买终身使用！</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy75onv1fk.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy77wx3lds.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy79nrjmkg.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7bbcmfi8.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7cxw8r9c.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7es020ow.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7g1i7fgg.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7hd89la8.png\"></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7aw5qnsw.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7ca17ocg.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7dlr9u68.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7eu5gveo.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7gsmlqm8.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7i38piww.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7j7c2ups.png\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191122/s8zy7kcjek1s.png\"></p><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><p>本次活动由本站联合软购正版软件商城共同举办！！</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>威力导演 18 -为你量身打造的视频剪辑工具。功能强大、简单易用，让创意尽情发挥！</p></li><li><p>官方授权经销商查询：<a href=\"https://cn.cyberlink.com/stat/company/chs/reps_china.jsp\" target=\"_blank\">https://cn.cyberlink.com/stat/company/chs/reps_china.jsp</a></p></li></ul><h3>独家专属优惠券：ldqk10，ldqk5</h3><p>软购商城特价购买地址：<a href=\"https://apsgo.com/store/product/powerdirector/?id=2\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/powerdirector/?id=2\">https://apsgo.com/store/product/powerdirector/?id=2</a></p>', NULL, '2019-11-22 13:50:07.515375', '2020-01-23 13:37:52.399414', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, '威力导演', 0, 0, 5.712914130605227, 610, '203.218.143.46', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1679, 5, '专业人士必备深层清理卸载工具 -Total Uninstall 官方授权软购特价购买', '懒得勤快', '<p>Total Uninstall PC专业清理卸载工具由本站和 APSGO 软购商城推荐的官方正版特价！终身版！一次购买终身使用！</p><p>Total Uninstall 是一款包含两个工作模块的全能卸载工具。</p><p>Total Uninstall 中文官方网站：<a href=\"https://total-uninstall.cn/\" target=\"_blank\" rel=\"noopener noreferrer\">https://total-uninstall.cn</a></p><p>已安装程序&nbsp;模块用于分析现有已安装程序并创建安装日志。 甚至不依靠程序自身的卸载功能，Total Uninstall 也能彻底卸载您不需要的程序。<br style=\"box-sizing: border-box;\">您所要做的就是从已安装程序列表中选择要卸载的程序，Total Uninstall 会在几秒内完成分析，并以树状视图的形式显示要删除的文件、文件夹、注册表项以及注册表项值。 您可以通过查看分析结果的详细信息，移除您不需要的项目。 Total Uninstall 卸载已分析的程序时， 将优先使用程序自身的卸载程序，然后再使用卸载日志移除其他残留的内容。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191125/s9b8bo0xxpfk.png\"></p><p>已监控程序&nbsp;模块用于监控新程序安装期间对系统所做的更改。 在没有自身卸载程序帮助的情况下彻底删除程序留下的文件。<br style=\"box-sizing: border-box;\">Total Uninstall 在新程序安装前，先创建一次系统快照。 程序安装完成后，再创建一次系统快照。 然后对比前后两个系统快照，以树状视图形式显示全部更改。标记所有已添加的、更改的和删除的注册表项和文件。 Total Uninstall 会保存这些更改，如果您决定卸载这些程序，那么它就会还原系统到卸载之前的状态。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191125/s9b8byh1nbpc.png\"></p><h3>Total Uninstall 可以轻松移除任何程序</h3><p>精确分析已安装程序</p><p>使用 Total Uninstall 的“已安装程序”模块可以分析已安装程序并创建安装日志。这可用于执行彻底的程序卸载，即使没有自身卸载程序的帮助。</p><p>监视新程序的安装过程</p><p>使用 Total Uninstall 的“已监视程序” 模块可以帮助您监视新安装程序对您系统所做的更改。 便于您在没有自身卸载程序帮助的情况下彻底删除程序留下的文件。</p><p>安全清理系统</p><p>移除多余的文件和注册表项目</p><p>Autorun Manager handles start-up.</p><p>管理 Windows 启动过程。控制随系统自启动的程序，服务和计划任务。 通过禁用不想要的自启动程序，使操作系统运行的更快速。</p><p>转移程序到新 PC 上</p><p>此功能与独立程序同等重要。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191125/s9b8bvxyults.png\"></p><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><h3>本次活动由本站联合软购正版软件商城共同举办！！</h3><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>Total Uninstall PC专业卸载清理工具 -一次购买终身享用！-官方授权代理商！官网直发授权，绑定您的邮箱和用户名！</p></li></ul><h3>独家专属优惠券：ldqk10，ldqk5</h3><p>软购商城特价购买地址：<a href=\"https://apsgo.com/store/product/total-uninstall/?id=2\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/total-uninstall/?id=2\">https://apsgo.com/store/product/total-uninstall/?id=2</a></p><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><p><br data-rich-text-line-break=\"true\" style=\"box-sizing: border-box;\">还在犹豫是否需要购买？没关系，请从这里下载安装免费先体验再说！</p><p><a href=\"https://masuit.com/84\" target=\"_blank\" textvalue=\"https://masuit.com/84\">https://masuit.com/84</a></p>', NULL, '2019-11-25 17:43:07.779164', '2020-01-19 21:16:18.315429', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, 'null', 0, 0, 10.187995051657703, 1059, '172.68.253.81', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1680, 5, '官方正版特价！Internet Download Manager IDM 下载神器 -软购商城', '懒得勤快', '<p style=\"text-align: center;\"><img src=\"https://git.imweb.io/si/imgbed/raw/master/2020/01/02/6371359616833105467862600.jpg\" class=\"meizi\"></p><p style=\"text-align: center;\">▲湘湘</p><p>由本站和 APSGO 软购商城推荐的官方正版特价！终身版！一次购买终身使用！</p><p>Internet Download Manager IDM 下载器是一款先进的下载工具,可以提升您的下载速度高达5倍,支持续传，IDM 可以让用户自动下载某些类型的文件，它可将文件划分为多个下载点以更快速度下载，并列出最近的下载，方便访问文件。</p><p>IDM 的优势在于可以利用多线程技术极大地提高文件下载速度，即便是特别大的文件也可以轻松的快速整合。当然下载速度具体能达到多少取决于你的带宽和服务器的带宽。</p><figure><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191125/s9b8kgoujbpc.png\"></figure><h3>多个浏览器支持：</h3><p>IDM 支持所有主流浏览器包括谷歌浏览器、火狐浏览器以及微软家系列的 IE 和 Microsoft EDGE浏览器等等。</p><p>对于不支持的浏览器用户也可以在 IDM 设置的浏览器集成里手动设置，完成后即可接管各浏览器的任务下载。</p><p>同时IDM也可以用来识别视频网站中的链接，嗅探完成即可直接使用IDM将对应的视频文件下载到本地保存。</p><figure><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191125/s9b8klkewem8.jpg\"></figure><h3>IDM 功能介绍：</h3><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>下载提速5倍</p></li></ul><p>IDM 可提升您的下载速度高达 5 倍！</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>浏览器兼容</p></li></ul><p>支持多款浏览器，包括 IE，Safari，谷歌浏览器，火狐，Opera，并用通过自带的添加浏览器功能可以支持所有浏览器。</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>in-speed 技术</p></li></ul><p>智能的 in-speed 技术会动态地将所有设定应用到某种联机类型，以充分利用下载速度。</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>7*24 服务</p></li></ul><p>7*24 小时为您提供全方位售后服务，若您在使用过程中遇到任何无法解决的问题时，请您及时联系我们。</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>密钥找回</p></li></ul><p><a href=\"http://www.internetdownloadmanager.com/retrieve_registration.html\">http://www.internetdownloadmanager.com/retrieve_registration.html</a></p><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><h3>本次活动由本站联合软购正版软件商城共同举办！！</h3><p>官方正版 Internet Download Manager IDM 下载器软件 （终身版）原价：175元&nbsp; &nbsp; &nbsp; &nbsp;&nbsp;现券后价：只需要 99元！</p><h3>独家专属30元优惠券：<span style=\"color: rgb(255, 0, 0);\">ldqkidm30</span></h3><p>软购商城特价购买地址：&nbsp;<a href=\"https://apsgo.com/store/product/internet-download-manager\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/internet-download-manager\">https://apsgo.com/store/product/internet-download-manager</a></p>', NULL, '2019-11-25 17:45:12.904164', '2020-02-22 18:13:05.597656', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, 'null', 0, 0, 14.21200850837256, 1479, '162.158.119.51', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1685, 5, 'Eagle，让你高效管理素材库的设计利器，专为设计师打造的图片收藏及管理工具', '懒得勤快', '<p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03f4ys52io.jpeg\"></p><p>想必大家每天逛微博、论坛会即兴保存一些有意思的图片，看视频、聊天时有顺手截图的习惯；如果你还经常在网上发动态、文章，肯定会制造不少图片，更不用说设计师了。</p><p>对重命名图片都懒得动的人来说，即使每天定期清理，也只是随手扔进云盘或回收站的区别。</p><p>这时候，只有专门的图片管理工具能帮到你了。</p><h3>如果你喜欢收藏网图…</h3><p>在 Pinterest、behance 等网站需要科学上网后，花瓣成了不少设计师采集灵感的首选。</p><p>然而今年年初，花瓣引发了一波刷屏，毫无征兆关停一个月让很多没准备的设计师懵圈了。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03gamr61hc.png\"></p><p>这件事也许说明了图片管理工具同时具备云功能和本地功能的重要性。</p><p>一直以来花瓣给人的感觉像开放式的 QQ 空间，你可以分类创建自己的画板 (相册)，然后采集本地图片或他人作品 (互相踩一踩)。</p><p>就图片采集功能而言，支持浏览器插件的花瓣非常便利，正如上方图片左上角会出现「采集」按钮，一键就能保存到画板中。</p><p>如果你特别喜欢保存有趣的网图，花瓣会是不错的选择。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03gcc06eps.jpg\"></p><p>但是，将太私人的图片上传到花瓣之前还请三思，除非升级专业版获得隐私花瓣。 (即便如此，万一再次关停咋办？)</p><p>此外，花瓣上的素材能为大家提供灵感，但版权归属很模糊，设计师都只是用来参考，商用要谨慎哦~</p><h3>如果你是摄影爱好者…</h3><p>「P 图」是摄影师们的必修技能之一，拥有一款快速预览和高效处理大量照片的软件助手对摄影爱好者而言格外重要。</p><p>在 Adobe 庞大的精英家族中，Adobe Bridge 就是一款非常出色的照片管理工具。它不仅支持 JPG、PNG 等常见的图片类型，还支持 PDF、AI、TIFF、PSD 以及各种相机 RAW 文件。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03gdc2pmgw.png\"></p><p>摄影师中的老司机都默认采用 RAW 文件，以保留照片的原生数据。Br 能按不同机型、镜头类型、曝光时间等多种规则陈列照片，帮助你高效删除多余的照片。</p><p>Br 和其他家族成员的无缝衔接也是摄影师青睐它的原因之一，你可以在 Br 中初步筛选过后，用 Camera Raw 组件润色，需要进一步修图就直接转进 PhotoShop。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03gf48lq80.png\"></p><p>Br 和从现实中取材的设计师密不可分，如果你只是初学者，并且没有太多后期处理照片的要求，那么使用同样支持 RAW 文件的 ACDSee 就够了。</p><h3>如果你追求效率和美观…</h3><p>如果你喜欢和 Adobe Bridge 风格截然不同的工具，Eagle 绝对是你的首选。</p><p>本来在 Eagle 之前还有不少优秀的图片管理软件，例如被评为「2015 年最佳苹果应用」的 Pixave、备受欢迎的 Inboard……</p><p>然而就像 Eagle 开发者 Augus 所说，同类型很多产品都停止维护了，符合他心中理想的产品一直没有出现。</p><p>于是 Eagle 诞生了。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03gcktbim8.gif\"></p><p>这款界面活力十足的图片素材管理工具完全迎合设计师审美和工作习惯而生的，它可以整理电脑上的图片、照片、屏幕截图、海报、网页设计、Sketch 等各种设计素材。</p><p>不仅如此，Eagle 还能管理 PPT、Keynote、PDF、MP4 视频文件，新版还能管理 TTF 和 OTF 字体，可以说基本网罗了设计师所有的需求。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03gl7uocn4.png\"></p><p>在 Eagle 中你还可以直接在软件界面搜图，并且通过截图、拖拽就能随时收集灵感，根据图片的标签、颜色、形状、格式等条件还能随时精准找到任何内容。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03gmo81pmo.png\"></p><p>可以肯定的是，Eagle 是对中国用户最友好的设计素材管理工具，它能在 Windows 和 macOS 两大平台上运行。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03q7o86jgg.png\"></p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03ou5xmpkw.jpeg\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03ow883zsw.jpeg\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03ou6z36rk.jpeg\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191202/sa03ovtv708w.jpeg\"></p><p>&nbsp;</p><p>Eagle 是专为设计师打造的素材收集 / 管理工具，支持 macOS 与 Windows 系统。它可以帮你高效地整理电脑上的图片、照片、屏幕截图、海报、网页设计、Sketch 等各种设计素材。</p><h3>迅速保存你喜爱的图片</h3><p>通过安装浏览器扩展、截图和拖拽等方式，帮助你收藏出现在眼前的任何灵感，随手写下想法。</p><h3>轻松完成图片整理、分类</h3><p>使用 Eagle 强大的功能来整理、标记你的图片，让你在未来可以快速的找到它们。</p><h3>寻找你需要的设计灵感</h3><p>正在寻找设计的灵感？根据图片的标签、颜色、形状、格式等条件找到你需要任何内容。</p><h3>支持你喜爱的各种格式</h3><p>Eagle 支持 Sketch、PS、Ai、Keynote、PPT、GIF、JPG、PNG、PDF 等 20+ 种文件格式的收集。</p><h3>常见Q&amp;A</h3><h4>一、我想要在多台设备中同步 Eagle 收藏的内容，我该怎么做？</h4><p>目前你有两种方式可以达成：</p><p>1. 使用具有同步功能的云盘服务：Eagle 支持 Google Drive、Dropbox、iCloud、Resilio Sync、坚果云等各种支持文件同步的云端服务，只需将 Eagle 资源库本地文件夹放入同步服务的本地文件夹中，你在 Eagle 收藏的内容就可以在多台设备中进行同步了；</p><p>2. 将资料存放于便携式储存设备（如 USB 硬盘）：如果不借助网络，你也可使用 USB 设备来达到同样的效果，你只需要将 Eagle 的资源库文件夹存放在 USB 设备中，随身携带即可。</p><p>你可以点击 Eagle 菜单栏「资源库 &gt; 载入其他资源库」选项，找到存放于 USB 设备中的 Eagle 资源库内容。</p><h4>二、为什么浏览器插件一直说我没有开启 Eagle App？</h4><p>请确认你已启动 Eagle 软件。如已启动，还是无法解决该问题，你可以尝试：</p><p>1.重新启动 Eagle；</p><p>2.检查电脑是否开启了科学上网软件，如果是，将代理模式切换到「自动代理模式」或直接关闭代理工具。</p><h4>三、我想要把序列号移转至其他设备，我该怎么处理呢？</h4><p>你可在取消绑定的设备中点击菜单栏「Eagle &gt; 移除注册状态」将设备移除，接着在新设备重新注册软件即可。</p><h4>四、我的电脑遗失或损坏，请问我的序列号可以移转至其他电脑上继续使用吗？</h4><p>可以，你不需要担心因為设备损坏或丟失导致产品序列号无法使用，你可以在新的设备中，将不需要的设备解除绑定状态。</p><h3>视频评测</h3><video class=\"wp-video-shortcode\" id=\"video-5865-1\" width=\"100%\" height=\"635\" preload=\"none\" controls=\"controls\"><source type=\"video/mp4\" src=\"http://cloud.video.taobao.com//play/u/881336826/p/2/e/6/t/1/50011988307.mp4?_=1\"><a href=\"http://cloud.video.taobao.com//play/u/881336826/p/2/e/6/t/1/50011988307.mp4\">http://cloud.video.taobao.com//play/u/881336826/p/2/e/6/t/1/50011988307.mp4</a></video><h3>购买链接</h3><p><a href=\"https://partner.lizhi.io/ldqk/eagle\" target=\"_blank\" textvalue=\"https://partner.lizhi.io/ldqk/eagle\">https://partner.lizhi.io/ldqk/eagle</a></p>', NULL, '2019-12-02 17:01:33.019531', '2020-01-29 11:12:55.653320', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, NULL, 0, 0, 14.199310260689707, 1379, '172.68.253.81', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1687, 5, '官方正版绑定账户 AdGuard 广告拦截隐私保护软件 -3设备授权', '懒得勤快', '<p style=\"text-align: center;\"><img src=\"https://masuit.oss-cn-beijing.aliyuncs.com/2020/02/12/sh43bvdfq22o.jpg\" class=\"meizi\"></p><p style=\"text-align: center;\">▲小丽</p><p>AdGuard 广告拦截隐私保护软件 -3设备授权 由本站和 APSGO 软购商城推荐的官方正版特价！终身版！一次购买终身使用！</p><h3>地球村特高级的广告拦截程序！</h3><p>AdGuard 是摆脱恼人广告，在线跟踪，保护您远离恶意软件的最佳方式。AdGuard 使您网络冲浪更快速，更安全，更安逸！</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191203/sa3sv1ikl6gw.gif\"></p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>AdGuard for Windows<br style=\"box-sizing: border-box;\">不只是广告拦截程序，它还组合了可获取最佳网络体验所需功能的多用途工具。其可拦截广告和危险网站，加速网页载入，保护儿童的在线安全。</p></li><li><p>AdGuard for Mac<br style=\"box-sizing: border-box;\">与其它广告浏览器不同，AdGuard 有专用于 macOS 的版本。其不仅可拦截 Safari 和其它浏览器内的广告，还可使您远离跟踪，钓鱼和诈骗。</p></li><li><p>AdGuard for Android<br style=\"box-sizing: border-box;\">安卓移动设备的理想解决方案。与其它广告拦截程序对比，AdGuard 无需根权限，其提供了丰富的功能：过滤应用，应用管理以及更多。</p></li><li><p>AdGuard for iOS<br style=\"box-sizing: border-box;\">用于 Safari 的最高级广告拦截器：其可拦截各种广告和计数器，加速页面载入，保护您的个人数据。有超过 50 个过滤器可用，您可按需调整过滤。</p></li></ul><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191203/sa3sv79k69z4.png\"></p><p>广告拦截</p><p>AdGuard 会一次处理所有类型的烦人横幅广告，弹窗以及视频广告。</p><p>隐私保护</p><p>AdGuard 隐藏您的数据，使其远离全集网络之上的跟踪器及活动性分析器。</p><p>安全浏览</p><p>幸亏有了 AdGuard，您将能够避免所有诈骗和钓鱼网站及恶意攻击。</p><p>家长控制</p><p>通过限制儿童访问不适宜的和成人内容以保护他们的在线安全。</p><h3>为什么选择 AdGuard？</h3><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>广告拦截<br style=\"box-sizing: border-box;\">当今大多数广告拦截程序至少都能够确保广告拦截品质。</p></li><li><p>页面装饰处理<br style=\"box-sizing: border-box;\">许多 AdGuard 的同类产品也能够隐藏广告拦截后框架和空白空间。</p></li><li><p>节省流量加速载入<br style=\"box-sizing: border-box;\">与浏览器广告拦截程序不同，AdGuard 是在广告加载到浏览器之前就拦截了它们。这可节省流量加速载入页面。</p></li><li><p>远离烦人的广告<br style=\"box-sizing: border-box;\">AdGuard 提供专用的过滤器以拦截最烦人的元素（注册表单，在线顾问等）过滤任何浏览器或应用<br style=\"box-sizing: border-box;\">AdGuard 可完美协同所有和浏览器工作，包括 Windows 的 Metro 应用。</p></li></ul><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191203/sa3sv1hgmsxs.png\"></p><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><p>本次活动由本站联合软购正版软件商城共同举办！！</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>AdGuard 广告拦截隐私保护软件 -3设备 1年订阅许可证：官方原价：72.00元&nbsp;联合软购商城特价活动价：58.00 元！</p></li><li><p>AdGuard 广告拦截隐私保护软件 -3设备 永久版许可证：官方原价：189.9.00元&nbsp;联合软购商城特价活动价：138.00 元！</p></li></ul><h3>独家专属10元优惠券：<span style=\"color: rgb(255, 0, 0);\">ldqkadguard10</span></h3><p>软购商城特价购买地址：<a href=\"https://apsgo.com/store/product/adguard/?id=2\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/adguard/?id=2\">https://apsgo.com/store/product/adguard/?id=2</a></p>', NULL, '2019-12-03 17:53:18.752929', '2020-02-13 12:30:39.696289', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, '去广告', 1, 0, 14.346076311929869, 1376, '13.94.57.190', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1698, 5, '官方授权正版 Beyond Compare 4 文件代码文件夹对比工具软件', '懒得勤快', '<p style=\"text-align: center;\"><img src=\"https://masuit.oss-cn-beijing.aliyuncs.com/2020/02/08/sgrc6qwjlo1s.JPG\">▲田静</p><hr><h3>一款极致的文件对比工具</h3><p>业界遥遥领先，即可体验到位的文件对比乐趣<br style=\"box-sizing: border-box;\">简易的操作方式，只需用鼠标点击几下，开启享受般的对比体验，找出所需差异，同步文件并生成报告，一气呵成。</p><p><img src=\"https://apsgo.com/wp-content/uploads/2019/12/%E6%8F%8F%E8%BF%B0_01.jpg\"></p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>多文本格式</p></li></ul><p>一款不可多得的专业级的文件和文件夹对比工具，它可以支持大多数我们常见的文档格式。</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>文件夹合并</p></li></ul><p>将您对文件夹进行比较之后，可以快速将其进行合并为一个文件夹。</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>图片对比</p></li></ul><p>您可以对图片进行翻转、旋转和缩放图像来比较两张图片中的差异，它可支持许多图片格式。</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>注册表比较</p></li></ul><p>此功能可对比注册表文件（.reg），从而快速找到差异，提高工作效率。</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>音乐文件比较</p></li></ul><p>您可通过软件来比较 MP3 标签、.exe 版本信息，实际上它能比较各种流行的音乐文件。</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>Excel 表格文件对比</p></li></ul><p>做为专业的文件比较工具，支持 CSV PHP HTML 表格和 Excel 工作表等文档格式。</p><p><img src=\"https://apsgo.com/wp-content/uploads/2019/12/beyondcompare_02.jpg\"></p><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><h3>本次活动由本站联合软购正版软件商城共同举办！！</h3><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>Beyond Compare 4 文件代码文件夹对比工具软件 -标准版：官方原价：211.00元&nbsp;联合软购商城特价活动价：<span style=\"color: rgb(255, 0, 0);\">198.00</span> 元！</p></li><li><p>Beyond Compare 4 文件代码文件夹对比工具软件 -专业版：官方原价：422.00元&nbsp;联合软购商城特价活动价：<span style=\"color: rgb(255, 0, 0);\">398.00</span> 元！</p></li></ul><h3>独家专属10元优惠券：<span style=\"color: rgb(255, 0, 0);\">ldqkBeyond10</span></h3><p>软购商城特价购买地址：<a href=\"https://apsgo.com/store/product/beyond-compare/?id=2\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/beyond-compare/?id=2\">https://apsgo.com/store/product/beyond-compare/?id=2</a></p>', NULL, '2019-12-17 19:31:59.730468', '2020-02-03 17:48:54.767578', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, 'null', 1, 0, 18.443945118757526, 1510, '13.94.57.190', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1699, 5, '「48折」官方正版授权！iMazing iPhone/iPad 设备管理备份工具软件', '懒得勤快', '<p style=\"text-align: center;\"><img src=\"https://git.imweb.io/ldqk0/imgbed/raw/master/2020/02/09/sgv19qbu7bi8.jpg\">▲艾栗栗</p><p>iMazing iPhone/iPad 设备管理备份工具软件 由本站和 APSGO 软购商城推荐的官方正版特价！终身版！一次购买终身使用！</p><h3>iMazing -以自己的方式管理 iPhone。</h3><p>让备受信赖的软件为您传输和保存音乐、信息、文件和数据。安全备份任何 iPhone、iPad 或 iPod touch。iMazing 功能强大、易于使用，称得上是 Mac 和 PC 上最好的 iOS 设备管理器。</p><p><img src=\"https://gitlab.com/masuit/imgbed/raw/master/2019/12/17/sbi09vkhhaf4.png\"></p><p>超越 iTunes，畅享 iMazing。</p><p>保存珍贵的数据</p><p>保存、导出和打印您的 iPhone 信息。文字信息、彩信、iMessage 和附件都可以用 iMazing 安全备份。</p><p>更简单的音乐传输</p><p>在 iPhone、iPad、iPod 和电脑之间自由地来回拷贝音乐。无需使用 iTunes 同步。</p><p>轻松访问您的照片</p><p>无需 iCloud 或 iTunes，即可导出照片和视频。将您喜爱的瞬间保存在 Mac 或 PC 上。</p><p>更智能的备份（免费！）</p><p>借助独有的技术存储 iPhone 和 iPad 数据。有了 iMazing，您就可以安全地备份设备，甚至可以无线备份。</p><h3>将数据传输至您的全新 iPhone 11</h3><p>将数据快速传输至全新 iPhone。无需 iCloud 或 iTunes，您就能拷贝全部内容或选择要传输的正确内容。</p><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>传输文件和文稿<br style=\"box-sizing: border-box;\">在 iPhone、iPad 和电脑之间传输文件和文件夹。</p></li><li><p>管理通讯录<br style=\"box-sizing: border-box;\">在 iPhone 和 Mac 或 PC 之间直接拷贝所有联系人信息。</p></li><li><p>独有的应用管理解决方案<br style=\"box-sizing: border-box;\">将您的应用（.ipa）下载至电脑。备份及传输应用数据。</p></li><li><p>导出“Safari 浏览器”数据<br style=\"box-sizing: border-box;\">访问书签、阅读列表和浏览记录并将它们导出到您的电脑。</p></li><li><p>将铃声传输到 iPhone<br style=\"box-sizing: border-box;\">自定义铃声、通知和提醒声音。</p></li><li><p>传输并管理图书<br style=\"box-sizing: border-box;\">从 eBooks 导出电子书或 PDF，将数据从电脑导入 iPhone 或 iPad。</p></li><li><p>访问和导出日历<br style=\"box-sizing: border-box;\">以“日历”或 Excel / CSV 格式将日历导出到您的电脑。</p></li><li><p>导出通话记录和语音邮件<br style=\"box-sizing: border-box;\">访问和导出通话记录，将语音邮件保存在电脑上。</p></li><li><p>您的其他重要数据<br style=\"box-sizing: border-box;\">读取您的 iPhone 语音邮件、语音备忘录和备忘录。</p></li><li><p>iOS 高级管理<br style=\"box-sizing: border-box;\">USB 或 Wi-Fi 连接、管理配对、抹掉设备、重新安装 iOS、诊断…</p></li></ul><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><h3>本次活动由本站联合软购正版软件商城共同举办！！</h3><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>iMazing iPhone/iPad 设备管理备份工具软件，永久终身版！1台电脑：官方原价：183.00元&nbsp;联合软购商城特价活动价：<span style=\"color: rgb(255, 0, 0);\">89.00</span> 元！（券后）</p></li><li><p>macOS, Windows 自选一个平台。</p></li></ul><h3>独家专属10元优惠券：<span style=\"color: rgb(255, 0, 0);\">ldqkiMazing10</span></h3><p>软购商城特价购买地址：<a href=\"https://apsgo.com/store/product/imazing/?id=2\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/imazing/?id=2\">https://apsgo.com/store/product/imazing/?id=2</a></p>', NULL, '2019-12-17 19:34:12.848632', '2020-02-09 21:48:26.678710', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, 'null', 0, 0, 5.546739076308676, 453, '140.227.126.126', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1703, 5, '官方授权正版！PP鸭 图片压缩神器工具软件 – 给您的图片减减肥', '懒得勤快', '<p style=\"text-align: center;\"><img src=\"https://git.imweb.io/guomo/imgbed/raw/master/2020/01/05/sdcn8caw581s.JPG\" class=\"meizi\"></p><p style=\"text-align: center;\">▲小静</p><p>PP鸭 图片压缩神器工具软件 由本站和 APSGO 软购商城推荐的官方正版特价！终身版！一次购买终身使用！</p><p>PP鸭整合了业内最优秀的数种开源的图片压缩算法，会自动根据图片特征自动选择压缩参数。只需要将图片拖入PP鸭，就能自动批量压缩，省时省心。</p><h3>极致的图片压缩效果：</h3><p>经过长时间反复调校和对比各种算法，PP鸭在品质，体积，速度三者间，帮你定位完美的平衡点。最新的v3 版本还支持 WebP 压缩；</p><p><img src=\"https://apsgo.com/wp-content/uploads/2019/11/ppduck01.png\"></p><h3>谁需要使用 PP鸭：</h3><p>在移动互联网时代，对更快速度和更小流量的追求正在变得更严格，PP鸭帮助客户做到更好；</p><p>加速网站打开</p><p>减小应用体积</p><p>节省网站流量</p><p>节省磁盘空间</p><p><img src=\"https://apsgo.com/wp-content/uploads/2019/11/ppduck03-768x579.png\"></p><h3>软件规格</h3><table class=\"woocommerce-product-attributes shop_attributes\"><tbody style=\"box-sizing: border-box;\"><tr class=\"woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_%e4%b8%ad%e6%96%87%e7%95%8c%e9%9d%a2%ef%bc%9a firstRow\" style=\"box-sizing: border-box;\"><th class=\"woocommerce-product-attributes-item__label\" style=\"box-sizing: border-box; padding: 0.4375em; text-align: left; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\">中文界面：</th><td class=\"woocommerce-product-attributes-item__value\" style=\"box-sizing: border-box; padding: 0.4375em; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\"><p>支持中文界面显示，多语言可选。</p></td></tr><tr class=\"woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_%e6%9b%b4%e6%96%b0%e8%af%b4%e6%98%8e%ef%bc%9a\" style=\"box-sizing: border-box;\"><th class=\"woocommerce-product-attributes-item__label\" style=\"box-sizing: border-box; padding: 0.4375em; text-align: left; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\">更新说明：</th><td class=\"woocommerce-product-attributes-item__value\" style=\"box-sizing: border-box; padding: 0.4375em; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\"><p>永久使用，子版本免费更新。</p></td></tr><tr class=\"woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_%e4%b9%b0%e5%89%8d%e8%af%95%e7%94%a8%ef%bc%9a\" style=\"box-sizing: border-box;\"><th class=\"woocommerce-product-attributes-item__label\" style=\"box-sizing: border-box; padding: 0.4375em; text-align: left; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\">买前试用：</th><td class=\"woocommerce-product-attributes-item__value\" style=\"box-sizing: border-box; padding: 0.4375em; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\"><p>30天免费试用。</p></td></tr><tr class=\"woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_pa_%e8%bf%90%e8%a1%8c%e5%b9%b3%e5%8f%b0%ef%bc%9a\" style=\"box-sizing: border-box;\"><th class=\"woocommerce-product-attributes-item__label\" style=\"box-sizing: border-box; padding: 0.4375em; text-align: left; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\">运行平台：</th><td class=\"woocommerce-product-attributes-item__value\" style=\"box-sizing: border-box; padding: 0.4375em; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\"><p>macOS, Windows</p></td></tr><tr class=\"woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_%e5%a6%82%e4%bd%95%e6%94%b6%e8%b4%a7%ef%bc%9a\" style=\"box-sizing: border-box;\"><th class=\"woocommerce-product-attributes-item__label\" style=\"box-sizing: border-box; padding: 0.4375em; text-align: left; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\">如何收货：</th><td class=\"woocommerce-product-attributes-item__value\" style=\"box-sizing: border-box; padding: 0.4375em; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\"><p>购买后，激活信息会以邮件的形式发送到下单时的邮箱。</p></td></tr><tr class=\"woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_%e8%ae%be%e5%a4%87%e6%95%b0%e9%87%8f%ef%bc%9a\" style=\"box-sizing: border-box;\"><th class=\"woocommerce-product-attributes-item__label\" style=\"box-sizing: border-box; padding: 0.4375em; text-align: left; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\">设备数量：</th><td class=\"woocommerce-product-attributes-item__value\" style=\"box-sizing: border-box; padding: 0.4375em; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\"><p>可安装1台电脑。</p></td></tr><tr class=\"woocommerce-product-attributes-item woocommerce-product-attributes-item--attribute_%e6%9b%b4%e6%8d%a2%e7%94%b5%e8%84%91%ef%bc%9a\" style=\"box-sizing: border-box;\"><th class=\"woocommerce-product-attributes-item__label\" style=\"box-sizing: border-box; padding: 0.4375em; text-align: left; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\">更换电脑：</th><td class=\"woocommerce-product-attributes-item__value\" style=\"box-sizing: border-box; padding: 0.4375em; border-top-width: 0px; border-left-width: 0px; border-color: rgb(209, 209, 209);\"><p>原电脑取消激活，新电脑激活。</p></td></tr></tbody></table><p><img src=\"https://apsgo.com/wp-content/uploads/2019/11/ppduck02.png\"></p><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><h3>本次活动由本站联合软购正版软件商城共同举办！！</h3><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>PP鸭 图片压缩神器工具软件 官方正版！永久使用！</p></li></ul><h3>独家专属5元优惠券：<span style=\"color: rgb(255, 0, 0);\">ldqk5</span></h3><p>软购商城特价购买地址：&nbsp;<a href=\"https://apsgo.com/store/product/ppduck/?id=2\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/ppduck/?id=2\">https://apsgo.com/store/product/ppduck/?id=2</a></p>', NULL, '2019-12-21 10:46:56.041992', '2020-02-28 21:26:27.456054', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, 'null', 1, 0, 12.887577142874877, 1010, '162.158.118.144', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1704, 5, '特惠官方授权正版 天若 OCR 文字识别软件 专业版', '懒得勤快', '<p style=\"text-align: center;\"><img src=\"https://git.imweb.io/guomo/imgbed/raw/master/2020/02/15/shevk3t4rp4w.jpg\" class=\"meizi\"></p><p style=\"text-align: center;\">▲顾欣欣</p><p>天若 OCR 文字识别软件 由本站和 APSGO 软购商城推荐的官方正版特价！终身版！一次购买终身使用！天若 OCR 文字识别工具是一款 Windows 上相当方便实用的「截图 OCR 识别」小工具，软件有免费版，它最大的亮点是直接对屏幕进行截图便能识别出其中的文字内容，然后你就可直接复制粘贴、或者对识别出来的文本快速进行翻译等操作。</p><p>它帮您减少重复劳动，助您提高工作效率。</p><p><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2019/12/21/sbuzhiz3pq80.gif\"></p><h3>功能</h3><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>识别功能<br style=\"box-sizing: border-box;\">将图片中的文字转换成可编辑文本</p></li><li><p>翻译功能<br style=\"box-sizing: border-box;\">识别图片中的文字并进行翻译</p></li><li><p>截图功能<br style=\"box-sizing: border-box;\">拥有丰富的截图标注功能</p></li><li><p>录制功能<br style=\"box-sizing: border-box;\">可以快速录制gif并且添加水印</p></li><li><p>贴图功能<br style=\"box-sizing: border-box;\">将粘贴板图片置顶到桌面最上方</p></li><li><p>透视变换<br style=\"box-sizing: border-box;\">通过透视变换进行图片校正</p></li></ul><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><h3>本次活动由本站联合软购正版软件商城共同举办！！</h3><ul style=\"list-style-type: square;\" class=\" list-paddingleft-2\"><li><p>天若 OCR 文字识别软件 专业版–绑定您的账户，官方授权代理商。</p></li></ul><h3>独家专属5元优惠券：<span style=\"color: rgb(255, 0, 0);\">ldqk5</span></h3><p>软购商城特价购买地址：&nbsp;<a href=\"https://apsgo.com/store/product/tianruoocr/?id=2\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/tianruoocr/?id=2\">https://apsgo.com/store/product/tianruoocr/?id=2</a></p><p>关于评论区的评论，代理商给出的解释：</p><p style=\"margin-top: 0px; margin-bottom: 10px; padding: 0px; font-family: &quot;Helvetica Neue&quot;, Helvetica, &quot;PingFang SC&quot;, &quot;Microsoft YaHei&quot;, Tahoma, Arial, sans-serif; font-size: 14px; white-space: normal;\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/20191221/sbw9nggr00zk.png\"></p><p><br></p>', NULL, '2019-12-21 10:52:13.834960', '2020-02-26 18:35:07.989257', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, 'null', 1, 0, 18.79660591285167, 1472, '52.175.24.217', b'0', b'0', NULL, NULL, NULL);
INSERT INTO `post` VALUES (1714, 5, 'Windows 10专业版正版操作系统，仅需348元！', '懒得勤快', '<p style=\"text-align: center;\"><img src=\"https://git.imweb.io/ldqk/imgbed/raw/master/2020/01/09/sdrz7h9uhmv4.jpg\">▲谭松韵</p><hr><h3>新一代 Windows 版本<br></h3><p>Windows 10 的设计旨在为您提供跨越不同设备的无缝体验。速度快而灵敏。您甚至可以与支持人员免费在线聊天或获得实时电话支持。拥有 Windows 10，工作变得比以往更加轻松。</p><p><img src=\"https://git.imweb.io/guomo/imgbed/raw/master/2020/01/09/sdrogrnb3qio.png\"></p><p>得心应手</p><p>Windows10 结合了您已熟悉的 Windows 操作系统，并进行了多项改进。InstantGo1 等技术让您可以迅速启动和重启。Windows 10 比以往具有更多内置安全功能，帮助您预防恶意软件的入侵。</p><p>多任务处理</p><p>像专家那样进行多任务处理，能够在屏幕中同时摆放四个窗口。屏幕太拥挤？创建虚拟桌面，获取更多空间，需要什么都能随手拈来。而且，您的所有通知和关键设置都集中于同一个操控简单的屏幕中。</p><p>Microsoft Edge</p><p>这是全新的浏览器，旨在让网络适应您的工作习惯。直接在网页上写入或输入，并与他人共享您的收藏。阅读视图可以减少干扰，让您静心阅读。还有改进的地址栏，帮助您更快找到想要的资料。</p><p>Continuum 模式</p><p>Windows 10 优化了您的活动和设备体验，让眼前的屏幕带给您更舒适的视觉效果。屏幕上的功能可自行调整以方便导航，应用程序也可从最小到最大显示平滑缩放。</p><p>专属于您的系统</p><p>您的 Windows 10 设备能以真正个性化的方式识别和确认您的身份。利用 Windows Hello，您的设备可以称呼您的名字来欢迎您、在识别后亮起、自动为您登入，让您无需记住或输入密码。</p><p><img src=\"https://git.imweb.io/si/imgbed/raw/master/2020/01/09/sdrogoq7vitc.png\"></p><p>游戏和 Xbox</p><p>在您的Windows 10 PC、笔记本电脑或平板电脑上玩 Xbox One 游戏。使用 Game DVR 功能录制您酷炫的英雄招式并即时发送给您的朋友，无需退出游戏。</p><p>Cortana</p><p>Cortana 是您真正的私人智能助理，存在于您的每一台 Windows10 设备，帮助您完成工作。随着时间的推移，Cortana 会对您了解更多，也会变得更有帮助，更直观易用，值得您信赖。</p><h3>系统要求</h3><p>1GHz或更快的处理器</p><p>1GB RAM（32位） 2GB RAM（64位）</p><p>至少20GB可用硬盘空间</p><p>800 x 600屏幕分辨率或更高</p><p>具有WDDM驱动程序的DirectX® 9图形处理器</p><p>Internet访问（可能要支付费用）</p><p>某些功能需要Microsoft账户</p><p>观看DVD需要单独的播放软件</p><p>您必须接受随附的许可条款，访问microsoft.com/useterms也可浏览许可条款 需要激活 • 单个许可证 • 包括USB 3.0上的32和64位</p><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><h3>本次活动由本站联合软购正版软件商城共同举办！！</h3><p>Windows 10 专业版 正版操作系统 联合软购商城特价活动价：348.00 元！</p><h3>独家专属150元优惠券：<span style=\"color: rgb(255, 0, 0);\">maswin10</span></h3><p>软购商城特价购买地址：<a href=\"https://apsgo.com/store/product/windows-10\" target=\"_blank\" textvalue=\"https://apsgo.com/store/product/windows-10\">https://apsgo.com/store/product/windows-10</a></p><hr style=\"box-sizing: border-box; height: 0px; margin: 0px; border-right: 0px; border-bottom: 0px; border-left: 0px; border-image: initial; border-top-style: solid; border-top-color: rgb(238, 238, 238); background-color: rgb(255, 255, 255); color: rgb(102, 102, 102); font-family: &quot;Work Sans&quot;, Arial, sans-serif; font-size: 14px; white-space: normal;\"><p>还在犹豫是否需要购买？没关系，请从这里下载安装免费先体验试用再说！官方下载地址：<a href=\"https://www.microsoft.com/zh-cn/software-download/windows10\" target=\"_blank\" textvalue=\"https://www.microsoft.com/zh-cn/software-download/windows10\">https://www.microsoft.com/zh-cn/software-download/windows10</a></p>', NULL, '2020-01-09 16:56:07.781250', '2020-03-03 23:47:06.538085', b'0', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', 'windows', 'null', 0, 0, 8.99270374787698, 531, '203.66.57.238', b'0', b'0', NULL, NULL, NULL);

-- ----------------------------
-- Table structure for posthistoryversion
-- ----------------------------
DROP TABLE IF EXISTS `posthistoryversion`;
CREATE TABLE `posthistoryversion`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Title` varchar(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ProtectContent` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `ViewCount` int(11) NOT NULL DEFAULT 0,
  `ModifyDate` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `CategoryId` int(11) NOT NULL,
  `PostId` int(11) NOT NULL,
  `Email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `Label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `Modifier` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `ModifierEmail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `IX_PostHistoryVersion_CategoryId`(`CategoryId`) USING BTREE,
  INDEX `IX_PostHistoryVersion_PostId`(`PostId`) USING BTREE,
  CONSTRAINT `FK_PostHistoryVersion_Category_CategoryId` FOREIGN KEY (`CategoryId`) REFERENCES `category` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `FK_PostHistoryVersion_Post_PostId` FOREIGN KEY (`PostId`) REFERENCES `post` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of posthistoryversion
-- ----------------------------

-- ----------------------------
-- Table structure for postmergerequest
-- ----------------------------
DROP TABLE IF EXISTS `postmergerequest`;
CREATE TABLE `postmergerequest`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `PostId` int(11) NOT NULL,
  `Title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Modifier` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `ModifierEmail` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `MergeState` tinyint(4) NOT NULL DEFAULT 0,
  `Status` tinyint(255) NOT NULL DEFAULT 0,
  `SubmitTime` datetime(0) NOT NULL DEFAULT CURRENT_TIMESTAMP(0) ON UPDATE CURRENT_TIMESTAMP(0),
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `PostId`(`PostId`) USING BTREE,
  CONSTRAINT `postmergerequest_ibfk_1` FOREIGN KEY (`PostId`) REFERENCES `post` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 15 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of postmergerequest
-- ----------------------------

-- ----------------------------
-- Table structure for searchdetails
-- ----------------------------
DROP TABLE IF EXISTS `searchdetails`;
CREATE TABLE `searchdetails`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `KeyWords` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SearchTime` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `IP` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  PRIMARY KEY (`Id`) USING BTREE,
  INDEX `SearchTime`(`SearchTime`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 538202 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of searchdetails
-- ----------------------------

-- ----------------------------
-- Table structure for seminar
-- ----------------------------
DROP TABLE IF EXISTS `seminar`;
CREATE TABLE `seminar`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Title` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SubTitle` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of seminar
-- ----------------------------
INSERT INTO `seminar` VALUES (1, 0, '网上学科', '老湿机日常飙车必备工具', '科学上网是科学的利用网络去解决生活中的实际问题以及学术研究等，简称科学上网，是有计划性，有目标的上网。联外网不是“科学上网”。');
INSERT INTO `seminar` VALUES (2, 0, '开源项目', '博主开源项目', '博主自主研发的开源项目，本专题搜集与开源项目有关的文章和资源');
INSERT INTO `seminar` VALUES (4, 0, '生产力工具', '工欲善其事，必先利其器', '所谓工欲善其事，必先利其器，尽管我们的生产力还是很强大了，但是有了他们，会有你意想不到的收获！');
INSERT INTO `seminar` VALUES (5, 0, '资源中心', '编程爱好者资源', '本专题包含各类编程类资源学习视频，供编程初学者下载，本专题资源完全免费，并且无加密，如果你是通过某宝、或是其他论坛等渠道，通过任何付费的方式获取到本资源，请直接退款并在相应的平台举报，如果是论坛的，请将本页链接分享到你购买源的评论区，告诫他人谨防上当，或者直接将本页链接转发分享给有需要的人。');
INSERT INTO `seminar` VALUES (6, 0, '稀缺资源', '互联网上重金难求的被和谐资源，这里不收费', '互联网上仅存的稀缺资源，不收取任何费用，仅用于个人研究和使用，发扬互联网分享精神，专注收藏与分享。');
INSERT INTO `seminar` VALUES (7, 0, 'jetbrains资源', 'jetbrains全系列资源', '集前后端及各种开发语言的开发神器全家桶');

-- ----------------------------
-- Table structure for seminarpost
-- ----------------------------
DROP TABLE IF EXISTS `seminarpost`;
CREATE TABLE `seminarpost`  (
  `Seminar_Id` int(11) NOT NULL,
  `Post_Id` int(11) NOT NULL,
  PRIMARY KEY (`Seminar_Id`, `Post_Id`) USING BTREE,
  INDEX `IX_SeminarPost_Post_Id`(`Post_Id`) USING BTREE,
  CONSTRAINT `FK_SeminarPost_Post_Post_Id` FOREIGN KEY (`Post_Id`) REFERENCES `post` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `FK_SeminarPost_Seminar_Seminar_Id` FOREIGN KEY (`Seminar_Id`) REFERENCES `seminar` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of seminarpost
-- ----------------------------

-- ----------------------------
-- Table structure for seminarposthistoryversion
-- ----------------------------
DROP TABLE IF EXISTS `seminarposthistoryversion`;
CREATE TABLE `seminarposthistoryversion`  (
  `Seminar_Id` int(11) NOT NULL,
  `PostHistoryVersion_Id` int(11) NOT NULL,
  PRIMARY KEY (`Seminar_Id`, `PostHistoryVersion_Id`) USING BTREE,
  INDEX `IX_SeminarPostHistoryVersion_PostHistoryVersion_Id`(`PostHistoryVersion_Id`) USING BTREE,
  CONSTRAINT `FK_SeminarPostHistoryVersion_PostHistoryVersion_PostHistoryVers~` FOREIGN KEY (`PostHistoryVersion_Id`) REFERENCES `posthistoryversion` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `FK_SeminarPostHistoryVersion_Seminar_Seminar_Id` FOREIGN KEY (`Seminar_Id`) REFERENCES `seminar` (`Id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of seminarposthistoryversion
-- ----------------------------

-- ----------------------------
-- Table structure for systemsetting
-- ----------------------------
DROP TABLE IF EXISTS `systemsetting`;
CREATE TABLE `systemsetting`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Name` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 31 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of systemsetting
-- ----------------------------
INSERT INTO `systemsetting` VALUES (2, 1, 'logo', 'https://git.imweb.io/ldqk/imgbed/raw/master/20190606/5dc7fc1266bfd8109d1ef5e0e7630f2c_2_3_art.png');
INSERT INTO `systemsetting` VALUES (3, 1, 'Title', '懒得勤快的博客_互联网分享精神');
INSERT INTO `systemsetting` VALUES (4, 1, 'Brand', '懒得勤快，互联网分享精神，勤于发现，乐于分享');
INSERT INTO `systemsetting` VALUES (5, 1, 'EmailFrom', 'root@masuit.com');
INSERT INTO `systemsetting` VALUES (6, 1, 'EmailPwd', '');
INSERT INTO `systemsetting` VALUES (7, 1, 'SMTP', '');
INSERT INTO `systemsetting` VALUES (8, 1, 'ReceiveEmail', 'admin@masuit.com');
INSERT INTO `systemsetting` VALUES (9, 1, 'Slogan', '懒得勤快，互联网分享精神，勤于发现，乐于分享');
INSERT INTO `systemsetting` VALUES (10, 1, 'Keyword', '懒得勤快,masuit.com,绿色软件,Resharper 2019 破解,TeamViewer破解版,FL Studio破解版,DIY显示器,k7b,M270DAN02.6');
INSERT INTO `systemsetting` VALUES (11, 1, 'Description', '懒得勤快,.net开发技术,Resharper 2019 破解,Navicat 破解版,FL Studio破解版,TeamViewer破解版,DIY显示器');
INSERT INTO `systemsetting` VALUES (12, 1, 'Donate', 'https://git.imweb.io/ldqk/imgbed/raw/master/20190810/微信图片_20190810204128.png');
INSERT INTO `systemsetting` VALUES (13, 1, 'Copyright', '<p>联系站长：<a href=\"https://github.com/ldqk\" target=\"_blank\">GitHub</a> | <a href=\"http://wpa.qq.com/msgrd?v=3&uin=3444764617&site=qq&menu=yes\" target=\"_blank\">腾讯QQ</a>&nbsp;|&nbsp;<a href=\"https://www.zhihu.com/people/ldqk/activities\" target=\"_blank\">知乎</a>&nbsp;| <a href=\"https://gitee.com/masuit_admin\" target=\"_blank\">码云</a> | <a href=\"https://t.me/ldqk0\" target=\"_blank\">Telegram</a>&nbsp;|&nbsp;<a href=\"https://t.me/masuit\" target=\"_blank\">Telegram群组</a> | <a target=\"_blank\" href=\"https://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=admin@masuit.com\" style=\"text-decoration:none;\"><img src=\"https://rescdn.qqmail.com/zh_CN/htmledition/images/function/qm_open/ico_mailme_02.png\"/></a>，商务合作请联系QQ：<a href=\"http://wpa.qq.com/msgrd?v=3&uin=3444764617&site=qq&menu=yes\" target=\"_blank\">3444764617</a>，邮箱：<a href=\"https://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=admin@masuit.com\" target=\"_blank\">admin@masuit.com</a></p><p>Copyright@懒得勤快 保留所有权利. | Powered&amp;Developed By 懒得勤快 |&nbsp;<a href=\"/donate\" target=\"_self\" textvalue=\"赞助和支持\">赞助和支持</a>&nbsp;|&nbsp;<a href=\"/disclaimer\" target=\"_self\" textvalue=\"免责声明\">免责声明</a>&nbsp;|&nbsp;<a href=\"/misc/4\" target=\"_self\" textvalue=\"侵删联系\">侵删联系</a>&nbsp;|&nbsp;<a href=\"/misc/10\" target=\"_blank\">DMCA</a>&nbsp;|&nbsp;<a href=\"/misc/11\" target=\"_blank\">隐私声明</a></p><p>火ICP备88888888 |&nbsp;<a href=\"https://masuit.com/sitemap.html\" style=\"white-space: normal;\">网站地图</a>&nbsp;|&nbsp;法务支持与联系：comments@whitehouse.gov |&nbsp;网站托管于火星云，基于量子网络实现火-地超光速传输，受当地法律保护！</p>');
INSERT INTO `systemsetting` VALUES (14, 1, 'ReservedName', '懒得勤快|system|admin|Administrator|root');
INSERT INTO `systemsetting` VALUES (15, 1, 'Disclaimer', '<p style=\"white-space: normal;\"><span style=\"color: rgb(255, 0, 0); font-family: Wingdings; font-size: 15px;\">l<span style=\"font-variant-numeric: normal; font-stretch: normal; font-size: 9px; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;</span></span><span style=\"color: rgb(255, 0, 0); font-family: Wingdings; line-height: 20px;\">文章内容仅供参考，所涉及的软件以具体使用情况为准！</span><br/></p><p style=\"white-space: normal;\"><span style=\"color: rgb(255, 0, 0); font-family: Wingdings; font-size: 15px;\">l<span style=\"font-variant-numeric: normal; font-stretch: normal; font-size: 9px; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;</span></span><span style=\"color: rgb(255, 0, 0); font-family: Wingdings; line-height: 20px;\">博主在此发文（包括但不限于汉字、拼音、拉丁字母）均为随意敲击键盘所出，用于检验本人电脑键盘录入、屏幕显示的机械、光电性能，并不代表本人局部或全部同意、支持或者反对观点。如需要详查请直接与键盘生产厂商法人代表联系。挖井挑水无水表，不会网购无快递。</span><br/></p><p style=\"white-space: normal;\"><span style=\"color: rgb(255, 0, 0); font-size: 15px; font-family: Wingdings;\">l<span style=\"font-variant-numeric: normal; font-stretch: normal; font-size: 9px; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;</span></span><span style=\"color: rgb(255, 0, 0); line-height: 20px;\">博主的文章没有高度、深度和广度，只是凑字数。由于博主的水平不高（其实是个菜B），不足和错误之处在所难免，希望大家能够批评指出。</span><br/></p><p style=\"white-space: normal;\"><span style=\"color: rgb(255, 0, 0);\"><span style=\"font-size: 15px; font-family: Wingdings;\">l<span style=\"font-variant-numeric: normal; font-stretch: normal; font-size: 9px; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;</span></span><span style=\"font-size: 16px;line-height:20px;\">博主是利用读书、参考、引用、抄袭、复制和粘贴等多种方式打造成自己的纯镀 24k 文章，请原谅博主成为一个无耻的文档搬运工！</span></span></p><p><span style=\"color: rgb(255, 0, 0);\"><span style=\"font-size: 15px; font-family: Wingdings;\">l<span style=\"font-variant-numeric: normal; font-stretch: normal; font-size: 9px; line-height: normal; font-family: &quot;Times New Roman&quot;;\">&nbsp;&nbsp;</span></span><span style=\"line-height: 20px;\">文章内容部分来源于互联网，不代表本人的任何立场；涉及到的软件来源于互联网，仅供个人下载使用，</span></span><span style=\"color: rgb(255, 0, 0);\">请勿用于商业用途，</span><span style=\"color: rgb(255, 0, 0);\">版权归软件开发者所有，下载后请于24小时内删除，如有真实需要请支持正版！因下载本站任何资源造成的损失，全部责任由使用者本人承担！如果你是版权方，认为本文内容对您的权益有所侵犯，请联系博主，并参照<a href=\"/misc/4\" target=\"_blank\">侵删联系</a>的说明提交相应的证明材料，待博主进行严格地审查和背景调查后，情况属实的将在三天内将本文删除或修正。</span></p>');
INSERT INTO `systemsetting` VALUES (16, 1, 'SmtpPort', '587');
INSERT INTO `systemsetting` VALUES (17, 1, 'DonateWechat', 'https://git.imweb.io/ldqk/imgbed/raw/master/2018/2/5ccadc6b53f28.jpg');
INSERT INTO `systemsetting` VALUES (18, 1, 'DonateQQ', 'https://git.imweb.io/ldqk/imgbed/raw/master/2018/2/5ccadc6c9aa5b.jpg');
INSERT INTO `systemsetting` VALUES (19, 1, 'PathRoot', '/');
INSERT INTO `systemsetting` VALUES (20, 1, 'Domain', 'masuit.com');
INSERT INTO `systemsetting` VALUES (22, 1, 'DisabledEmailBroadcast', 'true');
INSERT INTO `systemsetting` VALUES (23, 1, 'DisabledEmailBroadcastTip', '由于本站用的是免费的SMTP服务器，现在本站订阅人数过多，导致邮件无法正常发送，因此邮件订阅功能暂停使用！如果你有好用的免费的SMTP服务器推荐，欢迎联系博主！');
INSERT INTO `systemsetting` VALUES (24, 1, 'EnableDenyArea', 'true');
INSERT INTO `systemsetting` VALUES (25, 1, 'DenyArea', '苏州');
INSERT INTO `systemsetting` VALUES (26, 1, 'Scripts', '<script type=\"text/javascript\">var cnzz_protocol = ((\"https:\" == document.location.protocol) ? \"https://\" : \"http://\");document.write(unescape(\"%3Cspan id=\'cnzz_stat_icon_1260354294\'%3E%3C/span%3E%3Cscript src=\'\" + cnzz_protocol + \"s4.cnzz.com/z_stat.php%3Fid%3D1260354294%26online%3D1%26show%3Dline\' type=\'text/javascript\'%3E%3C/script%3E\"));</script>');
INSERT INTO `systemsetting` VALUES (27, 1, 'LimitIPFrequency', '60');
INSERT INTO `systemsetting` VALUES (28, 1, 'LimitIPRequestTimes', '300');
INSERT INTO `systemsetting` VALUES (29, 1, 'BanIPTimespan', '1');
INSERT INTO `systemsetting` VALUES (30, 1, 'FirewallEnabled', 'true');
INSERT INTO `systemsetting` VALUES (31, 1, 'Styles', '<meta name=\"referrer\" content=\"no-referrer\">');

-- ----------------------------
-- Table structure for userinfo
-- ----------------------------
DROP TABLE IF EXISTS `userinfo`;
CREATE TABLE `userinfo`  (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `Status` int(11) NOT NULL DEFAULT 0,
  `Username` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `NickName` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `Password` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `SaltKey` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `IsAdmin` bit(1) NOT NULL DEFAULT b'0',
  `Email` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `QQorWechat` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `Avatar` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `AccessToken` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  PRIMARY KEY (`Id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = DYNAMIC;

-- ----------------------------
-- Records of userinfo
-- ----------------------------
INSERT INTO `userinfo` VALUES (1, 0, 'masuit', '懒得勤快', '84e1338d260a7aedd8232df7f02de1f4', '3s+c1wnhqZO96G5Wh/R3W0XrOWHLntiX23XZxKEcmDh9VfVJ06AHgtdgjMUrsE3B', b'1', 'admin@masuit.com', 'admin@masuit.com', 'https://git.imweb.io/ldqk/imgbed/raw/master/20190606/db31c659cdb57dfba21e10fef1d58e50_2_3_art.png', NULL);

SET FOREIGN_KEY_CHECKS = 1;
