/*
 Navicat Premium Data Transfer

 Source Server         : localhost_5432
 Source Server Type    : PostgreSQL
 Source Server Version : 140005 (140005)
 Source Host           : localhost:5432
 Source Catalog        : myblogs_bak
 Source Schema         : public

 Target Server Type    : PostgreSQL
 Target Server Version : 140005 (140005)
 File Encoding         : 65001

 Date: 09/10/2022 20:59:08
*/


-- ----------------------------
-- Sequence structure for AdvertisementClickRecord_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."AdvertisementClickRecord_Id_seq";
CREATE SEQUENCE "public"."AdvertisementClickRecord_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE ;

-- ----------------------------
-- Sequence structure for AdvertisementClickRecord_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."AdvertisementClickRecord_Id_seq1";
CREATE SEQUENCE "public"."AdvertisementClickRecord_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE ;

-- ----------------------------
-- Sequence structure for Advertisement_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Advertisement_Id_seq";
CREATE SEQUENCE "public"."Advertisement_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Advertisement_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Advertisement_Id_seq1";
CREATE SEQUENCE "public"."Advertisement_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Category_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Category_Id_seq";
CREATE SEQUENCE "public"."Category_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Category_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Category_Id_seq1";
CREATE SEQUENCE "public"."Category_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Comment_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Comment_Id_seq";
CREATE SEQUENCE "public"."Comment_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Comment_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Comment_Id_seq1";
CREATE SEQUENCE "public"."Comment_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Donate_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Donate_Id_seq";
CREATE SEQUENCE "public"."Donate_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Donate_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Donate_Id_seq1";
CREATE SEQUENCE "public"."Donate_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for FastShare_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."FastShare_Id_seq";
CREATE SEQUENCE "public"."FastShare_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for FastShare_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."FastShare_Id_seq1";
CREATE SEQUENCE "public"."FastShare_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for InternalMessage_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."InternalMessage_Id_seq";
CREATE SEQUENCE "public"."InternalMessage_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for InternalMessage_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."InternalMessage_Id_seq1";
CREATE SEQUENCE "public"."InternalMessage_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for LeaveMessage_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."LeaveMessage_Id_seq";
CREATE SEQUENCE "public"."LeaveMessage_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for LeaveMessage_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."LeaveMessage_Id_seq1";
CREATE SEQUENCE "public"."LeaveMessage_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for LinkLoopback_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."LinkLoopback_Id_seq";
CREATE SEQUENCE "public"."LinkLoopback_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for LinkLoopback_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."LinkLoopback_Id_seq1";
CREATE SEQUENCE "public"."LinkLoopback_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Links_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Links_Id_seq";
CREATE SEQUENCE "public"."Links_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Links_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Links_Id_seq1";
CREATE SEQUENCE "public"."Links_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for LoginRecord_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."LoginRecord_Id_seq";
CREATE SEQUENCE "public"."LoginRecord_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for LoginRecord_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."LoginRecord_Id_seq1";
CREATE SEQUENCE "public"."LoginRecord_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Menu_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Menu_Id_seq";
CREATE SEQUENCE "public"."Menu_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Menu_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Menu_Id_seq1";
CREATE SEQUENCE "public"."Menu_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Misc_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Misc_Id_seq";
CREATE SEQUENCE "public"."Misc_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Misc_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Misc_Id_seq1";
CREATE SEQUENCE "public"."Misc_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Notice_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Notice_Id_seq";
CREATE SEQUENCE "public"."Notice_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Notice_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Notice_Id_seq1";
CREATE SEQUENCE "public"."Notice_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for PostHistoryVersion_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."PostHistoryVersion_Id_seq";
CREATE SEQUENCE "public"."PostHistoryVersion_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for PostHistoryVersion_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."PostHistoryVersion_Id_seq1";
CREATE SEQUENCE "public"."PostHistoryVersion_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for PostMergeRequest_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."PostMergeRequest_Id_seq";
CREATE SEQUENCE "public"."PostMergeRequest_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for PostMergeRequest_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."PostMergeRequest_Id_seq1";
CREATE SEQUENCE "public"."PostMergeRequest_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for PostTag_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."PostTag_Id_seq";
CREATE SEQUENCE "public"."PostTag_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE ;

-- ----------------------------
-- Sequence structure for PostVisitRecordStats_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."PostVisitRecordStats_Id_seq";
CREATE SEQUENCE "public"."PostVisitRecordStats_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE ;

-- ----------------------------
-- Sequence structure for PostVisitRecordStats_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."PostVisitRecordStats_Id_seq1";
CREATE SEQUENCE "public"."PostVisitRecordStats_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE ;

-- ----------------------------
-- Sequence structure for PostVisitRecord_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."PostVisitRecord_Id_seq";
CREATE SEQUENCE "public"."PostVisitRecord_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE ;

-- ----------------------------
-- Sequence structure for PostVisitRecord_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."PostVisitRecord_Id_seq1";
CREATE SEQUENCE "public"."PostVisitRecord_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE ;

-- ----------------------------
-- Sequence structure for Post_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Post_Id_seq";
CREATE SEQUENCE "public"."Post_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Post_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Post_Id_seq1";
CREATE SEQUENCE "public"."Post_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for SearchDetails_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."SearchDetails_Id_seq";
CREATE SEQUENCE "public"."SearchDetails_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE ;

-- ----------------------------
-- Sequence structure for SearchDetails_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."SearchDetails_Id_seq1";
CREATE SEQUENCE "public"."SearchDetails_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE ;

-- ----------------------------
-- Sequence structure for Seminar_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Seminar_Id_seq";
CREATE SEQUENCE "public"."Seminar_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Seminar_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Seminar_Id_seq1";
CREATE SEQUENCE "public"."Seminar_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for SystemSetting_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."SystemSetting_Id_seq";
CREATE SEQUENCE "public"."SystemSetting_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for SystemSetting_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."SystemSetting_Id_seq1";
CREATE SEQUENCE "public"."SystemSetting_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for UserInfo_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."UserInfo_Id_seq";
CREATE SEQUENCE "public"."UserInfo_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for UserInfo_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."UserInfo_Id_seq1";
CREATE SEQUENCE "public"."UserInfo_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Variables_Id_seq
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Variables_Id_seq";
CREATE SEQUENCE "public"."Variables_Id_seq" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Sequence structure for Variables_Id_seq1
-- ----------------------------
DROP SEQUENCE IF EXISTS "public"."Variables_Id_seq1";
CREATE SEQUENCE "public"."Variables_Id_seq1" 
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1;

-- ----------------------------
-- Table structure for Advertisement
-- ----------------------------
DROP TABLE IF EXISTS "public"."Advertisement";
CREATE TABLE "public"."Advertisement" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Title" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "Description" varchar(1000) COLLATE "pg_catalog"."default" NOT NULL,
  "Url" varchar(4096) COLLATE "pg_catalog"."default" NOT NULL,
  "ImageUrl" varchar(4096) COLLATE "pg_catalog"."default",
  "ThumbImgUrl" varchar(4096) COLLATE "pg_catalog"."default",
  "Price" numeric NOT NULL,
  "Types" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "CategoryIds" varchar(1024) COLLATE "pg_catalog"."default",
  "CreateTime" timestamptz(6) NOT NULL,
  "UpdateTime" timestamptz(6) NOT NULL,
  "Status" int4 NOT NULL,
  "DisplayCount" int4 NOT NULL,
  "ExpireTime" timestamptz(6),
  "RegionMode" int4 NOT NULL,
  "Regions" varchar(4096) COLLATE "pg_catalog"."default",
  "Merchant" varchar(255) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Advertisement
-- ----------------------------
INSERT INTO "public"."Advertisement" VALUES (175, '内推 | 成都喜鹊生活招聘中级.net开发工程师 11-14K·13薪', '岗位描述：负责维护公司原有系统和公司新平台开发工作；
岗位职责：1、按照进度和质量要求完成项目系统维护任务中的编码实现工作；
2、对维护模块和功能提供合理开发建议，并付诸实现。
3、按照开发规范和流程进行系统模块的开发。
公司简介：喜鹊生活是一家整体家装定制服务平台，旗下拥有华润涂料、乐易装、喜鹊生活三大品牌，业务涵盖建筑涂料、装修基础材料、家居设计、家具生产、家装施工服务等，致力于为用户提供全空间、全功能定制的整体家装解决方案。', 'https://www.zhipin.com/job_detail/baea69d6d9e4728f1XV40tS_FlBT.html?ka=comp_joblist_1', 'null', '/static/images/ujcgkc3jad4w.webp', 500.00, '2,3,4', '38,34,7,41,6,71', '2022-03-02 17:15:26+08', '2022-05-12 23:51:25+08', 1, 123, '2099-12-31 08:00:00+08', 1, '成都|Chengdu', NULL);
INSERT INTO "public"."Advertisement" VALUES (95, '27寸新大金刚电竞显示器，2k/240Hz/NanoIPS/gsync，LM270WQB-SSA1，外星人同款面板', '27寸240Hz 1ms IPS新电竞屏，12bit色深680亿色新高度，支持G-Sync，HDR400，LM270WQB-SSA1面板，外星人同款面板！', 'https://item.taobao.com/item.htm?id=640733907400', 'null', 'https://img.alicdn.com/imgextra/i4/2206799812/O1CN01mGsJFL2MLwnoMK3gD_!!2206799812.jpg', 400.00, '2,3,4', NULL, '2021-03-16 05:54:45+08', '2022-05-12 23:48:55+08', 1, 2963, '2033-05-06 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (159, 'DDDD.COOL——超低价网络中继服务，解锁流媒体，不限带宽，价格低至4.98元/100GB', '按量计费套餐，不限时间，支持10以上设备同时连接，不限速度，这瓜保熟。最新Trojan协议 移动千兆中转 ，负载均衡节点，告别掉线 不卡顿 即使现在特殊时期 服务依旧稳定。外网加速自由切换节点，售后到位，任何时间4k视频无压力防封，新用户注册试用一星期！六块钱能用一年！偶尔不太稳定，但这价格实在太香了！', '/dddd.cool', 'https://img14.360buyimg.com/ddimg/jfs/t1/210618/25/7836/336711/61825e43E5bad3ad1/491c87e570b6e177.jpg', '/static/images/2021/11/03/image1_1742.png', 200.00, '2,3,4', '', '2021-11-04 02:03:14+08', '2022-05-12 23:47:42+08', 1, 1567, '2099-12-27 08:00:00+08', 2, '江苏|浙江|重庆|GOIP', NULL);
INSERT INTO "public"."Advertisement" VALUES (132, '新品上市，专属价3300元起，32寸4k144Hz IPS新电竞屏旗舰来了！直降200元！完美屏送升降底座！', '32寸新大金刚电竞显示器，4k/144Hz/gsync，M315DCA-K7B，宏碁掠夺者同款面板。本站访客下单可享受直降200元的专属优惠！还送升降底座！', 'https://item.taobao.com/item.htm?id=655098231988', 'null', 'https://gd2.alicdn.com/imgextra/i3/2206799812/O1CN01SL9dnG2MLwtnDOKCN_!!2206799812.jpg_400x400.jpg', 400.00, '2,3,4', NULL, '2021-09-01 07:05:16+08', '2022-05-12 23:49:34+08', 1, 2964, '2033-04-01 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (198, '618 大促！Downie 4 限时 7 折，仅需 29.4 元起', 'Downie 4 是一款 Mac 上备受好评的视频下载利器，支持 Youtube、B 站、优酷、爱奇艺、腾讯视频 等 1000+ 国内外视频流媒体网站。即日起至 2022 年 6 月 21 日 618 大促期间，Downie 4 限时 7 折，下单 Downie 4 到手价只需 29.4 元起。', 'https://store.lizhi.io/site/products/id/280/cid/tkdempuy', '/static/images/usgswxyoe4u8.png', '/static/images/usgsxc6vklc0.png', 100, '4,3,2,1', NULL, '2022-06-02 09:42:41.504914+08', '2022-06-02 10:10:14.364136+08', 1, 613, '2022-06-21 10:10:04+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (43, '最稳定的体验最好的小众高质量的v2ray/ssr网络中继服务，限时开放注册！', '严格限制人数的良心机场，限时开放注册，赶紧上车吧！Re0x上线的海外节点均为高质量独享 VPS，无大量部署低成本 AWS、Azure、GCP 薅的羊毛机；国内节点均为高优先级出口 NAT，上海电信 CN2 和上海联通 AS4837；具备良好的稳定性和可持续发展性。', 'https://elk.re0x.eu.org/auth/register?code=IEhr', 'https://cdn.jsdelivr.net/gh/ldqk/imgbed/2020/02/29/sisr6grdpblt.png', 'https://pic.rmb.bdstatic.com/bjh/6e36c2bd9923c4f99363aa02df558f9d.png', 200.00, '2,3,4', NULL, '2020-02-29 18:48:08+08', '2022-05-12 23:48:18+08', 14, 0, '2099-12-27 08:00:00+08', 2, '江苏|浙江|重庆|GOIP', NULL);
INSERT INTO "public"."Advertisement" VALUES (186, '高端首选国际全球加速网络——GaCloud全球加速，国际Global Accelerator专线加速网络', 'GaCloud 从事于国际网络加速行业多年，拥有丰富的经验，采用流行的专用加密协议，中国国内优化线路，可以保证99%的时间稳定流畅加速体验，是中国大陆地区网络加速用户的不二之选。', '/gacloud', '/static/images/unn0dltihm2o.webp', '/static/images/unn0rtqkcxds.png', 300.00, '1,2,3,4', NULL, '2022-04-15 00:49:40+08', '2022-05-17 07:10:44+08', 1, 5251, '2099-12-31 08:00:00+08', 2, '成都|资阳|内江|北京|江苏|苏州|扬州|浙江|重庆|GOIP|BeiJing|Jiangsu|Zhejiang|Chongqing|Suzhou|Yangzhou|Chengdu|Ziyang|Neijiang', NULL);
INSERT INTO "public"."Advertisement" VALUES (173, '知乎热门：如何评价苏州思杰马克丁软件公司？', '知乎热门问题：《如何评价苏州思杰马克丁软件公司？》，快速充分了解该公司的背景，赶快来围观和发表你的观点吧！', 'https://www.zhihu.com/question/46746200', NULL, 'https://cn.technode.com/wp-content/blogs.dir/18/files/2019/08/zhihu-1.jpg', 100.00, '2,4', '46,7,43,45,42,15', '2022-02-11 22:30:00+08', '2022-05-12 23:47:32+08', 1, 1789, '2099-12-31 08:00:00+08', 2, '江苏|苏州|无锡|扬州|南京|GOIP|makeding|com|广州', NULL);
INSERT INTO "public"."Advertisement" VALUES (49, '优云666，多年老牌高速全隧道多节点IPLC超大国际机场，可白嫖！', '真正大鸡场，100多个节点，V2ray节点50多个。港台美日新均有白嫖节点，每日签到送1-7G流量。多条BGP中转/Azure/Dmit/HKT/Hinet/多点IPLC/保证高端用户使用需求。', 'https://youyun00.com/auth/register?code=AGTE', 'https://cdn.jsdelivr.net/gh/ldqk/imgbed/2020/12/08/1376c00022689e3b12aa4.jpeg', 'https://ae01.alicdn.com/kf/Hc5ec1fb4b47249edbd3067fb43e2027dr.jpg', 800.00, '1,2,3,4', NULL, '2020-04-03 23:02:52+08', '2022-05-12 23:51:17+08', 14, 0, '2099-12-27 08:00:00+08', 2, '江苏|浙江|重庆|GOIP', NULL);
INSERT INTO "public"."Advertisement" VALUES (86, '晚高峰25W的4K机场！桔子云，速鹰666的分机场，高速全隧道IPLC超大国际机场，可白嫖！', 'Free实现全设备、全平台全家免费上网！高速的加密隧道网络，毫无压力上网！值得推荐的最新国际网络加速利器！（关联SSR/SS/V2RAY/Trojan）', 'https://juziyun66.com/auth/register?code=vgqI', '/static/images/uf8fy64m58g0.jpg', '/static/images/2022/01/20/juzicloud_2027.jpg', 600.00, '1,2,3,4', NULL, '2021-01-28 21:30:30+08', '2022-04-29 07:55:05+08', 14, 0, '2099-12-28 08:00:00+08', 2, '江苏|浙江|重庆|GOIP', NULL);
INSERT INTO "public"."Advertisement" VALUES (109, '蜜桃云，晚高峰25W的4K机场！优云666的分机场，高速全隧道IPLC超大国际机场，可白嫖！', 'Free实现全设备、全平台全家免费翻墙！高速的VPN免费节点毫无压力科学上网！2021，值得推荐的最新翻墙利器！（关联SSR/SS/V2RAY/Trojan）', 'https://mitaocloud.net/auth/register?code=hrBc', 'https://cdn.jsdelivr.net/gh/ldqk/imgbed/2020/12/08/1375d0002efa167c68405.jpeg', 'https://img11.360buyimg.com/ddimg/jfs/t1/193402/21/12638/776301/60ebafe7E2b5e9519/276a9ee454c88863.png', 500.00, '1,2,3,4', NULL, '2021-05-25 18:42:26+08', '2021-11-12 17:18:12+08', 14, 0, '2099-12-28 08:00:00+08', 2, '江苏|浙江|重庆|GOIP', NULL);
INSERT INTO "public"."Advertisement" VALUES (123, '飞速云，晚高峰25W的4K机场！极客云的分机场，高速全隧道IPLC超大国际机场，可白嫖！', '新用户注册送500M免费流量！高速的VPN免费节点毫无压力科学上网！2021，值得推荐的最新翻墙利器！（关联SSR/SS/V2RAY/Trojan）', 'https://feisucloud.net/auth/register?code=1nz8', 'https://cdn.jsdelivr.net/gh/ldqk/imgbed/2020/12/08/1375d0002efa167c68405.jpeg', 'https://ae01.alicdn.com/kf/H2e33f8474add4e27a7925884be09c70bp.jpg', 500.00, '1,2,3,4', NULL, '2021-06-24 06:45:12+08', '2021-11-12 17:17:27+08', 14, 0, '2099-12-29 08:00:00+08', 2, '江苏|浙江|重庆|GOIP', NULL);
INSERT INTO "public"."Advertisement" VALUES (199, '618 大促！MarginNote 3 限时 75 折，仅需 51.75 元起', '学习知识，不只在于获取，归纳整理同样重要，从而达到真正的掌握。MarginNote 是一款功能强大的阅读和学习软件，将 PDF / EPUB 阅读器和多种学习工具集成起来。从不同的维度将知识进行重组、连接，学习思路更加清晰。即日起至 6 月 21 日 618 大促期间 MarginNote 3 限时 75 折，仅需 51.75 元起', 'https://store.lizhi.io/site/products/id/42/cid/tkdempuy', '/static/images/usgt2hxa9udc.png', '/static/images/usgt2yi909a8.png', 100, '1,2,3,4', NULL, '2022-06-02 09:44:27.92289+08', '2022-06-02 10:11:06.407222+08', 1, 497, '2022-06-22 00:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (200, '618 大促！Mac 平台优秀的 PDF 阅读编辑工具 PDF Expert 买断仅需 129 元', 'PDF Expert 是 macOS 上知名的 PDF 编辑工具，它集阅读、创建、编辑批注等功能于一身。但仍拥有美观界面与轻巧易用的特性，一经发布便获得众多好评，多次被 Apple 编辑推荐，并当选 Mac App Store 年度最佳应用。即日起至 6 月 21 日 618 大促期间，下单仅需 129 元，叠加满减只要 124 元！', 'https://store.lizhi.io/site/products/id/61/cid/tkdempuy', '/static/images/usgt78edsxz4.png', '/static/images/usgt7o1mwow0.png', 100, '2,1,3,4', NULL, '2022-06-02 09:45:55.946825+08', '2022-06-02 10:11:25.065756+08', 1, 501, '2022-06-21 10:11:21+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (36, '买正版软件，上数码荔枝！', '数码荔枝专注于分享最新鲜优质的正版软件，更加合理实惠的价格和更优质的服务，领取和本站联合的专属优惠券，立减5元。', 'https://store.lizhi.io/site/index/cid/tkdempuy', 'https://img14.360buyimg.com/ddimg/jfs/t1/208129/31/4884/480608/6165455bEac435e7e/e1ac3b9ecaf7633e.png', 'https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2020/02/11/sh0smjl8m8e9.png', 300.00, '1,2,3,4', NULL, '2020-01-25 17:56:44+08', '2022-03-27 00:09:46+08', 14, 0, '2022-03-31 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (94, '新品上市，1650元起，25寸420Hz 0.5ms IPS新电竞屏旗舰来了！直降150元！完美屏！', '25寸420Hz 0.5ms IPS新电竞屏，支持G-Sync，HDR400，M250HAN03.2面板，外星人同款面板，最高亮度可达430nit！本站访客下单可享受直降150元的专属优惠！', 'https://item.taobao.com/item.htm?id=635580236155', 'https://pic.rmb.bdstatic.com/bjh/84d70f8e6a876e80713416e8cb430439.jpeg', '/static/images/2022/04/27/O1CN01CSy1xU1vXrcaB34TG_!!179526183_112019.jpg', 400.00, '1,2,3,4', NULL, '2021-03-09 19:36:04+08', '2022-05-12 23:49:00+08', 1, 6457, '2099-12-30 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (77, '这位置很便宜，干爹就是你！', '这位置很便宜，干爹就是你！近年来本站内容已获得众多网友们的认可和支持，广告效益也在持续逆势上扬！', '/misc/17', '', '/static/images/uq6q57yfqtq8.webp', 10.00, '2,3,4', NULL, '2020-12-15 07:12:09+08', '2022-05-12 23:45:50+08', 1, 133, '2099-12-30 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (201, '618 大促！多平台广告拦截软件 AdGuard 限时 5 折起仅需 20 元起', '网络垃圾广告令人深恶痛绝，还在默默忍受？不仅影响心情，还存在安全隐患。何不使用 AdGuard 来帮你搞定关于广告的一切。即日起至 6 月 21 日 618 大促期间，下单仅需 20 元起，赶快来购买吧！', 'https://store.lizhi.io/site/products/id/31/cid/tkdempuy', '/static/images/usgtcm05hj40.png', '/static/images/usgtcx4e7tog.png', 100, '4,3,2,1', NULL, '2022-06-02 09:47:32.501425+08', '2022-06-02 09:47:32.501487+08', 1, 484, '2049-12-31 00:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (57, '100% AdobeRGB的4k IPS显示器，LM270WR4面板,type c一线通，色彩最强4k完美旗舰！', '对标明基PD2720U，100%AdobeRGB，HDR400,10bit色深，LM270WR4-SSA1面板，专业设计屏，支持Type-C一线通PD65w，色彩最强4k完美旗舰，立即购买，享本站渠道专属优惠！', 'https://item.taobao.com/item.htm?id=613736662335', 'https://gd1.alicdn.com/imgextra/i3/2206799812/O1CN01P0qedm2MLwnwyJki9_!!2206799812.jpg', 'https://gd4.alicdn.com/imgextra/i2/2206799812/O1CN01TQdGmz2MLwpBY5719_!!2206799812.jpg', 400.00, '2,3,4', '', '2020-07-01 21:09:59+08', '2022-05-12 23:50:49+08', 1, 3280, '2099-12-30 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (172, '畅游云，高性价比的国际网络加速服务，低至9.9元/100GB', '稳定老牌机场，1000M独享高峰期稳定不限速，顶级落地原生IP，全高速BGP节点，真正大鸡场，全球多个数据中心，游戏加速线路，独家智能技术，高速传输稳定不掉，体验顶级服务，无视晚高峰，保证高端用户使用需求。全线解锁各流媒体，不限带宽，极致体验，强烈推荐！新会员招募活动进行中......', 'https://easypopo.com/#/register?code=ymxSNEiC', 'null', '/static/images/uhd6lv2hkuf4.jpg', 300.00, '2,3,4', NULL, '2022-02-09 17:43:56+08', '2022-04-29 07:39:27+08', 1, 2980, '2099-12-31 08:00:00+08', 2, '江苏|浙江|重庆|GOIP', NULL);
INSERT INTO "public"."Advertisement" VALUES (205, '618 大促！剪贴板管理工具 PasteNow 限时 7 折购，仅需 34.3 元', '为了复制粘贴多条内容，还在不同窗口页面反复跳转？或者复制新内容，旧数据就被覆盖了？这样操作效率太低啦。你的 Mac 急需一个管理剪贴板历史的工具，美观好用的 PasteNow 值得一试！智能处理剪贴板内容，效率更上一层楼！即日起至 6 月 21 日 618 大促期间 PasteNow 迎来 7 折促销，仅需 34.3 元即可买断永久使用。', 'https://store.lizhi.io/site/products/id/474/cid/tkdempuy', '/static/images/usgtzx69yo74.png', '/static/images/usgu07txv85c.png', 100, '4,3,2,1', NULL, '2022-06-02 09:54:47.282804+08', '2022-06-02 10:11:16.76369+08', 1, 557, '2022-06-22 00:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (194, '给「荔」一夏 618 正版软件大促，秒杀 + 折扣 + 满减一起来袭！', '五月进入尾声，618 各种活动已经陆续开始了，又是年中采购，清空购物车的好机会。除了可以买吃的、用的实物，趁 618 入手虚拟商品，如软件会员、正版授权码同样有巨多优惠，还不用担心快递因疫情延误，买完就能用。我们的朋友「数码荔枝」今年提前开启了 618 给「荔」一夏大促活动，让大家更早享受特价，和其他抢购不撞车。2022 年 5 月 30 日至 6 月 21 日前往购买，就能享受各种优惠价格，这个 618 带几款正版软件回家吧！', 'https://store.lizhi.io/site/index/cid/tkdempuy', '/static/images/usgsaz9izfnk.png', '/static/images/usgsbee1ul8g.png', 100, '1,2,3,4', NULL, '2022-06-02 09:36:13.694251+08', '2022-06-02 09:36:13.697945+08', 1, 573, '2022-06-22 00:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (37, '极客云，速鹰666的分机场，高速全隧道多节点IPLC超大国际机场，可白嫖！', '真正大鸡场，100多个节点，V2ray节点50多个。港台美日新均有白嫖节点，每日签到送1-7G流量。多条BGP中转/Azure/Dmit/HKT/Hinet/多点IPLC/保证高端用户使用需求。', 'https://jike138.com/auth/register?code=j33L', '/static/images/uf8fzi5rutj4.jpeg', '/static/images/ufbtvlhrxszk.jpg', 300.00, '1,2,3,4', NULL, '2020-03-22 22:08:34+08', '2022-04-29 07:39:34+08', 1, 5174, '2099-12-28 08:00:00+08', 2, '江苏|浙江|重庆|GOIP', NULL);
INSERT INTO "public"."Advertisement" VALUES (18, '27寸4k 144Hz IPS freesync HDR顶级旗舰电竞显示器，战未来完美旗舰！', '目前世界顶级配置的27寸4k 144Hz IPS 友达M270QAN02.2面板，对标型号：pg27uq、x27、xv273k电竞+设计显示器，豪华配置，至尊体验，支持单dp上4k@144Hz以及开启freesync和HDR！立即购买，享本站渠道专属优惠！', 'https://item.taobao.com/item.htm?id=613487817622', 'null', 'https://gd2.alicdn.com/imgextra/i3/2206799812/O1CN01356tcC2MLwnNmhMDP_!!2206799812.jpg', 400.00, '2,3,4', '', '2019-11-07 07:11:03+08', '2022-05-12 23:49:24+08', 1, 2965, '2099-12-30 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (197, '618 大促！ 跨平台 Markdown 编辑器 Typora 买断仅需 80.1 元', 'Typora 是一款适配 Win / Mac 平台的 Markdown 编辑器，支持实时预览，所见即所得。支持 LaTeX 公式、版本控制、流程图等功能，为 Markdown 写作带来丝般顺滑的体验！618 大促期间，Typora 仅需 80.1 元即可买断当前版本，新注册用户领券还可立减 5 元，仅需 75.1 元！', 'https://store.lizhi.io/site/products/id/520?cid=tkdempuy', '/static/images/usgssmnwnjsw.png', '/static/images/usgsszx2r9q8.png', 100, '1,2,3,4', NULL, '2022-06-02 09:41:25.005296+08', '2022-06-02 09:41:25.005363+08', 1, 517, '2022-06-22 00:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (141, '三威显示器淘宝店铺双十二活动满1999元立减100元，和本站专属优惠叠加最高可立减250元！活动截止2021.12.13，高刷电竞高色域屏应有尽有！', '三威科技淘宝店铺显示器品类双十二活动已经开始啦，180/240/420Hz高刷电竞屏，高色域设计专业屏应有尽有！活动截止2021.12.13，保价双十二，期间下单单笔订单满1999元立减100元，同时还能享受本站的50元专属渠道优惠，最高可直降450元RMB，这次只为销量，不为赚钱！记得联系客服MM报专属优惠码：masuit', 'https://sanvtech.taobao.com/', 'https://gd1.alicdn.com/imgextra/i3/2206799812/O1CN01SL9dnG2MLwtnDOKCN_!!2206799812.jpg_400x400.jpg', 'https://gd1.alicdn.com/imgextra/i3/2206799812/O1CN01SL9dnG2MLwtnDOKCN_!!2206799812.jpg_400x400.jpg', 2200.00, '2,3,4', '', '2021-10-28 00:18:09+08', '2021-12-05 05:00:32+08', 14, 0, '2021-12-13 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (195, '摸鱼 / 效率工具？Mac 菜单栏浏览器 MenubarX 独家折扣啦！', '用 Mac 设备的小伙伴对顶部菜单栏一定不陌生，各种软件、系统图标都展示在这里，位置很显眼。但是在菜单栏上用的浏览器你听说过吗？没错，就是 MenubarX：一款安装后在 macOS 菜单栏就可使用的小窗浏览器。在地址栏输入网址就能快速直达想要的网站，平时还能收起只显示菜单栏图标，小巧轻量点开即用，效率办公或是摸鱼休息的双重利器！现在数码荔枝 618 活动正在进行中，MenubarX Pro只要 29 元即可买断', 'https://store.lizhi.io/site/products/id/543/cid/tkdempuy', '/static/images/usgshda1dwqo.png', '/static/images/usgshq2wnhfk.png', 100, '4,3,2,1', NULL, '2022-06-02 09:37:52.403093+08', '2022-06-02 10:11:45.152648+08', 1, 663, '2022-06-21 10:11:36+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (185, '内推 | 成都喜鹊生活招聘web前端开发工程师 10-13K·13薪', '岗位描述：负责维护公司原有系统和公司新平台开发工作；
岗位职责：1、按照进度和质量要求完成项目系统维护任务中的编码实现工作；
2、对维护模块和功能提供合理开发建议，并付诸实现。
3、按照开发规范和流程进行系统模块的开发。
公司简介：喜鹊生活是一家整体家装定制服务平台，旗下拥有华润涂料、乐易装、喜鹊生活三大品牌，业务涵盖建筑涂料、装修基础材料、家居设计、家具生产、家装施工服务等，致力于为用户提供全空间、全功能定制的整体家装解决方案。', 'https://www.zhipin.com/job_detail/9f26e2190003980e1XZ63Nu4EFFX.html', 'null', '/static/images/ujcgkc3jad4w.webp', 500.00, '2,3,4', '38,32,34,7,41,6,73', '2022-04-11 17:54:26+08', '2022-05-12 23:51:30+08', 1, 80, '2099-12-31 08:00:00+08', 1, '成都|Chengdu', NULL);
INSERT INTO "public"."Advertisement" VALUES (188, '成都找工作防坑公司指南，曝光最新公司', '免责声明：本群内容系群友个人填写，不代表本群及群主观点；请各位群友客观、公正发表吐槽言论；若有不实，责任自负。', 'https://docs.qq.com/sheet/DZVVwaFlscVFhYkJy', NULL, '/static/images/uqf0fnywurr4.webp', 200.00, '2,3,4', NULL, '2022-05-13 01:23:10+08', '2022-05-16 17:29:22+08', 1, 18, '2049-12-31 08:00:00+08', 1, '成都|Chengdu', NULL);
INSERT INTO "public"."Advertisement" VALUES (142, 'Synergy 为你的键鼠升个级，一套键盘鼠标轻松控制多台电脑！', '如果你的桌子上放置了多台电脑，为了分别控制每台设备，最常规的操作就是为每一台都插上一套键鼠，而此时你的桌面也被多个键盘鼠标占去了很大一部分空间。只要有 Synergy 一个软件即可将你手头的普通键盘鼠标，升级为可以跨设备操控多台电脑的键鼠，中国特惠价 59 元，升级专业版享受 SSL 加密传输仅需 99 元。', 'https://store.lizhi.io/site/products/id/511/cid/tkdempuy', 'https://img10.360buyimg.com/ddimg/jfs/t1/207316/10/8941/65285/6179fc07E7e35e25c/550d8e82e853d2dd.png', 'https://img12.360buyimg.com/ddimg/jfs/t1/221486/6/297/24436/6179fc07Edc1279fb/53cfb88839ca479d.png', 100.00, '1,2,3,4', NULL, '2021-10-28 17:26:23+08', '2022-05-12 23:46:11+08', 1, 3132, '2022-06-30 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (8, '超值性价比的25/27/32寸的DIY电竞液晶显示器，1350元起，180/240/420Hz高刷电竞屏，高色域设计专业屏应有尽有，立即购买，享本站渠道专属优惠！', '超高性价比的diy显示器，对标大金刚，小金刚等，一半的价格，完美的体验，LM270WQA，LM270WR4，LM315WR1-SSB1，M270QAN02.3，M250HAN03.2，LM270WF9，M270KCJ-K7E等。价格仅在1300-3900人民币，对标市场2500-9000机型。只赚手工费，每台机器综合利润不超过售价的10%！', 'https://sanvtech.taobao.com/', 'https://img10.360buyimg.com/ddimg/jfs/t1/209969/34/3548/459332/615b2470E611028e3/d72690b908257e73.jpg', 'https://gd1.alicdn.com/imgextra/i1/82940726/TB2JcI.gpuWBuNjSspnXXX1NVXa_!!82940726.jpg_400x400.jpg', 500.00, '1,2,3,4', '', '2020-01-05 03:59:57+08', '2022-05-12 23:49:16+08', 1, 7302, '2099-12-29 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (98, 'Microsoft365/Office365家庭版拼车又来啦！', '去年四月 Office 365 升级为 Microsoft 365，云服务的普及让它逐渐成为主流，并带来了更多用户权益，原价 498 元，现在前往「数码荔枝」软件商店购买Microsoft 365仅需99 元，新注册用户还可领取 5 元优惠卷，只需94 元更便宜。', 'https://store.lizhi.io/site/products/id/335/cid/tkdempuy', 'https://img11.360buyimg.com/ddimg/jfs/t1/169263/30/22972/1095185/61874009Edb93a4af/587e987bacb179f6.png', 'https://img11.360buyimg.com/ddimg/jfs/t1/169155/13/23051/369727/61874008E052de351/0cc32b5c029e19d0.png', 100.00, '1,2,3,4', '46,7,2,47,45,18,42,6,15', '2021-04-09 20:51:58+08', '2022-05-12 23:46:16+08', 14, 4514, '2023-01-10 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (83, '买 Eagle 素材管理工具送 40G 素材包', 'Eagle 是全能、高效的素材管理工具，支持 macOS 和 Windows 双系统，现在购买仅 199 元，新注册用户再享 5 元立减优惠，194 元即可到手，再送超 40G 价值百元的 Eagle 素材包！', 'https://store.lizhi.io/site/products/id/38/cid/tkdempuy', 'https://img10.360buyimg.com/ddimg/jfs/t1/110564/1/19343/560655/615b23dfEbc2bd237/4d3ce37007c72e2a.jpg', 'https://img11.360buyimg.com/ddimg/jfs/t1/205512/36/14408/54394/61873fbeE075a0856/557551b6dfb227d0.png', 100.00, '1,2,3,4', '46,7,4,45,42,6,15,49,28', '2020-12-24 17:33:14+08', '2022-05-12 23:46:27+08', 14, 0, '2099-12-31 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (75, '哔哩哔哩哲♂学好声音离线缓存分享', '哔哩哔哩越来越多的鬼畜视频被和谐，尤其是哲♂学视频是重灾区，说不定以后再无鬼畜，为了给自己再留点最后的乐趣，赶紧缓存吧。现在也就只能在自己的电脑上看点离线弹幕找乐趣了，但这不够自♂由！博主特意奉献自己已经缓存的部分优秀鬼畜视频作品，以及弹幕。', '/1425', NULL, 'https://img12.360buyimg.com/ddimg/jfs/t1/201813/29/5977/225619/613af5ecE3d94675c/da1d91ebcc1f4883.png', 100.00, '2,3,4', '', '2020-12-08 21:40:51+08', '2022-05-12 23:47:52+08', 1, 1002, '2099-12-31 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (206, '618 大促！图片转文字工具「白描」限时 20 元起', '白描，像猫一样灵动的 OCR 扫描识别神器。具备高准确度的文字识别、文字翻译、表格识别转Excel、文件批量扫描等功能。工作中经常会用到扫描件，想要免去一趟趟跑打印室的麻烦。不妨使用「白描」，扫描识别翻译个个在行！618 大促期间，「白描」普通会员仅需 20 元，黄金会员仅需 25 元！', 'https://store.lizhi.io/site/products/id/36/cid/tkdempuy', '/static/images/usgu4q72rksg.png', '/static/images/usgu55sdy60w.png', 100, '4,3,2,1', NULL, '2022-06-02 09:56:21.967246+08', '2022-06-02 10:08:19.611748+08', 1, 494, '2022-06-21 10:08:16+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (29, '超级金刚电竞IPS显示器，最强2k旗舰，LM270WQA，2k@180Hz 1ms GTG，完美屏！', '支持2k 144Hz 10bit HDR freesync/gsync同时开启，新驱动板对显示面板的色彩调校更加精确！功耗更低，更加节能！立即购买，享本站渠道专属优惠！', 'https://item.taobao.com/item.htm?id=613209328249', 'https://cdn.jsdelivr.net/gh/ldqk/imgbed/2020/12/08/138c50000042b4d0d6357.jpeg', 'https://gd4.alicdn.com/imgextra/i3/2206799812/O1CN01xEm0hn2MLworNKPee_!!2206799812.jpg', 400.00, '1,2,3,4', '', '2020-01-02 01:27:55+08', '2022-05-12 23:50:04+08', 1, 6548, '2099-12-29 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (204, '618 大促！Mac 文件管理器 QSpace 限时 85 折，仅需 41.65 元起！', '使用 Mac 的小伙伴，有多少人还在用原生的访达管理文件？虽然已经满足基本需求，但仍有一些槽点：不支持多视图查看、地址栏编辑不够直观、连接服务器仅只读等。强烈安利一款单窗口多视图文件管理器：QSpace，拥有连接云服务器、右键增强、文件暂存等诸多实用自定义功能。同类产品 Path Finder，订阅一年就要支付约 190 元，618 大促期间， QSpace 买断只要 41.65 元起，抢购就趁现在！新用户还能领券再省 5 元！', 'https://store.lizhi.io/site/products/id/534/cid/tkdempuy', '/static/images/usgtvi5z5hq8.png', '/static/images/usgtvuiokpvk.png', 100, '4,3,2,1', NULL, '2022-06-02 09:53:26.917521+08', '2022-06-02 10:08:28.345465+08', 1, 522, '2022-06-21 10:08:24+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (202, '618 大促！Mac 端的开关合集工具 One Switch 限时 7 折，仅需 20.3 元起', 'One Switch 是 Mac 端的多合一开关合集工具，常驻顶部菜单栏，可以快速切换不同的设置，打开多种功能。一键切换，拒绝繁琐，快来体验这款让 Mac 更好用的工具吧！即日起至 6 月 21 日 618 大促期间， One Switch 限时 7 折仅需 20.3 元起，5 设备版也只要 69.3 元。', 'https://store.lizhi.io/site/products/id/271/cid/tkdempuy', '/static/images/usgtmra0ya68.png', '/static/images/usgtn2591rsw.png', 100, '4,3,2,1', NULL, '2022-06-02 09:50:41.739044+08', '2022-06-02 10:10:47.922112+08', 1, 461, '2022-06-21 10:10:41+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (203, '618 大促！搜索神器 Listary 6 买断仅需 75 元', 'Listary 是一款 Win 平台文件搜索工具，只需双击 Ctrl 就能快速找到散落在电脑各地的文件、程序、图片，从此告别龟速的系统自带搜索功能。即日起至 6 月 21 日大促期间，Listary 6 买断仅需 75 元，荔枝商城新注册用户还能再减 5 元！只要 70 元即可到手。', 'https://store.lizhi.io/site/products/id/58/cid/tkdempuy', '/static/images/usguuimv3wu8.png', '/static/images/usgtrdyyin7k.png', 100, '4,3,2,1', NULL, '2022-06-02 09:52:02.824679+08', '2022-06-02 10:04:25.688457+08', 1, 533, '2022-06-21 10:04:21+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (133, '新品上市，专属价3200元起，27寸2k240Hz IPS新电竞屏旗舰来了！直降200元！', '27寸新大金刚电竞显示器，2k/240Hz/gsync，M270DTN02.7，外星人同款面板。本站访客下单可享受直降200元的专属优惠！', 'https://item.taobao.com/item.htm?id=613209328249', 'null', 'https://gd2.alicdn.com/imgextra/i3/2206799812/O1CN01SL9dnG2MLwtnDOKCN_!!2206799812.jpg_400x400.jpg', 400.00, '2,3,4', NULL, '2021-09-01 07:06:43+08', '2022-05-12 23:50:58+08', 1, 2861, '2099-12-30 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (184, '【莆田耐克代工鞋厂】顺丰得物发货空军￥65，万款货源【点击进入】专柜1.1！', '莆田珂珂鞋厂一件包邮，免费代理/自家工厂/匡威万斯￥75万款货源，可以免费发得物京东快递。本店主打中高端品质 同款鞋子 衣服 包包 手表 耳机 香水 口红等 都有多种价格的货 不同厂家生产的 价格越高的细节做工 用料方面更好，不要认为高仿的品质就不行 拿耐克AJ1来说 一双正品两三千的 我们这四五百的版本就能做到各方面用料 细节做工一样的 正品上万的 高仿的八九百就能做到完全一样 一双鞋子成本只有那么多 我们砍掉的是品牌溢价~', '/2129', '', '/static/images/2022/04/10/886B4CCFA39D0C65FC9601D4FB719BDB_1130.jpg', 600.00, '2,3,4', '', '2022-04-10 21:31:06+08', '2022-05-11 07:29:02+08', 1, 4376, '2022-06-11 07:59:59+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (196, 'Microsoft365/Office365家庭版拼车又来啦！618 大促！Office 拼车仅需 89 元', '去年四月 Office 365 升级为 Microsoft 365，云服务的普及让它逐渐成为主流，并带来了更多用户权益，原价 498 元，现在前往「数码荔枝」软件商店购买Microsoft 365仅需89 元，新注册用户还可领取 5 元优惠卷，只需84元更便宜。更重要的是 Office 365​ 每账号可激活 5 台设备，支持在移动端使用，比 Office 2021 更加方便。Office 365 现已升级为 Microsoft 365，并加入了更多新服务。', 'https://store.lizhi.io/site/products/id/335/cid/tkdempuy', '/static/images/usgsn5e2c8hs.png', '/static/images/usgsnjnigv7k.png', 100, '1,2,3,4', '', '2022-06-02 09:40:04.172811+08', '2022-06-02 09:40:04.172866+08', 1, 658, '2022-06-21 09:39:51+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (174, '哔哩哔哩——免费.NET 6视频教程，.Net Core 2022视频教程，杨中科主讲', '时隔十年，杨中科老师再来录制一套.NET教程。全部免费，没有套路。只为最爱的.NET6，只为跨平台的.NET Core。', 'https://www.bilibili.com/video/BV1pK41137He', 'null', '/static/images/uhvuf66aujgg.jpg', 200.00, '2,3,4', '38,34,7,6,28', '2022-02-15 23:22:33+08', '2022-05-12 23:47:26+08', 1, 5217, '2099-12-31 08:00:00+08', 0, NULL, NULL);
INSERT INTO "public"."Advertisement" VALUES (171, '跨平台 Markdown 编辑器 Typora 独家上架数码荔枝，新用户券后仅需 84 元', 'Typora 是一款适配 Windows / macOS / Linux 平台的 Markdown 编辑器，编辑实时预览标记格式，所见即所得，轻巧而强大。经过长达 6 年的测试，Typora 近期正式发布 1.0 版本，终于进入正式版时代并开启付费模式。现仅需 89 元即可买断当前版本，新注册用户领券还可立减 5 元，仅需 84 元！', 'https://store.lizhi.io/site/products/id/520/cid/tkdempuy', '/static/images/uf8f7pg2a328.jpg', 'null', 100.00, '1', '', '2022-01-20 05:33:19+08', '2022-05-12 23:45:58+08', 1, 4814, '2022-12-31 08:00:00+08', 0, NULL, NULL);

-- ----------------------------
-- Table structure for AdvertisementClickRecord
-- ----------------------------
DROP TABLE IF EXISTS "public"."AdvertisementClickRecord";
CREATE TABLE "public"."AdvertisementClickRecord" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE
),
  "Referer" varchar(4096) COLLATE "pg_catalog"."default",
  "IP" varchar(128) COLLATE "pg_catalog"."default",
  "Time" timestamptz(6) NOT NULL,
  "AdvertisementId" int4 NOT NULL,
  "Status" int4 NOT NULL,
  "Location" varchar(512) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of AdvertisementClickRecord
-- ----------------------------

-- ----------------------------
-- Table structure for Category
-- ----------------------------
DROP TABLE IF EXISTS "public"."Category";
CREATE TABLE "public"."Category" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Name" varchar(64) COLLATE "pg_catalog"."default" NOT NULL,
  "Description" varchar(512) COLLATE "pg_catalog"."default",
  "ParentId" int4,
  "Path" varchar(255) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Category
-- ----------------------------
INSERT INTO "public"."Category" VALUES (1, 1, '默认分类', '默认的分类', NULL, '1');
INSERT INTO "public"."Category" VALUES (2, 1, '操作系统', 'Windows硬盘系统和RamOS系统', NULL, '2');
INSERT INTO "public"."Category" VALUES (4, 1, '影视资源', '精品电影、电视剧等', NULL, '4');
INSERT INTO "public"."Category" VALUES (6, 1, '程序开发', '开发者学习教程', NULL, '6');
INSERT INTO "public"."Category" VALUES (7, 1, '开发工具', '开发者常用工具', NULL, '7');
INSERT INTO "public"."Category" VALUES (8, 1, '国际网络加速', NULL, NULL, '8');
INSERT INTO "public"."Category" VALUES (13, 1, '共享文献', NULL, NULL, '13');
INSERT INTO "public"."Category" VALUES (14, 1, '哲学♂文化传媒', '哲♂学≠搞基；
哲♂学来源是㚻片，这是不可否认的事实；但哲♂学本质是给人带来愉♂悦以及深♂刻的思考的，而不是搞基的；
哲♂学不可以代替爱情，爱情同样不可以代替哲♂学。（每个兄贵都应该收获自己真挚的感♂情，而不是沉迷哲♂学无法自拔；也不能沉迷美色不思哲♂学）；
哲♂学是一种精神♂娱乐；
哲♂学可以成为一种信仰。
左右为♂男，进退两♂男，男上夹♂男，困男♂重重，阳♂物运动，van♂艺复兴，弟大翻♂着洗，波大♂奶汁多，弟大♂勿勃，乳来♂伸掌，尝♂精阁，吸♂舔♂取♂精，在杰♂男逃，易痒♂千洗。', NULL, '14');
INSERT INTO "public"."Category" VALUES (15, 1, '绿色软件', '没有捆绑，没有烦人的广告，没有臃肿的身材，不收用户一分钱，不以盈利为目的！', NULL, '15');
INSERT INTO "public"."Category" VALUES (17, 1, '硬件知识', NULL, NULL, '17');
INSERT INTO "public"."Category" VALUES (18, 1, '玩机分享', '实用的搞机技巧', NULL, '18');
INSERT INTO "public"."Category" VALUES (20, 1, '生活随笔', NULL, NULL, '20');
INSERT INTO "public"."Category" VALUES (28, 1, '视频课程', '各大编程语言学习视频，C#、Java、php、go、web前端、UI设计、SEO等相关学习视频应有尽有！', NULL, '28');
INSERT INTO "public"."Category" VALUES (30, 1, '科技前沿', NULL, NULL, '30');
INSERT INTO "public"."Category" VALUES (31, 1, '网络安全', '互联网之大，安全第一！', NULL, '31');
INSERT INTO "public"."Category" VALUES (32, 1, '前端杂谈', NULL, NULL, '32');
INSERT INTO "public"."Category" VALUES (34, 1, '后端技术', '后端开发者充电', NULL, '34');
INSERT INTO "public"."Category" VALUES (38, 1, '.NET开发技术', '微软大法好！.NET好！退Java、Python、php保平安！', NULL, '38');
INSERT INTO "public"."Category" VALUES (41, 1, '开源项目', '博主自主研发的开源项目', NULL, '41');
INSERT INTO "public"."Category" VALUES (42, 1, '稀缺资源', '互联网上仅存的稀缺资源，不收取任何费用，仅用于个人研究和使用，发扬互联网分享精神，专注收藏与分享。', NULL, '42');
INSERT INTO "public"."Category" VALUES (43, 1, '曝光台', '专门曝光一些流氓公司，毒瘤公司，以及一些社会垃圾，坚决和社会毒瘤作斗争！秉承务实求真的态度以及客观评价，让更多人了解真相，防止上当受骗！', NULL, '43');
INSERT INTO "public"."Category" VALUES (45, 1, '正版软件', '优惠实用的小软件，提高工作效率', NULL, '45');
INSERT INTO "public"."Category" VALUES (47, 1, '本站活动', NULL, NULL, '47');
INSERT INTO "public"."Category" VALUES (44, 1, '电竞显示器', '自主生产的超高性价比的diy显示器，对标大金刚，小金刚等，一半的价格，完美的体验，M270KCJ-K7E，LM270WQA-SSA1，M270QAN02.3，M250HAN03.2，LM270WR4，LM315WR1-SSB2，M315DCA-K7B，M270DTN02.7......', NULL, '44');
INSERT INTO "public"."Category" VALUES (46, 1, '安卓软件', NULL, 15, '15,46');
INSERT INTO "public"."Category" VALUES (48, 1, '大型单机游戏', '一些3A大作，显卡危机！', NULL, '48');
INSERT INTO "public"."Category" VALUES (49, 1, '美图壁纸', '4k/8k的超高清手机电脑美图壁纸，养眼妹子?，秀人网精选模特，日韩、国模套图。', NULL, '49');
INSERT INTO "public"."Category" VALUES (50, 1, '其他', NULL, NULL, '50');
INSERT INTO "public"."Category" VALUES (51, 1, '影音编辑', NULL, 78, '15,78,51');
INSERT INTO "public"."Category" VALUES (52, 1, '工业软件', NULL, 78, '15,78,52');
INSERT INTO "public"."Category" VALUES (53, 1, '系统工具', NULL, 78, '15,78,53');
INSERT INTO "public"."Category" VALUES (54, 1, '教学软件', NULL, 78, '15,78,54');
INSERT INTO "public"."Category" VALUES (55, 1, '数据分析', NULL, 78, '15,78,55');
INSERT INTO "public"."Category" VALUES (56, 1, '办公软件', NULL, 78, '15,78,56');
INSERT INTO "public"."Category" VALUES (57, 1, '远程控制', NULL, 78, '15,78,57');
INSERT INTO "public"."Category" VALUES (58, 1, '虚拟机', NULL, 78, '15,78,58');
INSERT INTO "public"."Category" VALUES (59, 1, '科研软件', NULL, 78, '15,78,59');
INSERT INTO "public"."Category" VALUES (60, 1, '脑图软件', NULL, 78, '15,78,60');
INSERT INTO "public"."Category" VALUES (61, 1, '图像处理', NULL, 78, '15,78,61');
INSERT INTO "public"."Category" VALUES (62, 1, '软件开发工具', NULL, 78, '15,78,62');
INSERT INTO "public"."Category" VALUES (63, 1, '文件管理', NULL, 78, '15,78,63');
INSERT INTO "public"."Category" VALUES (64, 1, '效率工具', NULL, 78, '15,78,64');
INSERT INTO "public"."Category" VALUES (65, 1, '视听软件', NULL, 78, '15,78,65');
INSERT INTO "public"."Category" VALUES (66, 1, '数据恢复', NULL, 78, '15,78,66');
INSERT INTO "public"."Category" VALUES (67, 1, '基础软件', NULL, 78, '15,78,67');
INSERT INTO "public"."Category" VALUES (68, 1, '下载工具', NULL, 78, '15,78,68');
INSERT INTO "public"."Category" VALUES (69, 1, '录屏工具', NULL, 78, '15,78,69');
INSERT INTO "public"."Category" VALUES (70, 1, '服务器软件', NULL, 15, '15,70');
INSERT INTO "public"."Category" VALUES (71, 1, 'C#/.NET/.NET Core', NULL, 28, '28,71');
INSERT INTO "public"."Category" VALUES (72, 1, 'JavaEE/大数据', NULL, 28, '28,72');
INSERT INTO "public"."Category" VALUES (73, 1, 'Web前端', NULL, 28, '28,73');
INSERT INTO "public"."Category" VALUES (74, 1, 'Python', NULL, 28, '28,74');
INSERT INTO "public"."Category" VALUES (75, 1, 'Go语言', NULL, 28, '28,75');
INSERT INTO "public"."Category" VALUES (76, 1, '硬件工具', NULL, 78, '15,78,76');
INSERT INTO "public"."Category" VALUES (77, 1, 'MacOS软件', NULL, 15, '15,77');
INSERT INTO "public"."Category" VALUES (78, 1, 'Windows软件', NULL, 15, '15,78');
INSERT INTO "public"."Category" VALUES (80, 1, '跨平台软件', NULL, 15, '15,80');

-- ----------------------------
-- Table structure for Comment
-- ----------------------------
DROP TABLE IF EXISTS "public"."Comment";
CREATE TABLE "public"."Comment" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "NickName" varchar(24) COLLATE "pg_catalog"."default" NOT NULL,
  "Email" varchar(64) COLLATE "pg_catalog"."default",
  "Content" varchar(4096) COLLATE "pg_catalog"."default" NOT NULL,
  "ParentId" int4,
  "PostId" int4 NOT NULL,
  "CommentDate" timestamptz(6) NOT NULL,
  "Browser" varchar(255) COLLATE "pg_catalog"."default",
  "OperatingSystem" varchar(255) COLLATE "pg_catalog"."default",
  "IsMaster" bool NOT NULL,
  "VoteCount" int4 NOT NULL,
  "AgainstCount" int4 NOT NULL,
  "IP" varchar(255) COLLATE "pg_catalog"."default",
  "Location" varchar(255) COLLATE "pg_catalog"."default",
  "GroupTag" varchar(32) COLLATE "pg_catalog"."default",
  "Path" varchar(4096) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Comment
-- ----------------------------

-- ----------------------------
-- Table structure for Donate
-- ----------------------------
DROP TABLE IF EXISTS "public"."Donate";
CREATE TABLE "public"."Donate" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "NickName" varchar(64) COLLATE "pg_catalog"."default",
  "Email" varchar(64) COLLATE "pg_catalog"."default",
  "QQorWechat" varchar(64) COLLATE "pg_catalog"."default",
  "Amount" varchar(64) COLLATE "pg_catalog"."default",
  "Via" varchar(64) COLLATE "pg_catalog"."default",
  "DonateTime" timestamptz(6) NOT NULL
)
;

-- ----------------------------
-- Records of Donate
-- ----------------------------

-- ----------------------------
-- Table structure for FastShare
-- ----------------------------
DROP TABLE IF EXISTS "public"."FastShare";
CREATE TABLE "public"."FastShare" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Title" varchar(1024) COLLATE "pg_catalog"."default",
  "Link" varchar(4096) COLLATE "pg_catalog"."default",
  "Sort" int4 NOT NULL
)
;

-- ----------------------------
-- Records of FastShare
-- ----------------------------
INSERT INTO "public"."FastShare" VALUES (24, 0, '防止跟丢，请先加群，跟着组织走，搜不到你想要的资源？点击加入官方【电报群】，可以获得更多本站未公示的群友独享的【神秘稀缺资源】哦！', 'https://t.me/joinchat/JcFR4Utd7l3-qyhYpANUDA', 10);
INSERT INTO "public"."FastShare" VALUES (40, 0, '关于本站资源报毒的问题，这种问题请自行选择就好了。本站所提供的任何二进制文件均不具备权威性，如需体验官方正版，请从相应的官网渠道下载，请悉知！村通网并不可怕。如果九年义务教育还看不懂报毒的英文的话，请购买正版。', 'null', 30);
INSERT INTO "public"."FastShare" VALUES (50, 0, '近日有网友反馈，在InfoQ等第三方媒体网站发现有冒用本站马甲进行与本站价值观相违背的一些商业行为，鉴于此，本站强调：未在本站页面中公布过的任何第三方平台与“懒得勤快”同名的媒体账号均为假冒，请大家注意甄别，谨防上当受骗！', NULL, 99);
INSERT INTO "public"."FastShare" VALUES (51, 0, '⚠⚠⚠获取本站的最新域名，防止跟丢！⚠⚠⚠', 'https://masuit.gitee.io/masuit.tools/', 1);

-- ----------------------------
-- Table structure for InternalMessage
-- ----------------------------
DROP TABLE IF EXISTS "public"."InternalMessage";
CREATE TABLE "public"."InternalMessage" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Title" varchar(512) COLLATE "pg_catalog"."default",
  "Content" varchar(4096) COLLATE "pg_catalog"."default",
  "Link" varchar(4096) COLLATE "pg_catalog"."default",
  "Time" timestamptz(6) NOT NULL,
  "Read" bool NOT NULL
)
;

-- ----------------------------
-- Records of InternalMessage
-- ----------------------------

-- ----------------------------
-- Table structure for LeaveMessage
-- ----------------------------
DROP TABLE IF EXISTS "public"."LeaveMessage";
CREATE TABLE "public"."LeaveMessage" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "NickName" varchar(64) COLLATE "pg_catalog"."default" NOT NULL,
  "Content" varchar(4096) COLLATE "pg_catalog"."default" NOT NULL,
  "PostDate" timestamptz(6) NOT NULL,
  "Email" varchar(64) COLLATE "pg_catalog"."default",
  "ParentId" int4,
  "Browser" varchar(255) COLLATE "pg_catalog"."default",
  "OperatingSystem" varchar(255) COLLATE "pg_catalog"."default",
  "IsMaster" bool NOT NULL,
  "IP" varchar(255) COLLATE "pg_catalog"."default",
  "Location" varchar(255) COLLATE "pg_catalog"."default",
  "GroupTag" varchar(32) COLLATE "pg_catalog"."default",
  "Path" varchar(4096) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of LeaveMessage
-- ----------------------------
INSERT INTO "public"."LeaveMessage" VALUES (42, 5, '懒得勤快', '网站做的比较草率，后期会慢慢优化', '2017-09-28 22:00:02+08', '1@1.cn', 38, 'Chrome 63.0.3205.2', 'Windows 8.1 64-bit', 't', NULL, NULL, 'urpfyof2h1j4', '38,42');
INSERT INTO "public"."LeaveMessage" VALUES (46, 5, 'Justin', '一直很欣赏博主，哈哈哈，加油啊，一直支持你！这种互联网精神难能可贵啊~', '2017-11-03 02:41:43+08', '1@1.cn', NULL, 'Chrome 64.0.3246.2', 'Windows Server 2008 R2 / 7 64-bit', 'f', NULL, NULL, 'urpfyof2h1j6', '46');
INSERT INTO "public"."LeaveMessage" VALUES (47, 5, '??懒得勤快??', '感谢支持！<img src="/Assets/layui/images/face/1.gif">', '2017-11-03 07:42:33+08', '1@1.cn', 46, 'Chrome 64.0.3246.2', 'Windows 8.1 64-bit', 't', NULL, NULL, 'urpfyof2h1j6', '46,47');
INSERT INTO "public"."LeaveMessage" VALUES (38, 5, '誓不落伍', '网站有点花俏，字数还不够<img src="/Assets/layui/images/face/5.gif">', '2017-09-12 22:55:38+08', '1@1.cn', NULL, 'Chrome 59.0.3071.86', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1j4', '38');
INSERT INTO "public"."LeaveMessage" VALUES (40, 5, 'foxicreat', '网盘链接好多都失效了，怎么回事。求相关链接', '2017-09-22 17:39:52+08', '1@1.cn', NULL, 'Chrome 56.0.2924.87', 'Windows Server 2008 R2 / 7 64-bit', 'f', NULL, NULL, 'urpfyof2h1j5', '40');
INSERT INTO "public"."LeaveMessage" VALUES (41, 5, '懒得勤快', '链接失效都会修改重新发布的，注意关注下最新动态', '2017-09-28 21:59:33+08', '1@1.cn', 40, 'Chrome 63.0.3205.2', 'Windows 8.1 64-bit', 't', NULL, NULL, 'urpfyof2h1j5', '40,41');
INSERT INTO "public"."LeaveMessage" VALUES (48, 5, 'wx', '黑科技播放vip视频的 进度条是不是没效果？拖动之后就重新播放了', '2017-11-24 20:21:24+08', '1@1.cn', NULL, 'Chrome 62.0.3202.94', 'Windows Server 2008 R2 / 7 64-bit', 'f', NULL, NULL, 'urpfyof2h1j7', '48');
INSERT INTO "public"."LeaveMessage" VALUES (49, 5, '??懒得勤快??', '播放器因线路的不同，样式和功能有所不一样的', '2017-11-24 21:24:47+08', '1@1.cn', 48, 'Chrome 64.0.3246.2', 'Windows 8.1 64-bit', 't', NULL, NULL, 'urpfyof2h1j7', '48,49');
INSERT INTO "public"."LeaveMessage" VALUES (50, 5, '三代衣服', '为什么不是从新窗口打开连接呢', '2017-12-09 00:12:58+08', '1@1.cn', NULL, 'Chrome 55.0.2883.87', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1j8', '50');
INSERT INTO "public"."LeaveMessage" VALUES (51, 5, '??懒得勤快??', '开太多窗口你不嫌懒得关么<img src="/Assets/layui/images/face/5.gif">', '2017-12-09 00:14:06+08', '1@1.cn', 50, 'Chrome 64.0.3246.2', 'Windows 8.1 64-bit', 't', NULL, NULL, 'urpfyof2h1j8', '50,51');
INSERT INTO "public"."LeaveMessage" VALUES (53, 5, 'PaulLee', '博主真乃神人也，佩服佩服', '2018-01-14 08:09:59+08', '1@1.cn', NULL, 'Chrome 50.0.2661.95', 'Windows Server 2008 R2 / 7 64-bit', 'f', NULL, NULL, 'urpfyof2h1j9', '53');
INSERT INTO "public"."LeaveMessage" VALUES (54, 5, '旺旺', '视频解析，调用的别的网站的。如果不喜欢换一个线路就可以了', '2018-01-19 23:11:06+08', '1@1.cn', 49, 'Microsoft Edge 14.14393', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1j7', '48,49,54');
INSERT INTO "public"."LeaveMessage" VALUES (55, 5, 'Yahweh', '能不能啥时候分享点小程序的开发教程<br>', '2018-01-26 06:23:44+08', '1@1.cn', NULL, 'Firefox 57.0', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1ja', '55');
INSERT INTO "public"."LeaveMessage" VALUES (56, 5, '??懒得勤快??', '微信官网的文档不是挺详细的么', '2018-01-26 06:26:34+08', '1@1.cn', 55, 'Chrome 65.0.3301.0', 'Windows 8.1 64-bit', 't', NULL, NULL, 'urpfyof2h1ja', '55,56');
INSERT INTO "public"."LeaveMessage" VALUES (57, 5, '??懒得勤快??', '<img src="/Assets/layui/images/face/63.gif">', '2018-01-26 20:58:09+08', '1@1.cn', 53, 'Chrome 64.0.3246.2', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1j9', '53,57');
INSERT INTO "public"."LeaveMessage" VALUES (58, 5, 'ITbaiai', '能分享一些好的网站吗', '2018-04-11 05:08:31+08', '1@1.cn', NULL, 'Chrome 63.0.3239.132', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1jb', '58');
INSERT INTO "public"."LeaveMessage" VALUES (60, 5, 'ITbaiai', '就是你的这些软件破译，翻墙的这些都是哪里找来的呢', '2018-04-12 01:34:12+08', '1@1.cn', 58, 'Chrome 55.0.2883.87', 'Windows Server 2008 R2 / 7', 'f', NULL, NULL, 'urpfyof2h1jb', '58,60');
INSERT INTO "public"."LeaveMessage" VALUES (61, 5, 'Answer', '博主真的很厉害，是我努力的方向！！我要加油了', '2018-04-27 21:30:27+08', '1@1.cn', NULL, 'Chrome 63.0.3239.26', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1jc', '61');
INSERT INTO "public"."LeaveMessage" VALUES (62, 5, 'vyron', '博主求Android开发视频教学0 0，射射博主', '2018-05-14 18:18:51+08', '1@1.cn', NULL, 'Chrome 66.0.3359.139', 'OS X 10.13.4 64-bit', 'f', NULL, NULL, 'urpfyof2h1jd', '62');
INSERT INTO "public"."LeaveMessage" VALUES (63, 5, '??懒得勤快??', '<a target="_self" href="http://masuit.com/44">http://masuit.com/44</a>', '2018-05-14 18:19:40+08', '1@1.cn', 62, 'Chrome 68.0.3409.0', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1jd', '62,63');
INSERT INTO "public"."LeaveMessage" VALUES (64, 5, 'vyron', '没找到下载地址<img src="/Assets/layui/images/face/12.gif">', '2018-05-14 18:36:46+08', '1@1.cn', 63, 'Chrome 66.0.3359.139', 'OS X 10.13.4 64-bit', 'f', NULL, NULL, 'urpfyof2h1jd', '62,63,64');
INSERT INTO "public"."LeaveMessage" VALUES (65, 5, '??懒得勤快??', 'QQ私信找我', '2018-05-14 18:38:44+08', '1@1.cn', 64, 'Chrome 68.0.3409.0', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1jd', '62,63,64,65');
INSERT INTO "public"."LeaveMessage" VALUES (66, 5, 'd''d''d', 'dddd', '2018-05-20 05:32:57+08', '1@1.cn', 41, 'Firefox 61.0', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1j5', '40,41,66');
INSERT INTO "public"."LeaveMessage" VALUES (67, 5, 'www.xindingyue.com', '朋友 交换链接吗', '2018-05-21 20:30:52+08', '1@1.cn', NULL, 'Chrome 55.0.2883.87', 'Windows 8.1 64-bit', 'f', NULL, NULL, 'urpfyof2h1je', '67');
INSERT INTO "public"."LeaveMessage" VALUES (68, 5, '懒得勤快', '可以的，你到友情链接去提交链接就可以了', '2018-05-22 00:34:53+08', '1@1.cn', 67, 'Chrome 66.0.3359.181', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1je', '67,68');
INSERT INTO "public"."LeaveMessage" VALUES (70, 5, '木子', '<p>神秘代码，已经加友链了http://www.lxl8800.cn/</p>', '2018-05-23 08:02:49+08', '1@1.cn', NULL, 'Chrome 55.0.2883.87', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1jf', '70');
INSERT INTO "public"."LeaveMessage" VALUES (71, 5, '懒得勤快', '404，什么鬼？', '2018-05-23 08:04:04+08', '1@1.cn', 70, 'Chrome 66.0.3359.181', 'Windows 8.1 64-bit', 't', NULL, NULL, 'urpfyof2h1jf', '70,71');
INSERT INTO "public"."LeaveMessage" VALUES (72, 5, '木子', '刚刚改服务器了，你刷新试试', '2018-05-23 08:06:09+08', '1@1.cn', 71, 'Chrome 55.0.2883.87', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1jf', '70,71,72');
INSERT INTO "public"."LeaveMessage" VALUES (73, 5, '懒得勤快', '没检测到反链', '2018-05-23 08:08:06+08', '1@1.cn', 72, 'Chrome 66.0.3359.181', 'Windows 8.1 64-bit', 't', NULL, NULL, 'urpfyof2h1jf', '70,71,72,73');
INSERT INTO "public"."LeaveMessage" VALUES (74, 5, '木子', '<p>你进我网站看友情链接就看见你了</p>', '2018-05-23 08:09:53+08', '1@1.cn', 73, 'Chrome 55.0.2883.87', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1jf', '70,71,72,73,74');
INSERT INTO "public"."LeaveMessage" VALUES (75, 5, '懒得勤快', 'ok，可以了', '2018-05-23 08:10:40+08', '1@1.cn', 72, 'Chrome 66.0.3359.181', 'Windows 8.1 64-bit', 't', NULL, NULL, 'urpfyof2h1jf', '70,71,72,75');
INSERT INTO "public"."LeaveMessage" VALUES (76, 5, '枫树林', '<p>站长，我推荐个linq软件 linqpad&nbsp;</p><p>https://www.linqpad.net/</p>', '2018-05-30 00:18:27+08', '1@1.cn', NULL, 'Chrome 65.0.3325.146', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1jg', '76');
INSERT INTO "public"."LeaveMessage" VALUES (77, 5, '懒得勤快', '很久以前用过，感觉不好用', '2018-05-30 00:20:55+08', '1@1.cn', 76, 'Chrome 66.0.3359.181', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1jg', '76,77');
INSERT INTO "public"."LeaveMessage" VALUES (78, 5, '枫树林', '站长有没有QQ群？ 我想加入，都是程序猿，还是得有个港湾', '2018-05-30 00:36:57+08', '1@1.cn', 77, 'Chrome 65.0.3325.146', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1jg', '76,77,78');
INSERT INTO "public"."LeaveMessage" VALUES (79, 5, '懒得勤快', '没有Q群', '2018-05-30 00:37:23+08', '1@1.cn', 78, 'Chrome 66.0.3359.181', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1jg', '76,77,78,79');
INSERT INTO "public"."LeaveMessage" VALUES (80, 5, '枫树林', '考不考虑整一个？大家加进去讨论啊、聊天啊', '2018-05-30 00:39:45+08', '1@1.cn', 79, 'Chrome 65.0.3325.146', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1jg', '76,77,78,79,80');
INSERT INTO "public"."LeaveMessage" VALUES (81, 5, '枫树林', '<p>屏幕录制，我推荐个ScreenToGif。</p><p>http://www.screentogif.com/?l=zh_cn</p>', '2018-05-30 00:41:18+08', '1@1.cn', NULL, 'Chrome 65.0.3325.146', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1jh', '81');
INSERT INTO "public"."LeaveMessage" VALUES (84, 5, 'test', '快点开源吧,想学一下项目架构', '2018-06-27 18:00:28+08', '1@1.cn', NULL, 'Chrome 67.0.3396.62', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1ji', '84');
INSERT INTO "public"."LeaveMessage" VALUES (85, 5, '懒得勤快', '你可以先参考下我的这个项目，架构都是一样的。<a target="_blank" href="https://masuit.com/54">https://masuit.com/54</a>', '2018-06-28 17:58:54+08', '1@1.cn', 84, 'Chrome 67.0.3396.87', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1ji', '84,85');
INSERT INTO "public"."LeaveMessage" VALUES (88, 5, 'test', '看了一下，和我看的传智24期.net培训那个讲师讲的项目的架构一样，只不过没有dto,ioc这些东西，打算把这个架构好好研究一下，可以的话邮件发个联系方式，我认你做大哥，你教我梳中分', '2018-06-28 22:48:42+08', '1@1.cn', 85, 'Chrome 67.0.3396.62', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1ji', '84,85,88');
INSERT INTO "public"."LeaveMessage" VALUES (89, 5, '懒得勤快', '恩，单体项目的主流架构都这样的', '2018-06-28 22:50:15+08', '1@1.cn', 88, 'Chrome 67.0.3396.87', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1ji', '84,85,88,89');
INSERT INTO "public"."LeaveMessage" VALUES (90, 5, '健旺博客', '回访来了，非常不错的网站。<img src="https://masuit.com/Assets/layui/images/face/54.gif">', '2018-07-03 03:13:43+08', '1@1.cn', NULL, 'Chrome 63.0.3239.132', 'Windows Server 2008 R2 / 7 64-bit', 'f', NULL, NULL, 'urpfyof2h1jj', '90');
INSERT INTO "public"."LeaveMessage" VALUES (91, 5, '懒得勤快', '来呀，快活啊。反正有大把时光<img src="https://masuit.com/Assets/layui/images/face/57.gif">', '2018-07-03 03:27:26+08', '1@1.cn', 90, 'Chrome 67.0.3396.99', 'Windows 8.1 64-bit', 't', NULL, NULL, 'urpfyof2h1jj', '90,91');
INSERT INTO "public"."LeaveMessage" VALUES (92, 5, '星尘', '<p>博主，能交换个友链吗，关于java技术记录分享的，网站会持续更新文章的</p><p>网站名：星尘阁</p><p>地址：www.52xingchen.cn</p><p>图标：http://www.52xingchen.cn/favico.ico</p>', '2018-07-05 20:32:56+08', '1@1.cn', NULL, 'Chrome 65.0.3325.181', 'Windows Server 2008 R2 / 7 64-bit', 'f', NULL, NULL, 'urpfyof2h1jk', '92');
INSERT INTO "public"."LeaveMessage" VALUES (93, 5, '懒得勤快', '你已经通过自助通道上链了啊', '2018-07-06 01:15:24+08', '1@1.cn', 92, 'Chrome 67.0.3396.87', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1jk', '92,93');
INSERT INTO "public"."LeaveMessage" VALUES (94, 5, 'Robin', '<p>兄弟，同为技术爱好者。方便加个微信不。</p><p>挺好的一个项目，有没有考虑多人协同开发，让这个网站越来越好。如果有需要写代码的地方，可以联系我。</p>', '2018-07-22 01:02:53+08', '1@1.cn', NULL, 'Chrome 67.0.3396.99', 'Windows Server 2008 R2 / 7 64-bit', 'f', NULL, NULL, 'urpfyof2h1jl', '94');
INSERT INTO "public"."LeaveMessage" VALUES (95, 5, '懒得勤快', '可以的，欢迎pull&nbsp;Request', '2018-07-22 01:05:30+08', '1@1.cn', 94, 'Chrome 69.0.3486.0', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1jl', '94,95');
INSERT INTO "public"."LeaveMessage" VALUES (59, 5, '??懒得勤快??', 'github，csdn，博客园，jquery之家，脚本之家，胖次', '2018-04-11 05:55:41+08', '1@1.cn', 58, 'Chrome 67.0.3366.0', 'Windows 8.1 64-bit', 'f', NULL, NULL, 'urpfyof2h1jb', '58,59');
INSERT INTO "public"."LeaveMessage" VALUES (96, 5, 'WelphenEDM', '<p>请博主修改一下友链，welphen.cn域名过期，已更换新域名，welphen.com</p>', '2018-07-25 23:12:48+08', '1@1.cn', NULL, 'Chrome 67.0.3396.99', 'Windows 10 64-bit', 'f', NULL, NULL, 'urpfyof2h1jm', '96');
INSERT INTO "public"."LeaveMessage" VALUES (97, 5, '懒得勤快', '好的，友链已改。...', '2018-07-25 23:14:39+08', '1@1.cn', 96, 'Chrome 67.0.3396.99', 'Windows 10 64-bit', 't', NULL, NULL, 'urpfyof2h1jm', '96,97');

-- ----------------------------
-- Table structure for LinkLoopback
-- ----------------------------
DROP TABLE IF EXISTS "public"."LinkLoopback";
CREATE TABLE "public"."LinkLoopback" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Referer" varchar(4096) COLLATE "pg_catalog"."default",
  "IP" varchar(128) COLLATE "pg_catalog"."default",
  "Time" timestamptz(6) NOT NULL,
  "LinkId" int4 NOT NULL,
  "Status" int4 NOT NULL
)
;

-- ----------------------------
-- Records of LinkLoopback
-- ----------------------------

-- ----------------------------
-- Table structure for Links
-- ----------------------------
DROP TABLE IF EXISTS "public"."Links";
CREATE TABLE "public"."Links" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Name" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "Url" varchar(64) COLLATE "pg_catalog"."default" NOT NULL,
  "Except" bool NOT NULL,
  "Recommend" bool NOT NULL,
  "UpdateTime" timestamptz(6) NOT NULL,
  "UrlBase" varchar(64) COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of Links
-- ----------------------------
INSERT INTO "public"."Links" VALUES (2, 1, 'github', 'https://github.com/ldqk', 't', 't', '2020-06-30 19:40:35+08', 'https://github.com/ldqk');
INSERT INTO "public"."Links" VALUES (58, 1, '梁钟霖博客', 'https://www.liangzl.com/get-friend-link.html', 'f', 'f', '2022-05-11 22:04:01+08', 'https://www.liangzl.com');
INSERT INTO "public"."Links" VALUES (61, 14, '健旺博客', 'http://www.256it.com/', 'f', 'f', '2022-02-21 12:00:09+08', 'http://www.256it.com/');
INSERT INTO "public"."Links" VALUES (66, 1, '游魂博客', 'https://www.iyouhun.com/', 'f', 'f', '2022-05-11 22:03:59+08', 'https://www.iyouhun.com/');
INSERT INTO "public"."Links" VALUES (95, 1, 'ChromeFor浏览器插件下载中心', 'https://www.chromefor.com/links/', 'f', 'f', '2022-05-11 22:04:02+08', 'https://www.chromefor.com/');
INSERT INTO "public"."Links" VALUES (99, 1, 'DeTechn Blog', 'https://www.detechn.com', 'f', 'f', '2022-05-21 12:00:14+08', 'https://www.detechn.com');
INSERT INTO "public"."Links" VALUES (102, 1, '脑袋瓜子', 'https://www.naodai.org', 't', 'f', '2020-06-30 19:40:35+08', 'https://www.naodai.org');
INSERT INTO "public"."Links" VALUES (103, 14, '华梦博客', 'https://52huameng.com/links/', 'f', 'f', '2021-12-06 02:00:09+08', 'https://52huameng.com/');
INSERT INTO "public"."Links" VALUES (111, 1, '分享巴中', 'https://www.sharexbar.com/', 'f', 'f', '2022-05-19 21:00:09+08', 'https://www.sharexbar.com/');
INSERT INTO "public"."Links" VALUES (115, 1, '博客园-Edison Zhou', 'https://www.cnblogs.com/edisonchou/', 't', 'f', '2020-06-30 19:40:35+08', 'https://www.cnblogs.com/edisonchou/');
INSERT INTO "public"."Links" VALUES (125, 1, '思羽布丁', 'https://www.mfpud.com/', 'f', 'f', '2022-05-11 22:04:03+08', 'https://www.mfpud.com/');
INSERT INTO "public"."Links" VALUES (127, 14, '无名的碎语', 'https://www.4jax.net/log/', 'f', 'f', '2022-03-27 02:00:26+08', 'https://www.4jax.net/');
INSERT INTO "public"."Links" VALUES (132, 14, 'Szx''s Blog', 'https://www.songzixian.com/links.html', 'f', 'f', '2022-03-27 02:00:18+08', 'https://www.songzixian.com');
INSERT INTO "public"."Links" VALUES (136, 1, '刘旭博客', 'http://www.liuxuseo.cn', 'f', 'f', '2022-05-11 22:04:10+08', 'http://www.liuxuseo.cn');
INSERT INTO "public"."Links" VALUES (140, 1, 'Gopher博客', 'https://chunlife.top/', 'f', 'f', '2022-05-11 22:04:06+08', 'https://chunlife.top/');
INSERT INTO "public"."Links" VALUES (143, 1, 'java菜市场', 'https://www.javaweb.shop', 'f', 'f', '2022-05-11 22:04:07+08', 'https://www.javaweb.shop');
INSERT INTO "public"."Links" VALUES (148, 1, '何智政个人博客', 'https://hzz.cool/blog', 'f', 'f', '2022-05-11 22:04:07+08', 'https://hzz.cool/blog');
INSERT INTO "public"."Links" VALUES (156, 1, '江湖人士', 'https://jhrs.com', 'f', 'f', '2022-05-11 22:04:08+08', 'https://jhrs.com');
INSERT INTO "public"."Links" VALUES (161, 1, '清风博客', 'https://www.skyfinder.cc', 'f', 'f', '2022-05-11 22:04:10+08', 'https://www.skyfinder.cc');
INSERT INTO "public"."Links" VALUES (164, 1, '大道至简博客', 'https://www.yunted.com/', 't', 'f', '2020-06-30 19:40:35+08', 'https://www.yunted.com/');
INSERT INTO "public"."Links" VALUES (165, 1, 'Dotnet9', 'https://dotnet9.com', 'f', 'f', '2022-05-16 07:00:12+08', 'https://dotnet9.com');
INSERT INTO "public"."Links" VALUES (170, 1, '52abp', 'https://www.52abp.com/', 'f', 'f', '2022-05-11 22:04:11+08', 'https://www.52abp.com/');
INSERT INTO "public"."Links" VALUES (172, 1, 'Git开源网', 'https://gitoscc.com/', 'f', 'f', '2022-05-11 22:04:12+08', 'https://gitoscc.com/');
INSERT INTO "public"."Links" VALUES (173, 1, '佛系软件', 'https://foxirj.com', 't', 'f', '2022-01-06 12:00:34+08', 'https://foxirj.com');
INSERT INTO "public"."Links" VALUES (178, 1, '投我木李', 'https://xmuli.tech/links/', 'f', 'f', '2022-05-11 22:04:12+08', 'https://xmuli.tech/');
INSERT INTO "public"."Links" VALUES (179, 1, '24k导航', 'https://www.24kdh.com', 'f', 'f', '2022-05-11 22:04:13+08', 'https://www.24kdh.com');
INSERT INTO "public"."Links" VALUES (182, 1, 'sanv显示器淘宝店', 'https://sanvtech.taobao.com/', 't', 't', '2020-06-30 19:40:35+08', 'https://sanvtech.taobao.com/');
INSERT INTO "public"."Links" VALUES (188, 14, '清水河恶霸', 'http://ql.magic-seven.top/links', 'f', 'f', '2021-12-23 21:00:22+08', 'http://ql.magic-seven.top/');
INSERT INTO "public"."Links" VALUES (195, 1, 'V2方圆', 'https://www.v2fy.com', 'f', 'f', '2022-05-15 12:00:31+08', 'https://www.v2fy.com');
INSERT INTO "public"."Links" VALUES (197, 1, '风之暇想博客', 'https://www.fzxx.xyz/links/', 't', 'f', '2021-04-23 07:00:42+08', 'https://www.fzxx.xyz/');
INSERT INTO "public"."Links" VALUES (201, 1, 'BobMaster''s Blog', 'https://blog.hibobmaster.com/friends', 'f', 'f', '2022-05-17 07:00:30+08', 'https://blog.hibobmaster.com');
INSERT INTO "public"."Links" VALUES (206, 14, '酥泥洼', 'https://www.suni.wang/friendship.html', 'f', 'f', '2022-02-10 12:01:04+08', 'https://www.suni.wang');
INSERT INTO "public"."Links" VALUES (216, 1, 'Contione博客', 'https://www.contione.cn/', 'f', 'f', '2022-05-21 16:00:24+08', 'https://www.contione.cn/');
INSERT INTO "public"."Links" VALUES (217, 1, '独立观察员· 博客', 'http://dlgcy.com', 'f', 'f', '2022-05-13 12:00:38+08', 'http://dlgcy.com');
INSERT INTO "public"."Links" VALUES (222, 1, 'HZHControls控件库', 'http://www.hzhcontrols.com', 'f', 'f', '2022-05-12 07:00:41+08', 'http://www.hzhcontrols.com');
INSERT INTO "public"."Links" VALUES (225, 14, 'UJvUFP502tGRRKcE', 'https://t.me/joinchat/UJvUFP502tGRRKcE', 't', 'f', '2021-03-24 21:50:05+08', 'https://t.me/joinchat/UJvUFP502tGRRKcE');
INSERT INTO "public"."Links" VALUES (227, 14, 'ReGv3dmi6UZuo8m0', 'https://t.me/joinchat/ReGv3dmi6UZuo8m0', 't', 'f', '2021-04-18 22:05:47+08', 'https://t.me/joinchat/ReGv3dmi6UZuo8m0');
INSERT INTO "public"."Links" VALUES (229, 1, 'Zhendong的博客', 'https://www.kxit.net', 'f', 'f', '2022-05-11 22:04:24+08', 'https://www.kxit.net');
INSERT INTO "public"."Links" VALUES (230, 1, '小东西儿', 'https://xiaodongxier.com', 'f', 'f', '2022-05-11 22:04:25+08', 'https://xiaodongxier.com');
INSERT INTO "public"."Links" VALUES (238, 1, '架构师', 'https://www.itsvse.com/', 'f', 'f', '2022-05-11 22:04:26+08', 'https://www.itsvse.com/');
INSERT INTO "public"."Links" VALUES (240, 14, '麦子笔记', 'https://www.maizibiji.com', 'f', 'f', '2022-01-05 16:00:45+08', 'https://www.maizibiji.com');
INSERT INTO "public"."Links" VALUES (241, 1, 'Nite07的小窝', 'https://www.nite07.com/link', 'f', 'f', '2022-05-21 07:43:48+08', 'https://www.nite07.com/');
INSERT INTO "public"."Links" VALUES (242, 14, 'ZHC', 'https://www.zhhc.cc/links', 'f', 'f', '2022-01-07 02:01:09+08', 'https://www.zhhc.cc/');
INSERT INTO "public"."Links" VALUES (246, 14, '本站防丢页', 'https://holiday.pages.dev', 't', 'f', '2021-09-08 21:57:02+08', 'https://holiday.pages.dev');
INSERT INTO "public"."Links" VALUES (247, 14, '迷恋自留地', 'https://hunji.xyz/', 'f', 'f', '2022-03-20 07:02:50+08', 'https://hunji.xyz/');
INSERT INTO "public"."Links" VALUES (250, 14, '小祝同学的日常', 'http://www.zzy2001.com/index.php/friends.html', 'f', 'f', '2022-05-05 02:00:31+08', 'http://www.zzy2001.com');
INSERT INTO "public"."Links" VALUES (252, 14, 'BNTang', 'https://www.cnblogs.com/BNTang', 'f', 'f', '2021-12-23 02:00:37+08', 'https://www.cnblogs.com/BNTang');
INSERT INTO "public"."Links" VALUES (253, 14, '乐趣课堂lequ.co', 'https://lequ.co', 'f', 'f', '2022-02-15 07:01:33+08', 'https://lequ.co');
INSERT INTO "public"."Links" VALUES (254, 14, 'HowarZheng''s Blog', 'https://howarzheng.github.io/links/', 'f', 'f', '2022-01-27 21:01:14+08', 'https://howarzheng.github.io/');
INSERT INTO "public"."Links" VALUES (255, 1, 'HowarZheng''s Blog', 'https://howarzheng.com/links/', 'f', 'f', '2022-05-17 12:00:31+08', 'https://howarzheng.com');
INSERT INTO "public"."Links" VALUES (256, 14, 'ZhengXi''s Blog', 'https://blog.zhengxi.io/links/', 'f', 'f', '2022-02-08 02:01:11+08', 'https://blog.zhengxi.io');
INSERT INTO "public"."Links" VALUES (257, 1, '十分钟空间', 'https://www.tmspace.cn/Links', 'f', 'f', '2022-05-18 12:00:49+08', 'https://www.tmspace.cn/');
INSERT INTO "public"."Links" VALUES (106, 1, '吾勇士', 'https://wuyongshi.top/links.html', 'f', 'f', '2022-06-06 18:00:09.147465+08', 'https://wuyongshi.top/');
INSERT INTO "public"."Links" VALUES (194, 1, 'Popmars-专注共享资源', 'http://popmars.com', 'f', 'f', '2022-06-06 18:00:11.442549+08', 'http://popmars.com');
INSERT INTO "public"."Links" VALUES (77, 1, '袁志蒙博客', 'http://blog.yzmcms.com/', 'f', 'f', '2022-05-30 04:00:31.180275+08', 'http://blog.yzmcms.com/');
INSERT INTO "public"."Links" VALUES (192, 1, '诚宇教育', 'http://cywh.100xuexi.com', 'f', 'f', '2022-05-25 16:00:32.254926+08', 'http://cywh.100xuexi.com');
INSERT INTO "public"."Links" VALUES (92, 1, 'L&H Site', 'http://l2h.site/', 'f', 'f', '2022-05-27 04:00:33.675552+08', 'http://l2h.site/');
INSERT INTO "public"."Links" VALUES (171, 1, '吾皇千睡博客', 'http://16tao.cn/', 'f', 'f', '2022-05-30 23:00:45.620141+08', 'http://16tao.cn/');
INSERT INTO "public"."Links" VALUES (74, 14, '二丫讲梵', 'https://wiki.eryajf.net/friends/', 'f', 'f', '2022-06-09 13:00:06.560443+08', 'https://wiki.eryajf.net/');
INSERT INTO "public"."Links" VALUES (155, 1, '马王天地', 'http://www.goodym.cn/', 'f', 'f', '2022-06-01 08:00:38.603593+08', 'http://www.goodym.cn/');
INSERT INTO "public"."Links" VALUES (112, 1, '陈冬冬', 'http://www.chendd.cn', 'f', 'f', '2022-05-30 04:00:38.182534+08', 'http://www.chendd.cn');
INSERT INTO "public"."Links" VALUES (200, 1, 'Python 实战教程', 'https://pythondict.com', 'f', 'f', '2022-06-09 13:00:10.293903+08', 'https://pythondict.com');
INSERT INTO "public"."Links" VALUES (249, 14, 'OneByOneDotNet', 'https://onebyone.icu/', 'f', 'f', '2022-06-09 13:00:09.649713+08', 'https://onebyone.icu/');
INSERT INTO "public"."Links" VALUES (251, 1, 'Rosmontis博客', 'https://rosmontis.com/%e5%8f%8b%e4%ba%ba%e5%b8%90', 'f', 'f', '2022-06-06 13:00:10.051302+08', 'https://rosmontis.com');
INSERT INTO "public"."Links" VALUES (258, 1, '反码软件', 'https://antimkd.com/', 't', 'f', '2022-03-01 01:05:22+08', 'https://antimkd.com/');
INSERT INTO "public"."Links" VALUES (259, 14, 'Dotnet9工具箱', 'https://lequ.co', 'f', 'f', '2022-03-06 07:01:27+08', 'https://lequ.co');
INSERT INTO "public"."Links" VALUES (260, 1, '高木同学', 'https://t.me/gaomutongxue', 't', 'f', '2022-03-04 18:45:22+08', 'https://t.me/gaomutongxue');
INSERT INTO "public"."Links" VALUES (261, 1, 'fxxkmakeding', 'https://t.me/fxxkmakeding', 't', 'f', '2022-03-04 18:45:40+08', 'https://t.me/fxxkmakeding');
INSERT INTO "public"."Links" VALUES (263, 1, '偕臧的小站', 'https://ifmet.cn/links', 'f', 'f', '2022-05-17 12:00:35+08', 'https://ifmet.cn');
INSERT INTO "public"."Links" VALUES (264, 14, '雨糖科技-会声会影', 'http://www.miraclenet.xyz/friends/', 'f', 'f', '2022-04-03 02:00:46+08', 'http://www.miraclenet.xyz/');
INSERT INTO "public"."Links" VALUES (265, 14, 'JRuol资源', 'https://www.jruol.com/', 'f', 'f', '2022-03-28 07:00:55+08', 'https://www.jruol.com/');
INSERT INTO "public"."Links" VALUES (266, 1, '山海小站', 'https://bbs.shanhaiz.com/', 'f', 'f', '2022-05-11 22:04:37+08', 'https://bbs.shanhaiz.com/');
INSERT INTO "public"."Links" VALUES (212, 1, 'edu教育邮箱官方资讯平台', 'http://www.edumails.cn/links', 'f', 'f', '2022-05-22 16:00:42.426428+08', 'http://www.edumails.cn/');
INSERT INTO "public"."Links" VALUES (248, 1, '悦君', 'https://rexue.plus/links.html', 'f', 'f', '2022-05-26 07:00:39.235438+08', 'https://rexue.plus/');
INSERT INTO "public"."Links" VALUES (218, 1, '编程工具网址导航', 'http://1024todo.cn/', 'f', 'f', '2022-05-30 04:00:35.132373+08', 'http://1024todo.cn/');
INSERT INTO "public"."Links" VALUES (224, 1, '泡面加技术', 'https://www.paomian.plus/s/friend', 'f', 'f', '2022-05-30 04:00:43.39547+08', 'https://www.paomian.plus/');
INSERT INTO "public"."Links" VALUES (211, 1, '淘博文', 'https://www.songbin.top', 'f', 'f', '2022-06-06 18:00:10.395588+08', 'https://www.songbin.top');
INSERT INTO "public"."Links" VALUES (262, 1, 'ZhengXi’s Blog', 'https://www.zhengxi.io', 'f', 'f', '2022-06-06 18:00:15.255293+08', 'https://www.zhengxi.io');

-- ----------------------------
-- Table structure for LoginRecord
-- ----------------------------
DROP TABLE IF EXISTS "public"."LoginRecord";
CREATE TABLE "public"."LoginRecord" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "IP" varchar(128) COLLATE "pg_catalog"."default",
  "LoginTime" timestamptz(6) NOT NULL,
  "PhysicAddress" varchar(512) COLLATE "pg_catalog"."default",
  "LoginType" int4 NOT NULL,
  "UserInfoId" int4 NOT NULL
)
;

-- ----------------------------
-- Records of LoginRecord
-- ----------------------------

-- ----------------------------
-- Table structure for Menu
-- ----------------------------
DROP TABLE IF EXISTS "public"."Menu";
CREATE TABLE "public"."Menu" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Name" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "Icon" varchar(512) COLLATE "pg_catalog"."default",
  "Url" varchar(512) COLLATE "pg_catalog"."default" NOT NULL,
  "Sort" int4 NOT NULL,
  "ParentId" int4,
  "MenuType" int4 NOT NULL,
  "NewTab" bool NOT NULL,
  "Path" varchar(255) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Menu
-- ----------------------------
INSERT INTO "public"."Menu" VALUES (2, 1, '📚热门分类', NULL, '#', 20, NULL, 1, 'f', '2');
INSERT INTO "public"."Menu" VALUES (3, 1, '🎨专题', NULL, '#', 30, NULL, 2, 'f', '3');
INSERT INTO "public"."Menu" VALUES (4, 1, '🔬黑科技', NULL, '#', 40, NULL, 3, 'f', '4');
INSERT INTO "public"."Menu" VALUES (5, 1, '投稿', NULL, '/post/publish', 62, NULL, 0, 'f', '5');
INSERT INTO "public"."Menu" VALUES (6, 1, '留言和反馈', NULL, '/msg', 50, NULL, 0, 'f', '6');
INSERT INTO "public"."Menu" VALUES (7, 1, '技术杂谈', NULL, '#', 210, 2, 1, 'f', '2,7');
INSERT INTO "public"."Menu" VALUES (9, 1, '资源分享', NULL, '#', 220, 2, 1, 'f', '2,9');
INSERT INTO "public"."Menu" VALUES (10, 1, '程序人生', NULL, '#', 230, 2, 1, 'f', '2,10');
INSERT INTO "public"."Menu" VALUES (11, 1, '杂七杂八', NULL, '#', 240, 2, 1, 'f', '2,11');
INSERT INTO "public"."Menu" VALUES (13, 1, '玩机分享', NULL, '/cat/18', 2129, 7, 1, 'f', '2,7,13');
INSERT INTO "public"."Menu" VALUES (14, 1, '科技前沿', NULL, '/cat/30', 2130, 7, 1, 'f', '2,7,14');
INSERT INTO "public"."Menu" VALUES (16, 1, '硬件知识', NULL, '/cat/17', 2140, 7, 1, 'f', '2,7,16');
INSERT INTO "public"."Menu" VALUES (17, 1, '网络安全', NULL, '/cat/31', 2150, 7, 1, 'f', '2,7,17');
INSERT INTO "public"."Menu" VALUES (19, 1, '国际网络加速', NULL, '/cat/8', 2210, 9, 1, 'f', '2,9,19');
INSERT INTO "public"."Menu" VALUES (20, 1, '视频教程', NULL, '/cat/28', 2220, 9, 1, 'f', '2,9,20');
INSERT INTO "public"."Menu" VALUES (21, 1, '操作系统', NULL, '/cat/2', 2230, 9, 1, 'f', '2,9,21');
INSERT INTO "public"."Menu" VALUES (23, 1, '前端技术杂谈', NULL, '/cat/32', 2361, 10, 1, 'f', '2,10,23');
INSERT INTO "public"."Menu" VALUES (28, 1, '后端技术', NULL, '/cat/34', 2350, 10, 1, 'f', '2,10,28');
INSERT INTO "public"."Menu" VALUES (29, 1, '开发工具', NULL, '/cat/7', 2360, 10, 1, 'f', '2,10,29');
INSERT INTO "public"."Menu" VALUES (33, 1, '关于', NULL, '/about', 90, NULL, 0, 'f', '33');
INSERT INTO "public"."Menu" VALUES (42, 1, '网站公告', NULL, '/notice', 2429, 11, 1, 'f', '2,11,42');
INSERT INTO "public"."Menu" VALUES (43, 1, '免责声明', NULL, '/disclaimer', 2429, 11, 1, 'f', '2,11,43');
INSERT INTO "public"."Menu" VALUES (44, 1, '友情链接', NULL, '/links', 2428, 11, 1, 'f', '2,11,44');
INSERT INTO "public"."Menu" VALUES (46, 1, '国际网络加速', 'https://cdn.jsdelivr.net/gh/ldqk/imgbed/2018/2/5cc29f212a28f.gif', '/special/1', 351, 3, 2, 'f', '3,46');
INSERT INTO "public"."Menu" VALUES (48, 1, '开源项目', 'https://cdn.jsdelivr.net/gh/ldqk/imgbed/2018/2/5cc29f21dab23.jpg', '/special/2', 310, 3, 2, 'f', '3,48');
INSERT INTO "public"."Menu" VALUES (49, 1, '生产力工具', 'https://cdn.jsdelivr.net/gh/ldqk/imgbed/2018/2/5ccbdd60cf93b.jpg', '/special/4', 340, 3, 2, 'f', '3,49');
INSERT INTO "public"."Menu" VALUES (50, 1, '根据经纬度查询地理位置', NULL, '/tools/pos', 410, 4, 3, 'f', '4,50');
INSERT INTO "public"."Menu" VALUES (51, 1, '查询IP地址机房和路由信息', NULL, '/tools/ip', 420, 4, 3, 'f', '4,51');
INSERT INTO "public"."Menu" VALUES (55, 1, '绿色软件', NULL, '/cat/15', 1, 9, 1, 'f', '2,9,55');
INSERT INTO "public"."Menu" VALUES (59, 1, '详细地理位置转经纬度', NULL, '/tools/addr', 430, 4, 3, 'f', '4,59');
INSERT INTO "public"."Menu" VALUES (60, 1, '资源福利', 'https://cdn.jsdelivr.net/gh/ldqk/imgbed/20190613/129805093.jpg', '/special/5', 350, 3, 2, 'f', '3,60');
INSERT INTO "public"."Menu" VALUES (66, 1, '稀缺资源', 'https://cdn.jsdelivr.net/gh/ldqk/imgbed/2018/2/5ccbdd621ef9d.jpg', '/special/6', 360, 3, 2, 'f', '3,66');
INSERT INTO "public"."Menu" VALUES (68, 1, 'jetbrains资源', 'https://www.jetbrains.com/shop/static/images/jetbrains-logo-inv.svg', '/special/7', 370, 3, 2, 'f', '3,68');
INSERT INTO "public"."Menu" VALUES (69, 1, '📰Rss', NULL, '/rss', 9999, NULL, 0, 't', '69');
INSERT INTO "public"."Menu" VALUES (72, 1, 'DMCA', NULL, '/misc/10', 2450, 11, 1, 't', '2,11,72');
INSERT INTO "public"."Menu" VALUES (73, 1, '隐私声明', NULL, '/misc/11', 2460, 11, 1, 'f', '2,11,73');
INSERT INTO "public"."Menu" VALUES (74, 1, '稀缺资源', NULL, '#', 219, 2, 1, 'f', '2,74');
INSERT INTO "public"."Menu" VALUES (75, 1, '曝光台/无良公司', NULL, '/cat/43', 2510, 74, 1, 't', '2,74,75');
INSERT INTO "public"."Menu" VALUES (76, 1, '稀缺资源', NULL, '/cat/42', 2520, 74, 1, 'f', '2,74,76');
INSERT INTO "public"."Menu" VALUES (77, 1, '.NET开发技术', NULL, '/cat/38', 2340, 10, 1, 'f', '2,10,77');
INSERT INTO "public"."Menu" VALUES (78, 1, '开源项目', NULL, '/cat/41', 2305, 10, 1, 'f', '2,10,78');
INSERT INTO "public"."Menu" VALUES (82, 1, '养眼妹子/桌面壁纸', NULL, '/cat/49', 2509, 74, 1, 't', '2,74,82');
INSERT INTO "public"."Menu" VALUES (83, 1, '🐛Bug反馈', NULL, 'https://github.com/ldqk/Masuit.MyBlogs/issues', 9998, NULL, 0, 't', '83');
INSERT INTO "public"."Menu" VALUES (84, 1, '📺电竞显示器📺', NULL, '/cat/44', 18, NULL, 0, 't', '84');

-- ----------------------------
-- Table structure for Misc
-- ----------------------------
DROP TABLE IF EXISTS "public"."Misc";
CREATE TABLE "public"."Misc" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Title" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "Content" text COLLATE "pg_catalog"."default" NOT NULL,
  "PostDate" timestamptz(6) NOT NULL,
  "ModifyDate" timestamptz(6) NOT NULL
)
;

-- ----------------------------
-- Records of Misc
-- ----------------------------
INSERT INTO "public"."Misc" VALUES (10, 8, 'DMCA', '<p>很抱歉，如果本站侵犯了你的公司的任何权利。首先，我们不在服务器上托管任何文件。所有文件均由第三方站点托管和管理，因此，如果文件有任何问题，请先尝试与这些网站联系，如果内容存在问题，我们也会将其修改或删除。</p><p>本站一贯非常高度重视知识产权保护并遵守各项知识产权法律、法规和具有约束力的规范性文件。重视正版，打击盗版。根据法律、法规和规范性文件要求，本站旨在保护权利人的合法权益的措施和步骤，当权利人发现在本站生成的链接所指向的第三方网页的内容侵犯其合法权益时，权利人应事先向本站发出"权利通知"，本站将根据当地法律法规和政府规范性文件采取措施移除相关内容或链接。&nbsp;</p><p>本站符合17 U.S.C. §512条和《数字千年版权法案》( DMCA)。我们的政策是回应任何侵权通知，并根据《数字千年版权法案》(DMCA)和其他适用的知识产权法律采取适当的措施。如果您的受版权保护的内容已发布在本站上，或者通过搜索引擎返回了受版权保护的材料的链接，并且您希望删除该材料，则必须提供书面通讯，其中详细说明了以下部分中列出的信息。请注意，如果您虚假陈述我们网站上列出的侵犯版权的信息，您将承担赔偿责任（包括费用和律师费）。我们建议您首先与律师联系以寻求法律帮助。</p><p><br></p><p><span style="color: rgb(255, 0, 0);">您的版权侵权主张中必须包含以下内容：</span></p><p>•提供被授权人代表涉嫌侵权的专有权所有人行事的证据。</p><p>•提供足够的联系信息，以便我们与您联系。您还必须包括一个有效的电子邮件地址，必须包含公司名称，受版权保护的作品的经营/代理范围。</p><p>•您必须充分详细地声明声称受到侵权的受版权保护的作品，并包括至少一个搜索词，在该搜索词下材料会出现在ldqk.org中。</p><p>•声明投诉方有善意的信念，认为以投诉的方式使用该材料未经版权所有者，其代理人或法律的授权。</p><p>•声明通知中的信息准确无误，并受到伪证处罚，声明申诉方被授权代表据称受到侵犯的专有权的所有人行事。</p><p>•必须由授权人员签署，以代表据称受到侵犯的专有权的所有者行事。</p><p><br></p><p><span style="color: rgb(255, 0, 0);">关于下载地址的侵权：</span><br></p><p>▪&nbsp;此站内其它站上的侵权地址<br>针对未存储在本站服务器上的下载地址网盘存储的文件提出侵犯通知，请联系该存储网盘服务商提供版权侵犯通知。本站无权删除外部服务器上的文件，因此可能不会处理与该软件相关的版权侵权通知。</p><p>▪&nbsp;我们网站上的侵权下载地址<br>受版权证书保护的软件页面我们会删除链接，要联系本站提交版权侵权通知，您必须使用邮件联系。只有发送邮件，我们才能被接受处理，您的侵权通知必须包含以下所有内容：</p><p>您认为受版权保护的软件的详细信息，包括其在本站网站内的页面。</p><p>您是版权所有者或有版权代理所有者的信息或证明。<br><br></p><p>将书面侵权通知发送到以下地址，并将电子邮件通知发送至admin@masuit.com。</p><p>由于我们的搜索引擎存在问题，我们不能保证所有内容都会被删除，请向我们提供指向每个出版物的直接链接，这些链接侵犯了您的权利。只有在这种情况下，我们才能保证删除所有原始内容。</p><p>并且由于<strong>我们的内容会分发到世界各地的第三方的数以万计的公共缓存服务器上</strong>，受缓存策略的影响，本站数据删除后无法保证缓存仍然可能存在，且本站没有权限删除第三方公共缓存的内容，如需删除缓存内容，请直接联系这些缓存服务器运营商处理。</p><p>同时由于互联网爬虫横行，<strong>本站的公开内容也会在短时间内被大量的爬虫抓取</strong>，并将爬取结果存放其快照服务器/存档服务器中，如：Google、Baidu、Yandex，这类数据均不在本站的可控范围内，如需删除这类侵权内容，请联系快照服务器/存档服务器运营商处理。</p><p>我们会在收到电子邮件后2-30个工作日内核实并处理您的请求。但请注意，通过电子邮件将您的投诉发送给其他方（例如我们的Internet服务提供商）将不会加快您的请求，并可能由于投诉未正确提交而导致响应延迟。</p><p>但是除此之外，我们始终会谨慎处理dmca消息，如果收到这样的消息，我们将尽快采取适当的措施。我们尊重每家公司及其工作，因此，我们将尽全力帮助100％的解决此类问题。</p><h3 style="white-space: normal;">注：</h3><p style="white-space: normal;">1、为保证本站正常运作，凡是无法提供完整证明文件的请求本站一律不予处理，请谅解;</p><p style="white-space: normal;">2、因时间精力有限，凡是无法提供完整证明文件的请求本站均不会回复邮件，请谅解;</p><p style="white-space: normal;"><span style="color: rgb(255, 0, 0);">3、本站不接受任何付费删帖、亦未授权任何代理公司负责删帖，请勿轻信任何谣传谨防上当受骗！</span></p><p style="white-space: normal;"><span style="color: rgb(255, 0, 0);">4、在您提醒本站删帖前，本站不接受任何法律控诉。</span></p><p style="white-space: normal;"><span style="color: rgb(255, 0, 0);">5、本站工作时间：周一至周四10:00-17:00（UTC+6），工作时间段之外的任何请求本站不予处理！</span></p><p style="white-space: normal;"><span style="color: rgb(255, 0, 0);">6、本站运营范围：北美洲、南美洲、欧洲、非洲、澳洲、东南亚、南亚、西亚、北亚、中亚地区，超出上述地区范围的请求本站不予处理！</span></p>', '2019-11-01 01:55:59.6564+08', '2022-03-02 00:25:31.550151+08');
INSERT INTO "public"."Misc" VALUES (11, 8, '隐私政策', '<h3 style="text-align: center;">我们尊重您的隐私</h3><p>在本站的业务流程中，非常注重在处理您的个人数据的同时保护您的隐私。我们将根据相应的法律规定，对本网站收集的个人数据进行保密存储。本站对数据保护和信息安全有着严格的要求。本网站中可能包含其它第三方网站的链接，这些链接不受本隐私声明保护，我们建议您在访问这些网站及/或服务前首先了解第三方的隐私声明。</p><h3 style="text-align: center;">收集和处理个人数据</h3><p>在您访问本网站的时候，网站服务器会自动记录您的互联网服务供应商的名称、您通过哪个网站访问、您实际访问的网站、以及您访问的日期和时长。可能会使用cookie和活动脚本（如JavaScript）来追踪访问者的偏好，并相应优化本网站。您可以将浏览器设置为在收到cookie时通知您或拒绝接受cookie。请注意，如果您关闭cookie，那么绝大多数网站的特定栏目可能都会无法正常工作。除非您自愿提供，例如在注册、调查、竞争或执行合同的情况下提供，否则我们不会保存其他个人数据。</p><p>被动信息征集和使用当您浏览网站时，网站可能会使用各种技术，在您未主动提供的情况下搜集某些信息。我们以及我们的第三方服务提供商会以各种方式被动搜集和使用信息，包括：</p><p>- 通过您的浏览器：大多数浏览器都会搜集某些信息，如您的媒体访问控制 (MAC) 地址、计算机类型（Windows 或 Macintosh）、屏幕分辨率、操作系统版本以及互联网浏览器类型和版本。我们可能会搜集类似信息，比如，如果您使用移动设备访问网站，我们会搜集您的设备类型和标识之类。</p><p>- 使用 cookies：Cookies 是直接保存在您所使用的电脑中的信息片段。通过 Cookies，可以搜集诸如浏览器类型、浏览网站所用的时间、访问页面、语言首选项等信息。我们以及我们的服务提供商使用这些信息的原因在于出于安全目的，加快导航、更有效地显示信息，以及在使用网站的同时实现体验个性化。 我们还会使用 cookies 来识别您的电脑或设备，这样能使您在网站使用时更加方便，比如记住您的购物车中已经有哪些东西。此外，我们还利用 cookies 来搜集网站使用率方面的统计信息，以便不断改进网站的设计和功能，了解各人的使用习惯，并帮助我们解决这方面的问题。Cookies 还可以让我们了解哪些广告或产品最合乎您的兴趣，并当您浏览网站时将其显示出来。我们也可能会在网站广告中使用 cookies 来跟踪消费者对我们的广告的反应。</p><p>您可以按照浏览器的使用说明拒绝接收这些 cookies；不过，如果您选择不接受，在使用网站的过程中可能会有所不便。如欲了解 cookies 方面的更多内容，请访问&nbsp;<a href="http://www.allaboutcookies.org/" target="_blank" data-cms-ai="0">http://www.allaboutcookies.org</a>。</p><p>- IP 地址：您所使用的电脑的 IP 地址是由互联网服务提供商（ISP）自动分配的。当用户访问本网站时，我们的服务器会自动识别 IP 地址，并将其与访问时间和访问的页数一起记录在日志文件中。搜集 IP 地址是互联网上的通行做法，很多网站都是自动进行的。我们使用 IP 地址的目的包括计算网站使用率、帮助诊断服务器问题、网站管理等。</p><p>- 设备信息：我们可能会搜集移动设备方面的信息，如设备的唯一标识。</p><p>- 嵌入内容：我们发布的文章页面可能会包含嵌入的内容（如视频、图像、文章等），这些嵌入的内容很多是多次编辑过，和来自其他站点的嵌入内容的行为和您直接访问这些其他站点没有主要区别。</p><p>- 文章评论：当您提交评论时，我们会收集评论列表所显示的数据，和访客的 IP 地址及浏览器的 UA标识来检查垃圾评论。</p><p>- 站点统计：我们使用了 Google Analytics 和 CNZZ统计 来进统计网站运行情况，这些数据是匿名的。</p><p><br></p><p>我们保留多久您的信息：如果您留下评论，评论和其它数据将被无限期保存。我们这样做以便能识别并自动批准任何后续评论，而不用将这些后续评论加入待审队列。</p><h3 style="text-align: center;">个人数据的使用和披露以及用途规定</h3><p>我们采取多种安全措施来保护你的个人信息安全。我们使用一个安全的服务器储存你的个人信息和对话内容。只有管理人员才能获取你的个人信息，并且，没有你的书面同意，管理人员不会透露任何信息。</p><p>本站只会将您的个人数据用于网站技术管理、用户体验优化、产品调查等用途，并且仅在必要范围内使用。未经您的许可，我们不会向本站以外的第三方披露您的个人数据。但在下列情况下，我们可能会向本站以外第三方披露您的个人数据：</p><p>（1）获得您的事先同意；</p><p>（2）合法并可执行的法令、法律、传票或其他法规（总称“法令”）要求披露；</p><p>（3）为保障本站合法权利和利益，例如伪调查、恶意使用本站功能、预防和处理欺诈以及安全问题进行披露。</p><h3 style="text-align: center;">安全</h3><p>本站使用了多种安全措施来保护我们拥有的数据不会被操纵、丢失、破坏，防止未经授权的人员访问并组织未经授权的披露。本站将随着新技术的发展不断更新安全程序。</p><h3 style="text-align: center;">服务条款</h3><p>1.本站内容仅提供除中国大陆以外地区的华人华侨同胞交流学习，其他地区请根据当地法律法规酌情考虑使用本站内容。</p><p>2.本站所有内容任何人均可共同参与编辑，本站不对任何内容承担相关的责任和权利。</p><p style="white-space: normal;">3.访问本站的用户必须明白，本站对提供下载的第三方软件不拥有任何权利，其版权归该资源的合法拥有者所有。</p><p style="white-space: normal;">4.本站保证站内提供的所有可下载资源（软件等）都是按“原样”提供，本站未做过任何改动；但本网站不保证本站提供的下载资源的准确性、安全性和完整性；同时本站也不承担用户因使用这些下载资源对自己和他人造成任何形式的损失或伤害。不论何种情形我们都不对任何由于使用或无法使用本站提供的信息所造成的直接的、间接的、附带的、特殊的或余波所及的损失、灵失、债务或中断负任何责任﹝不论是可预见或是不可预见的，即使我们巳被告知这种可能性﹞。</p><h3 style="text-align: center;">选择自由</h3><p>本站将可能使用您的数据来向您通知本站的相关订阅数据和服务并在适当情况下征求您的意见。您可以自愿参加这样的活动。如果您不同意参加，您可以随时告知我们，我们将相应禁止使用您的数据。</p><h3 style="text-align: center;">修订</h3><p>本站将不时修订本隐私声明，并将在网站显著位置发布相关修订通知，您可以随时访问。</p><h3 style="text-align: center;">联系方式</h3><p>如果您需要了解任何信息，欢迎提出建议，或投诉个人数据处理问题，您可以联系站长。尽管本站已尽力保证数据及时准确，但如果存在任何错误数据，我们将根据您的要求为您更正该信息。</p><p style="text-align: right;"><strong>更新于2020年11月12日</strong></p>', '2019-11-01 02:08:04.9784+08', '2021-08-13 07:17:56.648441+08');
INSERT INTO "public"."Misc" VALUES (14, 8, '信杀软，无破解！', '<p><span style="font-size: 18px;">最近老是接到很多访客投诉说本站资源报毒的问题，这种问题请添加到允许信任就可以了。<span style="color: rgb(255, 0, 0);">本站所提供的任何二进制文件均不具备权威性</span>，如需体验官方正版，请从相应的官网渠道下载，请悉知！村通网并不可怕。如果九年义务教育还看不懂报毒的英文的话，请购买正版。信杀软，无破解！</span><img src="https://cdn.jsdelivr.net/gh/ldqk/imgbed/20191124/s980e0hxup6o.png" style="white-space: normal;"></p><p style="font-size: 18px;"><img src="/static/images/2021/09/26/image_1042.png" alt="image.png"></p><p style="font-size: 18px;">如果浏览器页面报红被阻止，将这个选项关闭即可：</p><p><img src="https://git.imweb.io/ldqk/imgbed/raw/master/2021/09/26/image_1041.png" alt="image.png"></p>', '2020-04-01 22:28:39.904296+08', '2021-09-26 18:43:08.281568+08');
INSERT INTO "public"."Misc" VALUES (17, 8, '广告服务', '<h3 style="text-align: center;">本站概述</h3><p>本站访问量每天稳定在<span style="color: rgb(255, 0, 0);">10000+PV</span>以上，访问的用户群基本上都是软件爱好者、软件开发人员、网站网管及相关的网络从业人员（如设计师、产品经理、剪辑师、开发者等），年龄在17岁到45岁之间，适合广告类型：应用软件、服务器租用、网站联盟、商业软件、网站系统、视频教程、编程培训、网络加速等与本站内容相关的广告。</p><h3 style="text-align: center;">广告联系<br></h3><p>邮箱：admin@masuit.com<br></p><p>（<span style="color: rgb(255, 0, 0);">本站不接受任何与邮件营销、欺诈、木马、博彩、虚假广告、虚拟货币等非法信息相关的广告业务，除以上联系方式外，任何自称懒得勤快广告QQ与邮件等均为假冒</span>）</p><h3 style="text-align: center;">广告形式</h3><p>本站提供广告条及各种形式的广告服务(下面是几种常见的广告形式)</p><p>Banner：即首页轮播广告，一个表现商家广告内容的图片，是互联网广告中最基本的广告形式，尺寸是1800*600像素，一般是使用jpg或png格式的图像文件。Banner 一般翻译为网幅广告、旗帜广告、横幅广告等。</p><p>列表页插入项:&nbsp;即网站文章页中随机插入的和文章列表项样式相同的广告，由标题、描述以及宣传图片组成，标题50字内，描述50-200字，图片大小为600*400或300*200。</p><p>边栏广告：即网站所有列表页边栏插入的广告，由标题和宣传图片组成，标题50字内，图片大小为600*400或300*200。</p><p>内页广告：即所有详情页正文后插入的广告，由标题、描述以及宣传图片组成，标题50字内，描述50-200字，图片大小为600*400或300*200。</p><p>软文广告：即以发表文章的形式投放的广告，和本站内容融为一体。</p><p>定制广告：由投放方按自己需求在本站进行定向投放的固定广告。</p><p>普通文章：以文章的形式发布广告内容。</p><p>置顶文章：将文章广告置顶到网站首页。</p><h3 style="text-align: center;">投放方式</h3><p>本站支持订单分润的形式以及固定租金的形式进行投放，你可以选择上述的一种或多种形式的广告进行同时投放，不同的价格区间会享有不同程度的曝光量。</p><p>且由于各广告商每月的投放竞价不同，曝光量会根据实际的价格进行自动调整。<br></p><p>招聘广告或公益广告可以免费投放。</p><h3 style="text-align: center;">投放说明</h3><p>1、所有价格单位：元/月，1个月开始投放（1个月=30天）。</p><p>2、付款到达之后即可开始投放广告。</p><p>3、虚拟主机的托管网站或其他商业网站的广告原则上要求公司性质，但也可以接受个人业务！</p><p>4、不接受六合彩、邮件营销、放置木马及性爱激情类站点的广告！不接弹窗广告！ 不接插件、捆绑类广告！</p><p>5、本网站是个人网站，投放广告不开具发票！</p><p>6、广告位出租后将不予退还，也不能更改为其他位置！</p><p>7、广告续订请提前三天付款！未能及时续订将有权保留其他广告商！</p><p>8、广告图片必须经过我的审查批准（例如文件大小，图像质量和内容），并且广告图像为JPEG或PNG格式！</p><p>9、如果广告商制作的广告是虚假的，或者有人举报为骗子产品或骗子公司，而广告商无法提供有效的答复或解释，则网站有权删除该广告，并且不予退款。</p><p>10、注意：现有的广告网站有权保留给其他公司或个人。如果您在口头上同意在网站上放置广告位，但尚未付款，那么我们也有权向其他公司或个人预订！</p>', '2020-07-03 00:50:37.862304+08', '2022-05-18 22:40:11.169405+08');

-- ----------------------------
-- Table structure for Notice
-- ----------------------------
DROP TABLE IF EXISTS "public"."Notice";
CREATE TABLE "public"."Notice" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Title" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "Content" varchar(8192) COLLATE "pg_catalog"."default" NOT NULL,
  "PostDate" timestamptz(6) NOT NULL,
  "ModifyDate" timestamptz(6) NOT NULL,
  "ViewCount" int4 NOT NULL,
  "StartTime" timestamptz(6),
  "EndTime" timestamptz(6),
  "NoticeStatus" int4 NOT NULL
)
;

-- ----------------------------
-- Records of Notice
-- ----------------------------
INSERT INTO "public"."Notice" VALUES (22, 8, '特别说明', '<p><span style="font-size: 18px;">本站所有下载资源<span style="color: rgb(255, 0, 0);">不收任何费用</span>，网站提供的自愿</span><a href="/donate" target="_blank" style="font-size: 18px; text-decoration: underline;"><span style="font-size: 18px;">打赏或捐赠</span></a><span style="font-size: 18px;">仅为网站服务支持，<span style="font-size: 18px; color: rgb(255, 0, 0);">鄙视一切薅完正版商羊毛又薅老百姓99元的行为。</span>一切二次收费都是个人谋取暴利的借口，欢迎有能力的朋友共享稀缺资源，可在</span><a href="http://masuit.com/post/publish" target="_self" textvalue="http://masuit.com/post/publish" style="font-size: 18px; text-decoration: underline;"><span style="font-size: 18px;">http://masuit.com/post/publish</span></a><span style="font-size: 18px;">进行投稿，互联网分享精神，专注收藏与分享。你薅群众，我就薅你。<span style="font-size: 18px; color: rgb(255, 0, 0);">所有软件下载均为个人使用，请勿用于商业用途！</span>支持正版请一定<span style="font-size: 18px; color: rgb(255, 0, 0);">认准官网</span>，所谓的中文官网如果页脚标注为<span style="color: rgb(255, 0, 0); font-size: 20px;">“苏州XXX”</span>的均为盗版官网！</span></p>', '2018-04-27 00:43:08+08', '2018-09-24 21:51:05+08', 12316, NULL, NULL, 1);
INSERT INTO "public"."Notice" VALUES (48, 8, '关于破解！', '<p><span style="font-size: 18px;">很多网友经常反映说在这儿下载的有些软件被<span style="font-size: 18px; color: rgb(255, 0, 0);">数字卫士、企鹅管家、Defender</span>等杀软报毒，博主在此强调一下，既然是破解软件，那就不免会有一些杀软报毒的情况，<span style="font-size: 18px; color: rgb(255, 0, 0);">站内99%以上的软件都是经过博主亲自测试过再分享出来的，博主自用杀软为火绒</span>。</span></p><p><span style="font-size: 18px;">有些软件也是博主深度使用的，诸如：TeamViewer、KMS激活工具、PrimoCache、aida64、腾讯QQ等，我用着到目前是没出现过任何问题的，但也并<span style="font-size: 18px; color: rgb(255, 0, 0);">不保证在你的机器上不会出问题，博主也不是专职做软件测试，不能保证权威，使用破解软件造成的任何损失后果自负</span>，毕竟是破解软件，如果心存疑虑，建议还是<a href="https://partner.lizhi.io/ldqk/cp" target="_blank">购买正版</a>享受官方支持服务！</span></p><p><span style="font-size: 18px;">或许你们也会说Defender是微软自家的，没有谁比微软更了解自己，但报毒的几句英文信息请仔细分析一下，<span style="font-size: 18px; color: rgb(255, 0, 0);">村通网并不可怕。如果九年义务教育还看不懂报毒的英文的话，那还是<a href="https://partner.lizhi.io/ldqk/cp" target="_blank">购买正版</a>吧</span>！</span></p>', '2019-03-12 20:59:02.66+08', '2019-04-17 21:59:01.481186+08', 185578, NULL, NULL, 1);
INSERT INTO "public"."Notice" VALUES (74, 8, '信杀软，无破解！', '<p><span style="font-size: 18px;">最近老是接到很多访客投诉说本站资源报毒的问题，这种问题请添加到允许信任就可以了。<span style="color: rgb(255, 0, 0);">本站所提供的任何二进制文件均不具备权威性</span>，如需体验官方正版，请从相应的官网渠道下载，请悉知！村通网并不可怕。如果九年义务教育还看不懂报毒的英文的话，请购买正版。信杀软，无破解！</span><img src="https://cdn.jsdelivr.net/gh/ldqk/imgbed/20191124/s980e0hxup6o.png"></p>', '2019-08-11 01:07:53.389875+08', '2019-09-12 05:23:19.875+08', 23599, NULL, NULL, 1);
INSERT INTO "public"."Notice" VALUES (117, 8, '儿童节快乐！', '<p>祝大家儿童节快乐！</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://cdn.jsdelivr.net/gh/ldqk/holiday@main/%E5%85%84%E8%B4%B5%E2%99%82%E5%A4%A9%E7%BA%BF%E5%AE%9D%E5%AE%9D.mp4" type="video/mp4"></video>', '2021-06-01 13:00:02.355953+08', '2021-06-02 13:00:03.926367+08', 3702, '2021-06-01 08:00:00+08', '2021-06-02 08:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (119, 8, '今天是父亲节', '<p>父亲是孩子成长中最坚强有力的后盾，默默地保护着孩子。今天是父亲节，希望各位哲♂学家把最真挚的祝福，送给自己的父亲。</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://cdn.jsdelivr.net/gh/ldqk/holiday@main/%E3%80%90%E5%85%84%E8%B4%B5%E3%80%91%E7%88%B6%E2%99%82%E4%BA%B2.mp4" type="video/mp4"></video>', '2021-06-20 13:00:14.314453+08', '2021-06-21 13:00:13.64746+08', 3696, '2021-06-20 08:00:00+08', '2021-06-21 08:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (123, 8, '毕业快乐！', '<p style="text-align: center;">各位，硕士毕业快乐！</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://cdn.jsdelivr.net/gh/ldqk/holiday@main/%E5%85%B0%E4%BA%AD%E2%99%82%E5%BA%8F.mp4" type="video/mp4"></video>', '2021-06-26 03:42:54.896484+08', '2021-06-28 13:00:13.004882+08', 7250, '2021-06-26 08:00:00+08', '2021-06-28 08:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (130, 8, '开学啦，欢迎新同学！', '<p style="text-align: center;">开学啦，欢迎新同学！</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://cdn.jsdelivr.net/gh/ldqk/holiday@main/%E3%80%90%E5%93%B2%E5%AD%A6%E3%80%91%E5%BC%80%E2%99%82%E5%AD%A6.mp4" type="video/mp4"></video>', '2021-09-01 13:00:13.757263+08', '2021-09-02 13:00:11.344864+08', 4162, '2021-09-01 08:00:00+08', '2021-09-02 08:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (128, 8, '中秋节快乐！', '<p style="text-align: center;">大家一起来赏♂月吧</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://zexue.vercel.app/%E8%B5%8F%E2%99%82%E6%9C%88.mp4" type="video/mp4"></video>', '2021-08-21 00:54:42.967704+08', '2021-09-22 13:00:12.819672+08', 3586, '2021-09-20 16:00:00+08', '2021-09-21 16:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (134, 8, '祝各位兄贵们圣诞快乐！', '<p>圣诞快乐！???</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://cdn.jsdelivr.net/gh/ldqk/kichiku.icu@master/%E3%80%90%E5%85%84%E8%B4%B5%E3%80%91%E5%9C%A3%E2%99%82%E8%AF%9E%E2%99%82%E8%8A%82.mp4" type="video/mp4"></video>', '2021-12-24 13:00:14.373412+08', '2021-12-26 13:00:04.918172+08', 5985, '2021-12-24 08:00:00+08', '2021-12-26 08:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (105, 8, '我们更新了《隐私声明》', '<p><span style="font-size: 18px;">我们更新了《隐私声明》的相关条款，点击链接进行查看：</span><a href="/misc/11" target="_blank" textvalue="https://masuit.com/misc/11" style="font-size: 18px; text-decoration: underline;"><span style="font-size: 18px;">https://masuit.com/misc/11</span></a><span style="font-size: 18px;">。</span></p>', '2020-11-12 22:57:30.360351+08', '2020-11-12 22:57:30.360351+08', 37964, NULL, NULL, 1);
INSERT INTO "public"."Notice" VALUES (104, 8, '蓝奏云链接无法打开的解决方案', '<p>蓝奏云链接无法打开的解决方案：蓝奏云频繁换域名，官方公告为<span style="color: rgb(255, 0, 0);">部分地区无法访问</span>，猜测可能有DNS污染，所以打不开的用户建议修改DNS试试。<br></p>', '2020-11-02 23:51:20.232421+08', '2021-03-23 21:23:15.586914+08', 266184, NULL, NULL, 1);
INSERT INTO "public"."Notice" VALUES (118, 8, '芒种so♂horny！', '<video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://raw.iqiq.io/ldqk/private/main/%E3%80%90%E5%93%B2%E5%AD%A6%E3%80%91%E8%8A%92%E2%99%82%E7%A7%8D.mp4" type="video/mp4"></video><p>..</p>', '2021-06-05 13:00:12.379328+08', '2022-06-01 14:16:21.616882+08', 3319, '2022-06-06 00:00:00+08', '2022-06-07 00:00:00+08', 0);
INSERT INTO "public"."Notice" VALUES (114, 8, '异常行为分析升级公告', '<p>为节省网站带宽流量等资源，将逐步添加各种异常行为检测，利用脚本爬虫或短时间内有大量记录的异常使用都有可能被封锁IP或IP段或IP所在整个机房甚至所在地区。如不喜欢离开即可！</p>', '2021-03-29 05:18:31.15332+08', '2021-05-21 07:16:56.033914+08', 183343, NULL, NULL, 1);
INSERT INTO "public"."Notice" VALUES (125, 8, '关于外站冒用本站马甲的声明', '<p>近日有网友反馈，在InfoQ等第三方媒体网站发现有冒用本站马甲进行与本站价值观相违背的一些商业行为，鉴于此，本站强调：<span style="color: rgb(255, 0, 0);">未在本站页面中公布过的任何第三方平台与“懒得勤快”同名的媒体账号均为假冒</span>，请大家注意甄别，谨防上当受骗！</p>', '2021-07-12 21:41:09.793115+08', '2021-07-12 21:44:55.058524+08', 17668, NULL, NULL, 1);
INSERT INTO "public"."Notice" VALUES (121, 8, '同学们高♂尻加油！', '<p>新日暮里睾♂等学校统一尻♂试是由蕉育部组织，新日暮里每年一度的dark事。通过对兄贵的哲学理论、摔跤技巧、人体乐器演奏等科目的考察，筛选出合格人才步入dark学。数百万年轻兄贵在经历三年残♂酷的更衣室苦摔后迎来了这最后的两天，不管结果如何，这都是不可磨灭的人生标记，睾♂考后悔三年，不睾♂考后悔一辈子。在这条路上的兄贵们，一起努力吧！</p><p><img src="/static/images/2021/05/24/psc_1314.jpg"></p>', '2021-06-06 13:00:16.040023+08', '2022-05-29 21:40:56.551064+08', 8446, '2022-06-07 00:00:00+08', '2022-06-09 00:00:00+08', 0);
INSERT INTO "public"."Notice" VALUES (133, 8, '网站升级公告', '<p><span style="font-size: 20px;">网站已升级.NET6.0(</span><span style="font-size: 20px; text-decoration: line-through;">踩坑</span><span style="font-size: 20px;">)，可能会出现一些功能性的bug，如有发现，请及时在<a href="/msg" target="_blank">留言板</a>或<a href="https://github.com/ldqk/Masuit.MyBlogs/issues" target="_blank">github</a>反馈，感谢大家~</span></p>', '2021-11-09 22:32:11.440455+08', '2021-11-09 22:32:31.143289+08', 66301, NULL, NULL, 2);
INSERT INTO "public"."Notice" VALUES (129, 8, '国庆快乐！', '<p style="text-align: center;">国庆快乐！</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://cdn.jsdelivr.net/gh/ldqk/private@main/%E3%80%90%E5%85%84%E8%B4%B5%E3%80%91%E4%BA%AE%E2%99%82%E5%89%91.mp4" type="video/mp4"></video>', '2021-10-01 13:00:13.892269+08', '2021-10-03 07:07:36.335055+08', 10081, '2021-09-29 16:00:00+08', '2021-10-05 16:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (127, 8, '关于镜像站的说明', '<p>近日本站发现网络上存在与本站所有内容完全相同的网站存在，无疑是本站的镜像站，虽然也很感谢这类镜像站的建立帮助本站进行分流，但还是鉴于此，本站需要说明：镜像站内容与本站无任何关联，也可能存在其他钓鱼或篡改的可能性，内容的准确性也无法保证，由于本站程序开源共享，其他人也有可能利用本站的开源程序搭建站点或做二次开发，所以本站尚未正式公示过的其他域名内容相同的均为假冒站点或爬虫镜像站点或高仿站，请各位网友注意甄别，谨慎使用镜像站！</p>', '2021-07-20 19:26:49.218258+08', '2021-07-21 00:30:29.061305+08', 134043, NULL, NULL, 1);
INSERT INTO "public"."Notice" VALUES (135, 8, '新年♂快乐！', '<p>新日暮里♂娼片公司全体员工恭祝各位兄♂贵们新年快乐！明天会更好！祝大家在新的一年里身体健康，van♂shit♂如意，性♂想shit♂成，dark?♂大力！去年勃起至今！</p><p><img src="/static/images/2021/12/31/v2-67a8da617f03b6e178f32d40ed9e1731_720w_1303.jpg"></p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://zexue.masuit.org/%E8%BF%87%E2%99%82%E5%B9%B4.mp4" type="video/mp4"></video>', '2022-01-31 13:00:05.925562+08', '2022-02-06 13:00:05.103066+08', 13005, '2022-01-31 08:00:00+08', '2022-02-06 08:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (136, 8, '放假了，要记得常回家看看', '<p>新日暮里♂娼片公司在此提醒大家：放假了，要记得常回家看看！</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://zexue.masuit.org/%E3%80%90%E5%93%B2%E5%AD%A6%E3%80%91%E5%B8%B8%E5%9B%9E%E5%AE%B6%E7%9C%8B%E7%9C%8B.mp4" type="video/mp4"></video>', '2022-01-25 18:24:50.678244+08', '2022-01-31 13:00:05.938756+08', 11693, '2022-01-30 08:00:00+08', '2022-01-31 08:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (137, 8, '兄♂贵们，元萧♂节快乐！', '<p>转眼间又到了元宵节，van仍在辛勤地工作，晚上加班，van买了一碗汤圆，送给了饿着肚子的同事。这时，隔壁传来了比利王的歌声，余音绕耳，三日不绝，van被歌声深深地打动了，渐渐流下泪来，想起来他的家与家人。于是，他离开办公室，没有回公寓，而是往家走去。推开门，看到全家人都在等他，van和全家兄贵一起，唱着儿时的歌曲......</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://zexue.masuit.org/%E5%8D%96%E6%B1%A4%E2%99%82%E5%9C%86.mp4" type="video/mp4"></video>', '2022-02-15 13:00:08.324633+08', '2022-02-16 13:00:15.604737+08', 4067, '2022-02-15 08:00:00+08', '2022-02-16 08:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (131, 8, '开学过后就该军♂训啦', '<p style="text-align: center;">开学过后就该军♂训啦</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://cdn.jsdelivr.net/gh/ldqk/holiday@main/%E5%86%9B%E2%99%82%E8%AE%AD.mp4" type="video/mp4"></video>', '2021-09-02 13:00:11.330007+08', '2021-09-04 13:00:05.662871+08', 7309, '2021-09-02 08:00:00+08', '2021-09-04 08:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (138, 8, '做个小调查：您最值得推荐的软件有哪些？', '<p><span style="font-size: 18px;">做个小调查：<strong>您最值得推荐的软件有哪些</strong>？</span><a href="http://hk.mikecrm.com/hsewFxb" target="_blank" textvalue="http://hk.mikecrm.com/hsewFxb" style="font-size: 18px; text-decoration: underline;"><span style="font-size: 18px;">http://hk.mikecrm.com/hsewFxb</span></a></p>', '2022-04-14 19:41:36.435857+08', '2022-04-14 19:44:42.996639+08', 70546, NULL, NULL, 1);
INSERT INTO "public"."Notice" VALUES (75, 8, '喜报！', '<p><span style="font-size: 18px;">因博主个人精力有限，所以为了照顾更多的小白朋友，本站目前已经跟<span style="color: rgb(255, 0, 0); font-size: 24px;">百度</span>和<span style="color: rgb(255, 0, 0); font-size: 20px;">Google</span>两大公司达成深度和长期的合作关系，将来大家在本站遇到的任何问题，均可随时随地的使用这两家公司提供的服务帮助解决你的问题，并且大多数时候能够秒解你的问题，关键还是<span style="color: rgb(255, 0, 0); font-size: 20px;">免费</span>的哦！如果他们最后实在是解决不了你的问题，再向本站站长寻求帮助，<span style="font-size: 18px; color: rgb(255, 0, 0);">在你询问之前，也请先尝试本站的站内搜索以及自己动手尝试一下</span>，理解万岁！</span></p><p><span style="font-size: 20px;">百度：</span><a href="https://www.baidu.com/" target="_blank" textvalue="https://www.baidu.com/" style="font-size: 20px; text-decoration: underline;"><span style="font-size: 20px;">https://www.baidu.com/</span></a></p><p><span style="font-size: 20px;">Google：</span><a href="https://www.google.com/" target="_blank" textvalue="https://www.google.com/" style="font-size: 20px; text-decoration: underline;"><span style="font-size: 20px;">https://www.google.com/</span></a></p>', '2019-08-06 07:01:33.409179+08', '2020-03-11 18:45:46.652343+08', 405110, NULL, NULL, 1);
INSERT INTO "public"."Notice" VALUES (140, 8, '兄♂贵们，六一快乐！', '<p>转眼间又到了六一儿童节，总是到了摔跤♂前，才知道该练的肌肉没有练♂，总是要等到调♂教以后，才知道该电的boy没有电！怀念啊♂我们的童♂黏~</p><video controls="" autoplay="" __idm_id__="219412481" width="100%"><source src="https://raw.iqiq.io/ldqk/private/main/%E7%AB%A5%E2%99%82%E5%B9%B4.mp4" type="video/mp4"></video>', '2022-06-01 05:00:11.356798+08', '2022-06-02 05:00:07.613138+08', 2870, '2022-06-01 00:00:00+08', '2022-06-02 00:00:00+08', 2);
INSERT INTO "public"."Notice" VALUES (132, 8, '关于浏览器去广告扩展对本站部分页面下载地址误杀屏蔽的解释说明', '<p>近日有收到一些反馈说本站有部分文章页看不到下载地址的情况，经过摸索排查发现是浏览器的去广告扩展(如:AdBlock、uBlock等)有对本站一些正常的非广告元素进行了错误的屏蔽造成【下载地址】不见了，站长也在一些屏蔽规则里找到了这样的一条规则：</p><p><img src="/static/images/2021/10/02/image_2258.png"></p><p>而<strong><span style="color: rgb(255, 0, 0);">该class是本站页面正常内容元素的css类</span></strong>，竟然被当做垃圾广告屏蔽，虽然并且在上次发现这种情况后立马做出了相关的修正进行调整防屏蔽，但又在短时间内看到的屏蔽规则出现在了去广告插件的列表里，想必是有别有用心的人故意为之！若大家也有遇到文章页【下载地址】不见的这种情况，可选择将本站提交至去广告插件白名单，或者临时对本站关闭去广告插件即可，本站也历来承诺：永不接入第三方的广告联盟，体验至上！</p><p>现如今做分享太难了，这样都能被搞~</p>', '2021-10-03 07:03:47.848719+08', '2021-10-03 07:07:28.423694+08', 232512, NULL, NULL, 1);

-- ----------------------------
-- Table structure for PerformanceCounter
-- ----------------------------
DROP TABLE IF EXISTS "public"."PerformanceCounter";
CREATE TABLE "public"."PerformanceCounter" (
  "Time" int8 NOT NULL,
  "CpuLoad" float4 NOT NULL,
  "MemoryUsage" float4 NOT NULL,
  "DiskRead" float4 NOT NULL,
  "DiskWrite" float4 NOT NULL,
  "Upload" float4 NOT NULL,
  "Download" float4 NOT NULL,
  "ServerIP" varchar(128) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of PerformanceCounter
-- ----------------------------

-- ----------------------------
-- Table structure for Post
-- ----------------------------
DROP TABLE IF EXISTS "public"."Post";
CREATE TABLE "public"."Post" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Title" varchar(256) COLLATE "pg_catalog"."default" NOT NULL,
  "Author" varchar(24) COLLATE "pg_catalog"."default" NOT NULL,
  "Content" text COLLATE "pg_catalog"."default" NOT NULL,
  "ProtectContent" text COLLATE "pg_catalog"."default",
  "PostDate" timestamptz(6) NOT NULL,
  "ModifyDate" timestamptz(6) NOT NULL,
  "IsFixedTop" bool NOT NULL,
  "CategoryId" int4 NOT NULL,
  "Email" varchar(64) COLLATE "pg_catalog"."default" NOT NULL,
  "Modifier" varchar(128) COLLATE "pg_catalog"."default",
  "ModifierEmail" varchar(64) COLLATE "pg_catalog"."default",
  "Label" varchar(256) COLLATE "pg_catalog"."default",
  "Keyword" varchar(256) COLLATE "pg_catalog"."default",
  "VoteUpCount" int4 NOT NULL,
  "VoteDownCount" int4 NOT NULL,
  "AverageViewCount" float8 NOT NULL,
  "TotalViewCount" int4 NOT NULL,
  "IP" varchar(128) COLLATE "pg_catalog"."default",
  "DisableComment" bool NOT NULL,
  "DisableCopy" bool NOT NULL,
  "LimitMode" int4,
  "Regions" varchar(512) COLLATE "pg_catalog"."default",
  "ExceptRegions" varchar(512) COLLATE "pg_catalog"."default",
  "Rss" bool NOT NULL,
  "ProtectContentMode" int4 NOT NULL,
  "Locked" bool NOT NULL,
  "ProtectContentLimitMode" int4,
  "ProtectContentRegions" varchar(512) COLLATE "pg_catalog"."default",
  "ProtectPassword" varchar(128) COLLATE "pg_catalog"."default",
  "Redirect" varchar(4096) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of Post
-- ----------------------------
INSERT INTO "public"."Post" VALUES (1685, 3, '正版Eagle，让你高效管理素材库的设计利器，专为设计师打造的图片收藏及管理工具', '懒得勤快', '<p style="text-align: center;"><img src="/static/images/2021/04/02/6375299663073535161693608.png"></p><p><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/20191202/sa03f4ys52io.jpeg"></p><p>想必大家每天逛微博、论坛会即兴保存一些有意思的图片，看视频、聊天时有顺手截图的习惯；如果你还经常在网上发动态、文章，肯定会制造不少图片，更不用说设计师了。</p><p>对重命名图片都懒得动的人来说，即使每天定期清理，也只是随手扔进云盘或回收站的区别。</p><p>这时候，只有专门的图片管理工具能帮到你了。</p><h3>一站式管理素材，Eagle 就够了</h3><p>不论是 UI / UX 设计、插画、建筑等领域的专业创作者，还是素材收集爱好者，Eagle 都可以帮你高效地整理电脑中的图片、字体、视频、音频等各种素材。Eagle 深受世界上众多优秀的设计团队所信赖，堪称设计师的「第二大脑」。</p><h3>收集灵感只需一瞬</h3><p>使用 Eagle 收集素材，帮你不错过任何灵感闪现一瞬，不仅可以一键拖拽素材迅速添加，还可以采取屏幕截图和浏览器扩展的方式捕捉值得收藏的画面。</p><p><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2020/12/08/13844000294451b5dc41f.png" style="box-sizing: border-box; border: 0px; display: inline-block; vertical-align: baseline; margin: 0px; padding: 0px; font: inherit; max-width: 100%;"></p><p>Eagle 支持管理超过 59 种以上的文件格式，不仅包括常见的 Sketch、PS、Ai、GIF、JPG、PNG、PDF 等图像文件，而且支持 Keynote、PPT 等文档和 MP3、MP4 等影音文件。</p><p><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2020/12/08/137380001ecc33b3be180.png" style="box-sizing: border-box; border: 0px; display: inline-block; vertical-align: baseline; margin: 0px; padding: 0px; font: inherit; max-width: 100%;"></p><h3>整理素材得心应手</h3><p>难道必须安装软件才能预览特定素材？使用 Eagle 无需打开文件即可实时预览，更有瀑布流、自适应布局，大幅提升浏览效率和体验！</p><p><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2020/12/08/138b400000fae237a6318.png" style="box-sizing: border-box; border: 0px; display: inline-block; vertical-align: baseline; margin: 0px; padding: 0px; font: inherit; max-width: 100%;"></p><p>面对纷繁杂乱的素材，「智能文件夹」可实现自动分类。只需为素材添加标签、注释等属性，智能文件夹会自动按照预设的筛选条件，将素材添加到指定文件夹中，无惧海量素材的整理。</p><p><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2020/12/08/137c90001a78f3dc23d97.png" style="box-sizing: border-box; border: 0px; display: inline-block; vertical-align: baseline; margin: 0px; padding: 0px; font: inherit; max-width: 100%;"></p><h3>查找筛选事半功倍</h3><p>传统的基于文件夹查找素材的方式如同大海捞针，经常是事倍功半。Eagle 能够根据颜色、关键字、标签、类型、形状等筛选条件迅速找到素材！</p><p><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2020/12/08/fe3a0002adb9cc35f448.png" style="box-sizing: border-box; border: 0px; display: inline-block; vertical-align: baseline; margin: 0px; padding: 0px; font: inherit; max-width: 100%;"></p><p>Eagle 支持 macOS 和 Windows 系统，还能将资源库保存至云盘，在多台设备间同步收藏的素材！更可和团队成员一起收藏灵感素材，共同管理资源库！</p><h3>常见Q&amp;A</h3><h4>一、我想要在多台设备中同步 Eagle 收藏的内容，我该怎么做？</h4><p>目前你有两种方式可以达成：</p><p>1. 使用具有同步功能的云盘服务：Eagle 支持 Google Drive、Dropbox、iCloud、Resilio Sync、坚果云等各种支持文件同步的云端服务，只需将 Eagle 资源库本地文件夹放入同步服务的本地文件夹中，你在 Eagle 收藏的内容就可以在多台设备中进行同步了；</p><p>2. 将资料存放于便携式储存设备（如 USB 硬盘）：如果不借助网络，你也可使用 USB 设备来达到同样的效果，你只需要将 Eagle 的资源库文件夹存放在 USB 设备中，随身携带即可。</p><p>你可以点击 Eagle 菜单栏「资源库 &gt; 载入其他资源库」选项，找到存放于 USB 设备中的 Eagle 资源库内容。</p><h4>二、为什么浏览器插件一直说我没有开启 Eagle App？</h4><p>请确认你已启动 Eagle 软件。如已启动，还是无法解决该问题，你可以尝试：</p><p>1.重新启动 Eagle；</p><p>2.检查电脑是否开启了科学上网软件，如果是，将代理模式切换到「自动代理模式」或直接关闭代理工具。</p><h4>三、我想要把序列号移转至其他设备，我该怎么处理呢？</h4><p>你可在取消绑定的设备中点击菜单栏「Eagle &gt; 移除注册状态」将设备移除，接着在新设备重新注册软件即可。</p><h4>四、我的电脑遗失或损坏，请问我的序列号可以移转至其他电脑上继续使用吗？</h4><p>可以，你不需要担心因為设备损坏或丟失导致产品序列号无法使用，你可以在新的设备中，将不需要的设备解除绑定状态。</p><p><img src="https://img11.360buyimg.com/ddimg/jfs/t1/210065/23/4928/120398/61654b3bE9cbab2b0/c33bd46d8d6f1d6f.png"></p><p>以上为官网的文档说明，你可以访问以下链接，前往 Eagle 官方网站查看&nbsp;</p><p><a href="https://docs-cn.eagle.cool/article/567-can-i-buy-the-serial-number-on-taobao" target="_blank" textvalue="https://docs-cn.eagle.cool/article/567-can-i-buy-the-serial-number-on-taobao">https://docs-cn.eagle.cool/article/567-can-i-buy-the-serial-number-on-taobao</a></p><h3>购买链接<br></h3><p><a href="https://store.lizhi.io/site/products/id/38/cid/tkdempuy" target="_blank" textvalue="https://store.lizhi.io/site/products/id/38/cid/tkdempuy">https://store.lizhi.io/site/products/id/38/cid/tkdempuy</a></p>', NULL, '2019-12-03 01:01:33.019531+08', '2022-05-07 21:38:49.929535+08', 'f', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, 'eagle,数码荔枝', 2, 0, 6.91764705882353, 10493, '103.117.103.107', 'f', 'f', 0, NULL, NULL, 't', 0, 't', NULL, NULL, NULL, NULL);
INSERT INTO "public"."Post" VALUES (2134, 5, 'Wise Care 365 Pro正版 —— 电脑系统智慧清理加速工具', '懒得勤快', '<p><img class="alignnone size-full wp-image-16124" src="https://www.lizhi.io/wp-content/uploads/2020/03/Wise-Care-365-Pro-商品简介-01-20200310.jpeg" width="1500"> <img class="alignnone size-full wp-image-16125" src="https://www.lizhi.io/wp-content/uploads/2020/03/Wise-Care-365-Pro-商品简介-02-20200310.jpeg" width="1500"> <img class="alignnone size-full wp-image-16126" src="https://www.lizhi.io/wp-content/uploads/2020/03/Wise-Care-365-Pro-商品简介-03-20200310.jpeg" width="1500"> <img class="alignnone size-full wp-image-16127" src="https://www.lizhi.io/wp-content/uploads/2020/03/Wise-Care-365-Pro-商品简介-04-20200310.jpeg" width="1500"></p><p>Wise Care 365 Pro 是一款 Windows 系统上的提高电脑性能释放磁盘空间的优化工具。清理注册表和磁盘垃圾文件，保护个人隐私记录，提高电脑使用安全。为你搭建提高 Windows 电脑速度的安全、稳定的解决方案。</p><h3>深度清理</h3><p>Wise Care 365 Pro 可以清理无效的注册表项、快捷方式，还可将临时文件、浏览记录、下载记录、缓存、密码以及 Windows 组件等无用数据进行清除。软件还为高级用户提供了可定制的清理选项。</p><h3>性能优化</h3><p>软件通过系统优化 、磁盘碎片整理、Windows 注册表整理和管理启动项里的进程与服务等对电脑进行全方面的优化。对磁盘和注册表进行碎片整理，提高其运行速度。软件还能禁用掉不需要开机启动的程序，从而避免它们消耗过多系统资源，并以此提高电脑的启动速度。</p><h3>隐私安全保护</h3><p>Wise Care 365 Pro 里的隐私擦除、磁盘擦除和文件粉碎工具可以保护用户隐私不被盗取。隐私擦除可以删除电脑操作痕迹，如浏览历史和访问的文件；磁盘擦除功能可防止第三方恢复已删除的数据；文件粉碎功能可以彻底删除文件，防止恢复。</p><h3>系统保护</h3><p>实时保护注册表不被其他程序未经许可修改。例如阻止程序更改浏览器主页，阻止任何不需要的新应用程序添加到 Windows 启动项，阻止其他程序更改默认浏览器等。</p><h3>系统硬件监控</h3><p>系统监视可以显示电脑的所有基本信息。进程监视可以提供清晰的进程列表，列出当前用户和系统运行的所有进程，可以关闭不需要的进程，使电脑运行更流畅。硬件概述也能提供所有关键硬件组件的详细信息，让你对自己的电脑一目了然。</p><h3>购买正版</h3><p><a href="https://store.lizhi.io/site/products/id/300/cid/tkdempuy" target="_blank" textvalue="https://store.lizhi.io/site/products/id/300/cid/tkdempuy">https://store.lizhi.io/site/products/id/300/cid/tkdempuy</a></p>', NULL, '2022-04-13 19:09:37.011031+08', '2022-04-13 19:09:37.011032+08', 'f', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, 'WiseCare365', 0, 0, 6.945945945945946, 256, '103.117.103.109', 'f', 'f', 0, NULL, NULL, 't', 0, 'f', NULL, NULL, NULL, NULL);
INSERT INTO "public"."Post" VALUES (1680, 5, '官方正版特价！Internet Download Manager IDM 下载神器', '懒得勤快', '<p style="text-align: center;"><img src="https://img10.360buyimg.com/ddimg/jfs/t1/88395/30/19490/67925/6145aee3E63324163/fc5dae78f26f2a1f.png"></p><p>Internet Download Manager IDM 下载器是一款先进的下载工具,可以提升您的下载速度高达5倍,支持续传，IDM 可以让用户自动下载某些类型的文件，它可将文件划分为多个下载点以更快速度下载，并列出最近的下载，方便访问文件。<br></p><p>IDM 的优势在于可以利用多线程技术极大地提高文件下载速度，即便是特别大的文件也可以轻松的快速整合。当然下载速度具体能达到多少取决于你的带宽和服务器的带宽。</p><figure><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/20191125/s9b8kgoujbpc.png"></figure><h3>多个浏览器支持：</h3><p>IDM 支持所有主流浏览器包括谷歌浏览器、火狐浏览器以及微软家系列的 IE 和 Microsoft EDGE浏览器等等。</p><p>对于不支持的浏览器用户也可以在 IDM 设置的浏览器集成里手动设置，完成后即可接管各浏览器的任务下载。</p><p>同时IDM也可以用来识别视频网站中的链接，嗅探完成即可直接使用IDM将对应的视频文件下载到本地保存。</p><figure><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/20191125/s9b8klkewem8.jpg"></figure><h3>IDM 功能介绍：</h3><ul style="list-style-type: square;" class=" list-paddingleft-2"><li><p>下载提速5倍</p></li></ul><p>IDM 可提升您的下载速度高达 5 倍！</p><ul style="list-style-type: square;" class=" list-paddingleft-2"><li><p>浏览器兼容</p></li></ul><p>支持多款浏览器，包括 IE，Safari，谷歌浏览器，火狐，Opera，并用通过自带的添加浏览器功能可以支持所有浏览器。</p><ul style="list-style-type: square;" class=" list-paddingleft-2"><li><p>in-speed 技术</p></li></ul><p>智能的 in-speed 技术会动态地将所有设定应用到某种联机类型，以充分利用下载速度。</p><ul style="list-style-type: square;" class=" list-paddingleft-2"><li><p>7*24 服务</p></li></ul><p>7*24 小时为您提供全方位售后服务，若您在使用过程中遇到任何无法解决的问题时，请您及时联系我们。</p><ul style="list-style-type: square;" class=" list-paddingleft-2"><li><p>密钥找回</p></li></ul><p><a href="http://www.internetdownloadmanager.com/retrieve_registration.html">http://www.internetdownloadmanager.com/retrieve_registration.html</a></p><h3>购买地址<br></h3><p>官方正版 Internet Download Manager IDM 下载器软件 （终身版）原价：175元，现券后价：只需要 109元！<span style="color: rgb(255, 0, 0);">新用户注册还能再领取5元优惠券！</span></p><p><a href="https://store.lizhi.io/site/products/id/325?cid=tkdempuy" target="_blank" textvalue="https://store.lizhi.io/site/products/id/325?cid=tkdempuy">https://store.lizhi.io/site/products/id/325?cid=tkdempuy</a></p>', NULL, '2019-11-26 01:45:12.904164+08', '2022-04-22 02:27:57.288381+08', 'f', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', '正版', 'idm,InternetDownloadManager', 8, 0, 49.97979797979798, 26178, '203.186.250.143', 'f', 'f', 0, NULL, NULL, 't', 0, 't', NULL, NULL, NULL, NULL);
INSERT INTO "public"."Post" VALUES (2048, 5, 'ASTER - 不用安装虚拟机，电脑分身主机共享 PC拖机软件一拖二，硬件资源零浪费', '懒得勤快', '<p style="text-align: center;"><img src="/static/images/2021/08/12/connections_1013.png"></p><p>不知道大家有没有遇到过类似的情况，自己正在用电脑赶工作进度，小孩过来又要争电脑上网课。或是自己正在玩游戏，想拉女朋友一块来开黑……总结下来就是：一台电脑很紧张，又没有必要多买一台来吃灰。有没有一种可能，让两个人同时用一台？</p><p>虚拟机、双系统、双屏幕拓展？看似有用却仍没办法解决两人同时操作的需求。ASTER&nbsp;这款拖机软件或许让你眼前一亮！</p><h3>电脑分身一个变俩</h3><p>一般情况下，在一台主机上连接两个显示器，可以选择复制或拓展两种方案。</p><p><img class="alignnone size-full wp-image-19854" src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2021/08/12/01_1002.png"></p><p>虽然有两个显示器，但效果仅仅是多了一个「显示」区域，没有办法让两个人同时操作电脑，同时键盘输入或鼠标操作根本不可能。ASTER&nbsp;用纯软件实现电脑分身，一台主机两人同时使用。添置一套键鼠、一台显示器，就能多出来一台电脑。</p><p><img src="https://img12.360buyimg.com/ddimg/jfs/t1/186383/7/18003/868610/6114b0bdE7a7824ca/1f2c707984efaa45.png"></p><p>一边码字办公，另一边打游戏互不影响，两套键鼠各用各的，再也不用两人抢电脑用了！而且，相比配备一套新主机，ASTER 更划算~</p><p>在电脑系统多添加一个用户，不同终端登录不同账号，彼此之间更少干扰！</p><p><img class="alignnone size-full wp-image-19856" src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2021/08/12/03_1002.png"></p><h3>设备分配很简单</h3><p>键盘、鼠标、音响都插了两套，是不是一时间很难分辨？ASTER 让这件事变得简单。当点击鼠标或敲击键盘时，在软件内就可以看到对应的图标在闪烁提示。</p><p>音响和麦克风也是同样的道理，当使用该设备时播放或讲话时，软件内对应的图标就会闪烁。是不是非常简单。直接拖拽图标到相应的终端，完成设备分配。</p><p><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2021/08/12/分配键鼠_1004.gif"></p><h3>使用流畅超稳定</h3><p>系统资源动态分配，稳定地执行基于 Win 10 / 8 / 7 / XP 系统的应用程序，分身电脑和原来主机性能一样优良。纯软件实现，无需增加主机硬件就能轻松完成，另外支持手动设置 CPU 核心分配。</p><p><img class="alignnone size-full wp-image-19858" src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2021/08/12/05_1002.png"></p><p>分身电脑可同时开启 3D 硬件加速，在硬件资源够用的前提下，可供两人同时流畅游戏，和单机时游戏体验差异不大。</p><p><img class="alignnone size-full wp-image-19859" src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2021/08/12/06_1002.png"></p><h3>省钱省地更划算</h3><p>对于一台电脑来说，主板、硬盘、CPU、内存这些硬件在整体购机费用中占了不少的比重，需要上千元不止。相比之下仅需二百多元的 ASTER 拖机软件，就能为你省下上千元的主机费用，是不是很划算~</p><p><img class="alignnone size-full wp-image-19860" src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2021/08/12/07_1002.jpg"></p><p>和虚拟机不同，分身出来的电脑和原主机共用一个操作系统，还能共享大部分软件。Adobe 系列、Office 软件等软件，两边同时使用互不影响，帮你省下一笔购买软件的费用。有些软件可以直接双开，有些 (如 Steam) 需要以沙盒的方式开启，具体可以咨询客服解决~</p><p>当然，两人共用一台主机，还能省电费和占地，无论是家庭共享，还是企业装机、学校机房，都是一个不错的方案。这样一款拖机软件，想不想试一下呢？帮你省下一笔购机费用~</p><h3>购买地址</h3><p><a href="https://store.lizhi.io/site/products/id/484/cid/tkdempuy" target="_blank" textvalue="https://store.lizhi.io/site/products/id/484/cid/tkdempuy">https://store.lizhi.io/site/products/id/484/cid/tkdempuy</a></p><p><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2021/08/12/ASTER_qrcode_1009.jpg"></p>', NULL, '2021-08-12 18:11:03.433045+08', '2022-05-12 21:09:10.153232+08', 'f', 45, 'admin@masuit.com', '懒得勤快', 'admin@masuit.com', NULL, NULL, 7, 1, 15.707070707070708, 7972, '103.117.103.110', 'f', 'f', 0, NULL, NULL, 't', 0, 't', NULL, NULL, NULL, NULL);

-- ----------------------------
-- Table structure for PostHistoryVersion
-- ----------------------------
DROP TABLE IF EXISTS "public"."PostHistoryVersion";
CREATE TABLE "public"."PostHistoryVersion" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Title" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "Content" text COLLATE "pg_catalog"."default" NOT NULL,
  "ProtectContent" text COLLATE "pg_catalog"."default",
  "ViewCount" int4 NOT NULL,
  "ModifyDate" timestamptz(6) NOT NULL,
  "CategoryId" int4 NOT NULL,
  "PostId" int4 NOT NULL,
  "Email" varchar(255) COLLATE "pg_catalog"."default",
  "Label" varchar(255) COLLATE "pg_catalog"."default",
  "Modifier" varchar(128) COLLATE "pg_catalog"."default",
  "ModifierEmail" varchar(64) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of PostHistoryVersion
-- ----------------------------

-- ----------------------------
-- Table structure for PostMergeRequest
-- ----------------------------
DROP TABLE IF EXISTS "public"."PostMergeRequest";
CREATE TABLE "public"."PostMergeRequest" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "PostId" int4 NOT NULL,
  "Title" varchar(256) COLLATE "pg_catalog"."default",
  "Content" text COLLATE "pg_catalog"."default",
  "Modifier" varchar(64) COLLATE "pg_catalog"."default",
  "ModifierEmail" varchar(64) COLLATE "pg_catalog"."default",
  "MergeState" int4 NOT NULL,
  "Status" int4 NOT NULL,
  "SubmitTime" timestamptz(6) NOT NULL,
  "IP" varchar(128) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of PostMergeRequest
-- ----------------------------

-- ----------------------------
-- Table structure for PostTag
-- ----------------------------
DROP TABLE IF EXISTS "public"."PostTag";
CREATE TABLE "public"."PostTag" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE
),
  "Name" varchar(255) COLLATE "pg_catalog"."default" NOT NULL,
  "Count" int4 NOT NULL DEFAULT 0,
  "Status" int4 NOT NULL DEFAULT 0
)
;

-- ----------------------------
-- Records of PostTag
-- ----------------------------

-- ----------------------------
-- Table structure for PostVisitRecord
-- ----------------------------
DROP TABLE IF EXISTS "public"."PostVisitRecord";
CREATE TABLE "public"."PostVisitRecord" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE
),
  "Referer" varchar(4096) COLLATE "pg_catalog"."default",
  "IP" varchar(128) COLLATE "pg_catalog"."default",
  "Time" timestamptz(6) NOT NULL,
  "PostId" int4 NOT NULL,
  "Status" int4 NOT NULL,
  "Location" text COLLATE "pg_catalog"."default",
  "RequestUrl" text COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of PostVisitRecord
-- ----------------------------

-- ----------------------------
-- Table structure for PostVisitRecordStats
-- ----------------------------
DROP TABLE IF EXISTS "public"."PostVisitRecordStats";
CREATE TABLE "public"."PostVisitRecordStats" (
  "Id" int4 NOT NULL GENERATED ALWAYS AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE
),
  "PostId" int4 NOT NULL,
  "Date" timestamp(6) NOT NULL,
  "Count" int4 NOT NULL,
  "Status" int4 NOT NULL
)
;

-- ----------------------------
-- Records of PostVisitRecordStats
-- ----------------------------

-- ----------------------------
-- Table structure for RequestLogDetail
-- ----------------------------
DROP TABLE IF EXISTS "public"."RequestLogDetail";
CREATE TABLE "public"."RequestLogDetail" (
  "Time" timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "UserAgent" varchar(1024) COLLATE "pg_catalog"."default",
  "RequestUrl" varchar(4096) COLLATE "pg_catalog"."default" NOT NULL,
  "IP" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "Location" varchar(256) COLLATE "pg_catalog"."default",
  "Network" varchar(256) COLLATE "pg_catalog"."default",
  "Id" varchar(32) COLLATE "pg_catalog"."default" NOT NULL,
  "TraceId" varchar(128) COLLATE "pg_catalog"."default",
  "Country" varchar(255) COLLATE "pg_catalog"."default",
  "City" varchar(255) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of RequestLogDetail
-- ----------------------------

-- ----------------------------
-- Table structure for SearchDetails
-- ----------------------------
DROP TABLE IF EXISTS "public"."SearchDetails";
CREATE TABLE "public"."SearchDetails" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
CYCLE
),
  "Keywords" varchar(256) COLLATE "pg_catalog"."default" NOT NULL,
  "SearchTime" timestamptz(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "IP" varchar(128) COLLATE "pg_catalog"."default",
  "Elapsed" float8 NOT NULL DEFAULT 0
)
;

-- ----------------------------
-- Records of SearchDetails
-- ----------------------------

-- ----------------------------
-- Table structure for Seminar
-- ----------------------------
DROP TABLE IF EXISTS "public"."Seminar";
CREATE TABLE "public"."Seminar" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Title" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "SubTitle" varchar(512) COLLATE "pg_catalog"."default",
  "Description" varchar(4096) COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of Seminar
-- ----------------------------
INSERT INTO "public"."Seminar" VALUES (1, 0, '国际网络加速', '链接世界，畅游国际网络', '拒绝404，给自己的网络加个速吧。');
INSERT INTO "public"."Seminar" VALUES (2, 0, '开源项目', '博主开源项目', '博主自主研发的开源项目，本专题搜集与开源项目有关的文章和资源');
INSERT INTO "public"."Seminar" VALUES (4, 0, '生产力工具', '工欲善其事，必先利其器', '所谓工欲善其事，必先利其器，尽管我们的生产力还是很强大了，但是有了他们，会有你意想不到的收获！');
INSERT INTO "public"."Seminar" VALUES (5, 0, '资源中心', '编程爱好者资源', '各大编程语言学习视频，C#、Java、php、go、web前端、UI设计、SEO等相关学习视频应有尽有！');
INSERT INTO "public"."Seminar" VALUES (6, 0, '稀缺资源', '互联网上重金难求的被和谐资源，这里不收费', '互联网上仅存的稀缺资源，不收取任何费用，仅用于个人研究和使用，发扬互联网分享精神，专注收藏与分享。');
INSERT INTO "public"."Seminar" VALUES (7, 0, 'jetbrains资源', 'jetbrains全系列资源', '集前后端及各种开发语言的开发神器全家桶');

-- ----------------------------
-- Table structure for SeminarPost
-- ----------------------------
DROP TABLE IF EXISTS "public"."SeminarPost";
CREATE TABLE "public"."SeminarPost" (
  "SeminarId" int4 NOT NULL,
  "PostId" int4 NOT NULL
)
;

-- ----------------------------
-- Records of SeminarPost
-- ----------------------------

-- ----------------------------
-- Table structure for SeminarPostHistoryVersion
-- ----------------------------
DROP TABLE IF EXISTS "public"."SeminarPostHistoryVersion";
CREATE TABLE "public"."SeminarPostHistoryVersion" (
  "SeminarId" int4 NOT NULL,
  "PostHistoryVersionId" int4 NOT NULL
)
;

-- ----------------------------
-- Records of SeminarPostHistoryVersion
-- ----------------------------

-- ----------------------------
-- Table structure for SystemSetting
-- ----------------------------
DROP TABLE IF EXISTS "public"."SystemSetting";
CREATE TABLE "public"."SystemSetting" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Name" varchar(64) COLLATE "pg_catalog"."default" NOT NULL,
  "Value" text COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of SystemSetting
-- ----------------------------
INSERT INTO "public"."SystemSetting" VALUES (2, 1, 'logo', 'https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/20190606/5dc7fc1266bfd8109d1ef5e0e7630f2c_2_3_art.png');
INSERT INTO "public"."SystemSetting" VALUES (3, 1, 'Title', '懒得勤快的博客_互联网分享精神');
INSERT INTO "public"."SystemSetting" VALUES (4, 1, 'Brand', '懒得勤快，互联网分享精神，勤于发现，乐于分享');
INSERT INTO "public"."SystemSetting" VALUES (5, 1, 'EmailFrom', 'admin@mail.masuit.com');
INSERT INTO "public"."SystemSetting" VALUES (6, 1, 'EmailPwd', '80f19dfa3db6cfdaa7a75c46ad0ec3d8-cb3791c4-1dbf94f7');
INSERT INTO "public"."SystemSetting" VALUES (7, 1, 'SMTP', 'smtp.mailgun.org');
INSERT INTO "public"."SystemSetting" VALUES (8, 1, 'ReceiveEmail', 'admin@masuit.com');
INSERT INTO "public"."SystemSetting" VALUES (9, 1, 'Slogan', '懒得勤快，互联网分享精神，勤于发现，乐于分享');
INSERT INTO "public"."SystemSetting" VALUES (10, 1, 'Keyword', '懒得勤快,绿色软件,DIY显示器,稀缺资源,Resharper 破解,M250HAN03.2,科学上网,秀人网,新日暮里');
INSERT INTO "public"."SystemSetting" VALUES (11, 1, 'Description', '若页面无法访问，可通过搜索引擎网页快照进行浏览。懒得勤快，互联网分享精神，勤于发现，乐于分享，稀缺软件分享，视频教程分享，各种优质资源分享，新日暮里哲学文化传媒，正版软件下载！');
INSERT INTO "public"."SystemSetting" VALUES (12, 1, 'Donate', '/ldqk/imgbed/raw/master/20190810/微信图片_20190810204128.png');
INSERT INTO "public"."SystemSetting" VALUES (13, 1, 'Copyright', '<hr class="margin-clear"/><p style="text-align: left;">切换网站语言：<a href="/lang/zh-cn" target="_self" textvalue="简体中文">简体中文</a>&nbsp;/&nbsp;<a href="/lang/zh-tw" target="_self" textvalue="正體中文">正體中文</a>；安全模式：<button class="btn btn-xs btn-info" onclick="enableDefaultSafeMode();alert(&#39;开启成功&#39;)">开启默认安全模式</button>/<button class="btn btn-xs btn-danger" onclick="clearBlockedCategory()">关闭安全模式</button>；联系站长：<a href="https://github.com/ldqk" target="_blank">GitHub</a>&nbsp;|&nbsp;<a href="https://t.me/ldqk0" target="_blank">Telegram</a>&nbsp;|&nbsp;<a href="https://t.me/+DztfcKpvpXFjZGZl" target="_blank" textvalue="Telegram群组">Telegram群组</a>&nbsp;| <a href="https://t.me/ldqk2" target="_blank">Telegram官方频道</a> | <a target="_blank" href="https://mail.qq.com/cgi-bin/qm_share?t=qm_mailme&email=admin@masuit.com" style="text-decoration-line: none;">电子邮箱</a></p><p>新日暮里♂娼片公司™旗下网站，本站由&nbsp;<a href="https://dotnet.microsoft.com/download/dotnet/6.0" target="_blank" textvalue=".NET 6.0">.NET 6.0</a>&nbsp;强力驱动！本站源代码：<a href="https://github.com/ldqk/Masuit.MyBlogs" target="_blank" style="white-space: normal;">github</a>&nbsp;| Copyright@懒得勤快 保留所有权利 | Powered&amp;Developed by 懒得勤快；</p><p>法务支持与联系：comments@whitehouse.gov |&nbsp;Hosting by Sia Nano IT in Latvia Riga，受当地法律保护！<a href="/disclaimer" target="_self" textvalue="免责声明">免责声明</a>&nbsp;|&nbsp;<a href="/misc/10" target="_blank">DMCA</a>&nbsp;|&nbsp;<a href="/misc/11" target="_blank" textvalue="隐私政策">隐私政策</a></p>');
INSERT INTO "public"."SystemSetting" VALUES (14, 1, 'ReservedName', '懒得勤快|system|admin|Administrator|root');
INSERT INTO "public"."SystemSetting" VALUES (15, 1, 'Disclaimer', '<p>● 下载遇到问题，请先阅读下载页页脚的说明或从<a href="/notice" target="_blank">网站公告</a>中查找解决方案！如遇资源报毒，请参阅：<a href="/misc/14" target="_blank" textvalue="https://masuit.com/misc/14">https://masuit.org/misc/14</a></p><p><span style="color: rgb(255, 0, 0);">● 文章内容仅供参考，所涉及的软件以具体使用情况为准！</span></p><p><span style="color: rgb(255, 0, 0);">● 博主在此发文（包括但不限于汉字、拼音、拉丁字母）均为随意敲击键盘所出，用于检验本人电脑键盘录入、屏幕显示的机械、光电性能，并不代表本人局部或全部同意、支持或者反对观点。如需要详查请直接与键盘生产厂商法人代表联系。挖井挑水无水表，不会网购无快递。<br/></span></p><p><span style="color: rgb(255, 0, 0);">● 博主的文章没有高度、深度和广度，只是凑字数。由于博主的水平不高（其实是个菜B），不足和错误之处在所难免，希望大家能够批评指出。</span></p><p><span style="color: rgb(255, 0, 0);">● 博主是利用读书、参考、引用、抄袭、复制和粘贴等多种方式打造成自己的纯镀 24k 文章，请原谅博主成为一个无耻的文档搬运工！</span></p><p><span style="color: rgb(255, 0, 0);">● 文章内容部分来源于互联网，本站不代表任何立场；<strong>涉及到的软件来源于互联网，仅供个人学习参考，请勿用于商业用途，版权归软件开发者所有，下载后请务必于24小时内删除，请支持正版！</strong>因下载本站任何资源造成的损失，全部责任由使用者本人承担！如果你是版权方，认为本文内容对您的权益有所侵犯，请联系本站管理员，并参照侵删联系的说明提交相应的证明材料，本站将进行严格地资质审查和背景调查后，情况属实的将在三天内对本文删除或修正。本站对互联网版权绝对支持！</span></p><p><span style="color: rgb(255, 0, 0);">● 本站一贯非常高度重视知识产权保护并遵守各项知识产权法律、法规和具有约束力的规范性文件。重视正版，打击盗版。根据法律、法规和规范性文件要求，本站旨在保护权利人的合法权益的措施和步骤，当权利人发现在本站生成的链接所指向的第三方网页的内容侵犯其合法权益时，权利人应事先向本站发出&quot;权利通知&quot;，本站将根据当地法律法规和政府规范性文件采取措施移除相关内容或链接。&nbsp;</span></p><p><span style="color: rgb(255, 0, 0);">● 访问本站的用户必须明白，本站对提供下载的第三方软件不拥有任何权利，其版权归该资源的合法拥有者所有。</span></p><p><span style="color: rgb(255, 0, 0);">● 本站保证站内提供的所有可下载资源（软件等）都是按“原样”提供，本站未做过任何改动；但本网站不保证本站提供的下载资源的准确性、安全性和完整性；同时本站也不承担用户因使用这些下载资源对自己和他人造成任何形式的损失或伤害。不论何种情形我们都不对任何由于使用或无法使用本站提供的信息所造成的直接的、间接的、附带的、特殊的或余波所及的损失、灵失、债务或中断负任何责任﹝不论是可预见或是不可预见的，即使我们巳被告知这种可能性﹞。</span></p>');
INSERT INTO "public"."SystemSetting" VALUES (16, 1, 'SmtpPort', '587');
INSERT INTO "public"."SystemSetting" VALUES (17, 1, 'DonateWechat', '/ldqk/imgbed/raw/master/2018/2/5ccadc6b53f28.jpg');
INSERT INTO "public"."SystemSetting" VALUES (18, 1, 'DonateQQ', '/ldqk/imgbed/raw/master/2018/2/5ccadc6c9aa5b.jpg');
INSERT INTO "public"."SystemSetting" VALUES (19, 1, 'PathRoot', '/');
INSERT INTO "public"."SystemSetting" VALUES (20, 1, 'Domain', 'masuit.com|ldqk.org|ldqk.xyz|masuit.tk|ldqk.tk|masuit.org');
INSERT INTO "public"."SystemSetting" VALUES (22, 1, 'DisabledEmailBroadcast', 'true');
INSERT INTO "public"."SystemSetting" VALUES (23, 1, 'DisabledEmailBroadcastTip', '由于本站用的是免费的SMTP服务器，现在本站订阅人数过多，导致邮件无法正常发送，因此邮件订阅功能暂停使用！如果你有好用的免费的SMTP服务器推荐，欢迎联系博主！');
INSERT INTO "public"."SystemSetting" VALUES (24, 1, 'EnableDenyArea', 'true');
INSERT INTO "public"."SystemSetting" VALUES (25, 1, 'DenyArea', '阿里,腾讯,数据,Alibaba,Tencent');
INSERT INTO "public"."SystemSetting" VALUES (26, 1, 'Scripts', '<script async src="https://www.googletagmanager.com/gtag/js?id=UA-172909745-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag(''js'', new Date());

  gtag(''config'', ''UA-172909745-1'');
</script>

<script src="https://cdn.staticfile.org/jquery-cookie/1.4.1/jquery.cookie.min.js"></script>
<script>
$(function() {
    window.fetch("/forge").then(function(response) {
        return response.json();
    }).then(function(data) {
        $.cookie("rawip",btoa(data.ip));
    });
    //  默认安全模式
    enableDefaultSafeMode();
    cookieStore.get("HideCategories").then(res=>{
        var value=(res||{value:""}).value;
        if(value!=""&&value!="null"&&localStorage.getItem("DefaultSafeMode")==1){
            $("body").append("<a style=''position:fixed;left:0;bottom:0;color:black;z-index:10;text-shadow: 0px 0px 1px #000;''>安全模式</a>");
        }
    })
});
</script>');
INSERT INTO "public"."SystemSetting" VALUES (27, 1, 'LimitIPFrequency', '60');
INSERT INTO "public"."SystemSetting" VALUES (28, 1, 'LimitIPRequestTimes', '300');
INSERT INTO "public"."SystemSetting" VALUES (29, 1, 'BanIPTimespan', '1');
INSERT INTO "public"."SystemSetting" VALUES (30, 1, 'FirewallEnabled', 'true');
INSERT INTO "public"."SystemSetting" VALUES (31, 1, 'Styles', '');
INSERT INTO "public"."SystemSetting" VALUES (32, 1, 'Watermark', '');
INSERT INTO "public"."SystemSetting" VALUES (33, 1, 'DataReadonly', 'false');
INSERT INTO "public"."SystemSetting" VALUES (34, 1, 'UserAgentBlocked', '');
INSERT INTO "public"."SystemSetting" VALUES (35, 1, 'UserAgentBlockedMsg', '<!DOCTYPE html> <html><head> <meta charset="utf-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"> <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> <title>403</title> </head> <body> <h2>当前浏览器({{browser}})或操作系统({{os}})不支持访问本站，请尝试更换其他浏览器访问本站，如果您当前正在QQ或微信内置浏览器中访问，请点击右上角，在浏览器中访问即可！</h2> </body> </html>');
INSERT INTO "public"."SystemSetting" VALUES (36, 1, 'AccessDenyTips', '<h4>遇到了什么问题？</h4>
<h4>您可能根据搜索引擎找到了这个页面，但是很抱歉：基于主观因素考虑，您所在的地区本站尚未开放访问权限！</h4>
<h4>或者您可能使用了VPN或其他的代理软件在访问本站，若是如此，请关掉您的VPN或代理或将本站域名加入您的代理跳过规则后即可正常访问本站！</h4>');
INSERT INTO "public"."SystemSetting" VALUES (37, 1, 'DonateHtml', '<div class="container"><p class="text-red size20">如果你现在正好需要一台显示器，可以到我们的<a href="https://shop123472283.taobao.com/" target="_blank">淘宝店铺</a>进行选购以表支持本站发展。</p><p class="text-red size20">或者可以点击本站任意形式的广告链接，购买正版软件或服务以表示对本站的支持！</p><!--<p class="margintop20"><img src="https://ae01.alicdn.com/kf/H9c0ef439b7ae4a5ba4151456f3c5f0a2N.jpg" alt="懒得勤快的博客_互联网分享精神"/></p>--><p><img src="https://ae01.alicdn.com/kf/H85230da1c344482c90ad38046159c750f.jpg" alt="懒得勤快的博客_互联网分享精神"/></p><p>钱包地址：</p><p>BTC：1EBaXHTvrsXaTGtqdLn5HGW71E7XquRj28</p><p>ETH：0x7ed2f49717b82b1418e4e27a510001f9d9dd2f52</p><p>USDT：1EBaXHTvrsXaTGtqdLn5HGW71E7XquRj28</p><div class="text-green size20 margintop20" style="line-height: 26px;"><p>本网站由博主一个人打造，开发和运营均为博主本人，如果您是真心喜欢本博客，您可以对博主表示一下感谢，以支持后期发布更多好资源，5毛也好、1元也罢，都是你们的心意。网站运营也需要成本，有你的援助，一切会更好。</p><p class="text-red size20">打赏时最好能够附上你的完整信息，包括：您的昵称或真名、邮箱地址、QQ或微信、金额等；因为不能保证能够完全的清楚打赏者的基本信息，如果你完成了打赏，推荐你在网站留言板备注一下，或者QQ私信告知你是谁。</p><p>您可以尽您所能地打赏，如果您临时改变主意，您可以在事后一个月之内联系作者申请退款！</p><p>本站的宗旨是：互联网分享精神，乐于发现，勤于分享；</p><p>我希望的：您将我的网站告诉你的朋友，让更多的人来这里学习，共同进步。</p></div></div>');
INSERT INTO "public"."SystemSetting" VALUES (38, 1, 'UploadPath', '/static');
INSERT INTO "public"."SystemSetting" VALUES (39, 1, 'EnableSsl', 'true');
INSERT INTO "public"."SystemSetting" VALUES (40, 1, 'LimitIPInterceptTimes', '40');
INSERT INTO "public"."SystemSetting" VALUES (41, 1, 'EnableDonate', 'false');
INSERT INTO "public"."SystemSetting" VALUES (42, 1, 'ChallengeMode', 'JSChallenge');
INSERT INTO "public"."SystemSetting" VALUES (43, 1, 'AllowedArea', 'Telegram Messenger,AS132892');
INSERT INTO "public"."SystemSetting" VALUES (44, 1, 'CloseSite', 'false');
INSERT INTO "public"."SystemSetting" VALUES (45, 1, 'EnableRss', 'true');

-- ----------------------------
-- Table structure for UserInfo
-- ----------------------------
DROP TABLE IF EXISTS "public"."UserInfo";
CREATE TABLE "public"."UserInfo" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Status" int4 NOT NULL,
  "Username" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "NickName" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "Password" varchar(4096) COLLATE "pg_catalog"."default" NOT NULL,
  "SaltKey" varchar(4096) COLLATE "pg_catalog"."default" NOT NULL,
  "IsAdmin" bool NOT NULL,
  "Email" varchar(64) COLLATE "pg_catalog"."default",
  "QQorWechat" varchar(64) COLLATE "pg_catalog"."default",
  "Avatar" varchar(255) COLLATE "pg_catalog"."default"
)
;

-- ----------------------------
-- Records of UserInfo
-- ----------------------------
INSERT INTO "public"."UserInfo" VALUES (1, 0, 'masuit', '懒得勤快', '84e1338d260a7aedd8232df7f02de1f4', '3s+c1wnhqZO96G5Wh/R3W0XrOWHLntiX23XZxKEcmDh9VfVJ06AHgtdgjMUrsE3B', 't', 'admin@masuit.com', 'admin@masuit.com', '/static/images/sr5356c7shs0.png');

-- ----------------------------
-- Table structure for Variables
-- ----------------------------
DROP TABLE IF EXISTS "public"."Variables";
CREATE TABLE "public"."Variables" (
  "Id" int4 NOT NULL GENERATED BY DEFAULT AS IDENTITY (
INCREMENT 1
MINVALUE  1
MAXVALUE 2147483647
START 1
CACHE 1
),
  "Key" varchar(128) COLLATE "pg_catalog"."default" NOT NULL,
  "Value" text COLLATE "pg_catalog"."default" NOT NULL
)
;

-- ----------------------------
-- Records of Variables
-- ----------------------------
INSERT INTO "public"."Variables" VALUES (2, 'baidupan.net', '<h3>一些优质的.NET免费视频推荐：<br/></h3><p>杨中科：<a href="https://www.bilibili.com/video/BV1pK41137He" target="_blank" textvalue="https://www.bilibili.com/video/BV1pK41137He">https://www.bilibili.com/video/BV1pK41137He</a></p><p>朝夕教育：<a href="https://www.bilibili.com/video/BV147411x7p1" target="_blank" textvalue="https://www.bilibili.com/video/BV147411x7p1">https://www.bilibili.com/video/BV147411x7p1</a></p><p>杨旭草根专栏：<a href="https://space.bilibili.com/361469957/" target="_blank" textvalue="https://space.bilibili.com/361469957/">https://space.bilibili.com/361469957/</a></p>');
INSERT INTO "public"."Variables" VALUES (3, 'monitor', '<h3 style="white-space: normal;">相关科普</h3><table><colgroup><col width="72" style="width: 72px;"/><col width="91" style="width: 91px;"/><col width="133" style="width: 133px;"/><col width="112" style="width: 112px;"/><col width="132" style="width: 132px;"/><col width="131" style="width: 131px;"/><col width="159" style="width: 159px;"/></colgroup><tbody><tr height="24" class="firstRow" style="height: 24px;"><td height="24" rowspan="1" colspan="7" style="word-break: break-all; text-align: center;" width="629"><span style="font-size: 20px;"><strong>显卡接口输出带宽科普</strong></span></td></tr><tr height="24" style="height: 24px;"><td height="24" width="72" style="text-align: center;"><strong>接口</strong></td><td style="text-align: center;" width="42"><strong>接口版本</strong></td><td width="133" style="text-align: center;"><strong>最大传输速率</strong></td><td width="129" style="text-align: center;"><strong>1080P</strong></td><td width="125" style="text-align: center;"><strong>2K</strong></td><td width="121" style="text-align: center;"><strong>4K</strong></td><td width="244" style="text-align: center;"><strong>最高完美支持</strong></td></tr><tr height="38" style="height: 38px;"><td rowspan="2" height="95" style="text-align: center;">DP</td><td style="text-align: center;" width="42">1.2</td><td style="text-align: center;">21.6Gbps</td><td width="129" style="text-align: center; word-break: break-all;"><p>240Hz(完美)</p><p><span style="text-align: center;">370Hz(完美)</span></p></td><td width="125" style="word-break: break-all; text-align: center;">144Hz(完美)<br/>240Hz(422色彩)</td><td width="121" style="word-break: break-all; text-align: center;">60Hz(完美)<br/>120Hz(422色彩)</td><td width="85" style="text-align: center;">4K@60Hz 10bit RGB</td></tr><tr height="57" style="height: 57px;"><td height="57" style="text-align: center;">1.4</td><td style="text-align: center;" width="89">32.4Gbps</td><td style="text-align: center; word-break: break-all;"><p>240Hz(完美)</p><p><span style="text-align: center;">560Hz(完美)</span></p></td><td width="149" style="word-break: break-all; text-align: center;">144Hz(完美)<br/>240Hz(完美)</td><td width="124" style="word-break: break-all; text-align: center;">60Hz(完美)<br/>120Hz(完美)<br/>144Hz(完美)</td><td width="163" style="word-break: break-all; text-align: center;">4K@144Hz 10bit RGB(DSC模式)<br/>8K@30Hz 10bit RGB</td></tr><tr height="57" style="height: 57px;"><td rowspan="2" height="95" style="text-align: center;">HDMI</td><td style="text-align: center;" width="42">1.4</td><td style="text-align: center;">8.16Gbps</td><td width="129" style="word-break: break-all; text-align: center;">120Hz(完美)<br/>144Hz(看线材)<br/>240Hz(420色彩)</td><td width="125" style="word-break: break-all; text-align: center;">60Hz(完美)<br/>144Hz(420色彩)</td><td width="121" style="word-break: break-all; text-align: center;">30Hz(完美)<br/>60Hz(420色彩)</td><td width="85" style="text-align: center;">4K@30Hz 8bit RGB</td></tr><tr height="38" style="height: 38px;"><td height="38" style="text-align: center;">2.0</td><td style="text-align: center;" width="89">14.4Gbps</td><td style="text-align: center; word-break: break-all;"><p>240Hz(完美)</p><p>360Hz(420色彩)</p></td><td width="149" style="word-break: break-all; text-align: center;">144Hz(完美)<br/>240Hz(420色彩)</td><td width="124" style="word-break: break-all; text-align: center;">60Hz(完美)<br/>120Hz(420色彩)</td><td width="163" style="text-align: center;">4K@60Hz 8bit RGB</td></tr><tr height="19" style="height: 19px;"><td colspan="7" height="19" style="text-align: center;" width="629">带宽计算公式：总带宽(bps)=水平分辨率x垂直分辨率x刷新率x色彩通道数x色深</td></tr><tr height="19" style="height: 19px;"><td colspan="7" height="19" style="text-align: center; word-break: break-all;" width="629">如4k@144Hz&nbsp; 10bit总带宽：3840x2160x3x10x144÷1024÷1024÷1024=33.37Gbps</td></tr></tbody></table><p style="white-space: normal;"><img src="https://img.alicdn.com/imgextra/i3/2206799812/O1CN01qldfkI2MLwoJlXBvi_!!2206799812.jpg"/></p><p style="white-space: normal;"><br/></p><p style="white-space: normal;"><span style="background-color: rgb(255, 192, 0); font-size: 18px;">买两台以上有优惠哦！推荐购买的还能得返利哦！</span></p><h3><span style="color: rgb(255, 0, 0);">优惠信息</span></h3><p>本站粉丝下单的客户，付款时请暗号联系客服：<span style="color: rgb(255, 0, 0);"><strong>masuit</strong></span>，购买1500元及以上的产品可获得<span style="color: rgb(255, 0, 0);"><strong>立减50</strong></span>的本站专属渠道优惠！优惠自联系客服起24h有效！</p><p>如果你是.NET程序猿，<span style="color: rgb(255, 0, 0);"><strong>2000元以下产品再优惠50元，2100元以上产品优惠100元</strong></span>！该项优惠将下单后进行<span style="color: rgb(255, 0, 0);"><strong>真实性考核</strong></span>，考核通过的将以现金返现的形式优惠！客服也是.程序猿，请不要尝试欺骗优惠。</p><p>如果你还是github活跃分子，直接成本价相送！(定义：单个.NET的开源项目至少50star，并且最近半年内有连续提交记录，不局限于github，gitlab和gitee亦可)</p><p><br/></p><p>注：本页信息由第三方广告方提供，内容仅供参考，具体参数和优惠活动以淘宝店的最新信息为准！</p>');
INSERT INTO "public"."Variables" VALUES (4, 'jichang', '<h3>不可用怎么办？</h3><p>1. 请首先参考官网的帮助文档，如果帮助文档不能解决，请检查以下几项是否正确或正常：</p><p>2. 有可能是你客户端的问题，电脑端推荐使用clash for Windows或v2rayN的最新版本，安卓端推荐使用clash for Android或v2rayNG的最新版本；</p><p>3. 也可能是你系统的问题，比如当前的系统时间不是准确的网络时间，建议先同步下系统时间；</p><p>4. 也可能是你网络本身的问题，比如一些二级网络运营商（墙中墙）：铁通、广电、教育网、科技网、长城宽带之类的非顶级网络运营商，这类二级网络很难突破限制，所以不可用；</p><p>5. 使用<a href="https://acl4ssr-sub.github.io/" target="_blank" textvalue="https://acl4ssr-sub.github.io/">https://acl4ssr-sub.github.io/</a>转换订阅后尝试是否可以正常使用。</p><p>6. 以上都尝试过，实在不可用的话，你可以24h内发起退款申请的，一般机场新注册用户都是有1天的试用套餐赠送，你可以试用看看适不适合你再决定需不需要购买正式套餐；</p><p>7. 如果已经购买了套餐发现不可用，可以在24小时内找机场主或者官网提工单申请退款，一般机场都会给你处理退款的。</p><h4>您当前的网络信息：</h4><p><iframe src="https://ip.skk.moe/simple" style="width: 100%; border: 0"></iframe></p><h3>一点小建议</h3><p>为保障可用性，建议购买两家或者多家不同的机场搭配使用，一家机场作为主力使用，一家低端机场作为备用。</p><p>机场这种服务，都是一分钱一分体验的，贵的肯定比便宜的好用稳定，应该根据自己的实际使用情况选择对应的适合自己的套餐。</p><p style="text-align: center;"><img src="/static/images/2022/04/29/%E4%BC%81%E4%B8%9A%E5%BE%AE%E4%BF%A1%E6%88%AA%E5%9B%BE_16512094119870_132321.png" alt="【平价】畅游云，高性价比的v2ray全球网络加速服务，不限带宽，解锁流媒体，低至9.9元/100GB"/></p>');
INSERT INTO "public"."Variables" VALUES (1, 'baidupan', '<p style="text-align: left;"><strong><span style="font-size: 20px; color: rgb(255, 0, 0);">请仔细阅读以下内容，这将有助于你获取本页中的资源！</span></strong></p><p>请务必使用<span style="color: rgb(255, 0, 0);">官方最新版</span>的手机端<span style="color: rgb(255, 0, 0);">百度网盘app</span>扫二维码即可进群，若无法扫描二维码，可尝试手动输入二维码上面的<span style="color: rgb(255, 0, 0);">群号</span>添加。<br style="text-align: left;"/></p><p style="text-align: left;">进群后资料自取，因为每个群只能容纳200人，建议<span style="color: rgb(255, 0, 0);"><strong>找到自己想要的资料后转存到自己的网盘上，然后退群为其他有需要的伙伴腾出位置</strong></span>，将来再有需要时可随时重新加群取资料，请尽量把名额留给其他更有需要的人。若群满长期没有退群的，那么满群的将会在一段时间后进行<strong><span style="color: rgb(255, 0, 0);">废弃处理</span></strong>。</p><p style="text-align: left;">注意：正常情况下群内会有以下两个文件夹，如果群里<span style="color: rgb(255, 0, 0);">有丢失资源，请在评论区反馈</span>，请不要尝试在百度网盘里私信，任何私信一律不回复和处理！</p><p style="text-align:center"><img src="https://fastly.jsdelivr.net/gh/ldqk/imgbed@master/2019/12/24/sc6q2ptgegow.png"/></p><p style="text-align: left;"><strong><span style="color: rgb(255, 0, 0);">百度网盘群只作为编程类学习资源的分享用途，请尽量不要在群里聊天，有其他诉求可通过页脚的联系方式私信站长，请合理使用群资源，因网盘每个群名额有限，请有真实需要的才加，感谢大家的配合和理解！</span></strong></p><p style="text-align: left;">如果你已经仔细阅读上述内容，请&nbsp;<a href="https://s2.loli.net/2022/05/25/fPliv7yXOTwnFLS.png" target="_blank" textvalue="点击这里">点击这里</a>&nbsp;获取百度网盘群二维码。如果二维码无法添加，请在评论区反馈并附上截图。</p><p style="text-align: left;"><strong><span style="font-size: 20px;">特别提醒：公开群，任何人都能加的，请不要相信群里任何的出售课程以及其他的小广告！由于网盘特殊，资源大多数是搬运来的，没法一一下载验证，若你发现资源存在加密的情况，请在评论区反馈，谢谢！</span></strong></p><p><span style="color: rgb(255, 0, 0);">最后，求有能力将上面的资源搬运到OneDrive或者GoogleDrive并分享出来！</span></p>');

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."AdvertisementClickRecord_Id_seq"
OWNED BY "public"."AdvertisementClickRecord"."Id";
SELECT setval('"public"."AdvertisementClickRecord_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."AdvertisementClickRecord_Id_seq1"
OWNED BY "public"."AdvertisementClickRecord"."Id";
SELECT setval('"public"."AdvertisementClickRecord_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Advertisement_Id_seq"
OWNED BY "public"."Advertisement"."Id";
SELECT setval('"public"."Advertisement_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Advertisement_Id_seq1"
OWNED BY "public"."Advertisement"."Id";
SELECT setval('"public"."Advertisement_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Category_Id_seq"
OWNED BY "public"."Category"."Id";
SELECT setval('"public"."Category_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Category_Id_seq1"
OWNED BY "public"."Category"."Id";
SELECT setval('"public"."Category_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Comment_Id_seq"
OWNED BY "public"."Comment"."Id";
SELECT setval('"public"."Comment_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Comment_Id_seq1"
OWNED BY "public"."Comment"."Id";
SELECT setval('"public"."Comment_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Donate_Id_seq"
OWNED BY "public"."Donate"."Id";
SELECT setval('"public"."Donate_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Donate_Id_seq1"
OWNED BY "public"."Donate"."Id";
SELECT setval('"public"."Donate_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."FastShare_Id_seq"
OWNED BY "public"."FastShare"."Id";
SELECT setval('"public"."FastShare_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."FastShare_Id_seq1"
OWNED BY "public"."FastShare"."Id";
SELECT setval('"public"."FastShare_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."InternalMessage_Id_seq"
OWNED BY "public"."InternalMessage"."Id";
SELECT setval('"public"."InternalMessage_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."InternalMessage_Id_seq1"
OWNED BY "public"."InternalMessage"."Id";
SELECT setval('"public"."InternalMessage_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."LeaveMessage_Id_seq"
OWNED BY "public"."LeaveMessage"."Id";
SELECT setval('"public"."LeaveMessage_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."LeaveMessage_Id_seq1"
OWNED BY "public"."LeaveMessage"."Id";
SELECT setval('"public"."LeaveMessage_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."LinkLoopback_Id_seq"
OWNED BY "public"."LinkLoopback"."Id";
SELECT setval('"public"."LinkLoopback_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."LinkLoopback_Id_seq1"
OWNED BY "public"."LinkLoopback"."Id";
SELECT setval('"public"."LinkLoopback_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Links_Id_seq"
OWNED BY "public"."Links"."Id";
SELECT setval('"public"."Links_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Links_Id_seq1"
OWNED BY "public"."Links"."Id";
SELECT setval('"public"."Links_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."LoginRecord_Id_seq"
OWNED BY "public"."LoginRecord"."Id";
SELECT setval('"public"."LoginRecord_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."LoginRecord_Id_seq1"
OWNED BY "public"."LoginRecord"."Id";
SELECT setval('"public"."LoginRecord_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Menu_Id_seq"
OWNED BY "public"."Menu"."Id";
SELECT setval('"public"."Menu_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Menu_Id_seq1"
OWNED BY "public"."Menu"."Id";
SELECT setval('"public"."Menu_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Misc_Id_seq"
OWNED BY "public"."Misc"."Id";
SELECT setval('"public"."Misc_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Misc_Id_seq1"
OWNED BY "public"."Misc"."Id";
SELECT setval('"public"."Misc_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Notice_Id_seq"
OWNED BY "public"."Notice"."Id";
SELECT setval('"public"."Notice_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Notice_Id_seq1"
OWNED BY "public"."Notice"."Id";
SELECT setval('"public"."Notice_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."PostHistoryVersion_Id_seq"
OWNED BY "public"."PostHistoryVersion"."Id";
SELECT setval('"public"."PostHistoryVersion_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."PostHistoryVersion_Id_seq1"
OWNED BY "public"."PostHistoryVersion"."Id";
SELECT setval('"public"."PostHistoryVersion_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."PostMergeRequest_Id_seq"
OWNED BY "public"."PostMergeRequest"."Id";
SELECT setval('"public"."PostMergeRequest_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."PostMergeRequest_Id_seq1"
OWNED BY "public"."PostMergeRequest"."Id";
SELECT setval('"public"."PostMergeRequest_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."PostTag_Id_seq"
OWNED BY "public"."PostTag"."Id";
SELECT setval('"public"."PostTag_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."PostVisitRecordStats_Id_seq"
OWNED BY "public"."PostVisitRecordStats"."Id";
SELECT setval('"public"."PostVisitRecordStats_Id_seq"', 73000, true);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."PostVisitRecordStats_Id_seq1"
OWNED BY "public"."PostVisitRecordStats"."Id";
SELECT setval('"public"."PostVisitRecordStats_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."PostVisitRecord_Id_seq"
OWNED BY "public"."PostVisitRecord"."Id";
SELECT setval('"public"."PostVisitRecord_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."PostVisitRecord_Id_seq1"
OWNED BY "public"."PostVisitRecord"."Id";
SELECT setval('"public"."PostVisitRecord_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Post_Id_seq"
OWNED BY "public"."Post"."Id";
SELECT setval('"public"."Post_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Post_Id_seq1"
OWNED BY "public"."Post"."Id";
SELECT setval('"public"."Post_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."SearchDetails_Id_seq"
OWNED BY "public"."SearchDetails"."Id";
SELECT setval('"public"."SearchDetails_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."SearchDetails_Id_seq1"
OWNED BY "public"."SearchDetails"."Id";
SELECT setval('"public"."SearchDetails_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Seminar_Id_seq"
OWNED BY "public"."Seminar"."Id";
SELECT setval('"public"."Seminar_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Seminar_Id_seq1"
OWNED BY "public"."Seminar"."Id";
SELECT setval('"public"."Seminar_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."SystemSetting_Id_seq"
OWNED BY "public"."SystemSetting"."Id";
SELECT setval('"public"."SystemSetting_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."SystemSetting_Id_seq1"
OWNED BY "public"."SystemSetting"."Id";
SELECT setval('"public"."SystemSetting_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."UserInfo_Id_seq"
OWNED BY "public"."UserInfo"."Id";
SELECT setval('"public"."UserInfo_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."UserInfo_Id_seq1"
OWNED BY "public"."UserInfo"."Id";
SELECT setval('"public"."UserInfo_Id_seq1"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Variables_Id_seq"
OWNED BY "public"."Variables"."Id";
SELECT setval('"public"."Variables_Id_seq"', 1, false);

-- ----------------------------
-- Alter sequences owned by
-- ----------------------------
ALTER SEQUENCE "public"."Variables_Id_seq1"
OWNED BY "public"."Variables"."Id";
SELECT setval('"public"."Variables_Id_seq1"', 1, false);

-- ----------------------------
-- Auto increment value for Advertisement
-- ----------------------------
SELECT setval('"public"."Advertisement_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table Advertisement
-- ----------------------------
CREATE INDEX "Price" ON "public"."Advertisement" USING btree (
  "Price" "pg_catalog"."numeric_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table Advertisement
-- ----------------------------
ALTER TABLE "public"."Advertisement" ADD CONSTRAINT "PK_Advertisement" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for AdvertisementClickRecord
-- ----------------------------
SELECT setval('"public"."AdvertisementClickRecord_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table AdvertisementClickRecord
-- ----------------------------
CREATE INDEX "AdvertisementId" ON "public"."AdvertisementClickRecord" USING btree (
  "AdvertisementId" "pg_catalog"."int4_ops" ASC NULLS LAST
);
CREATE INDEX "Time" ON "public"."AdvertisementClickRecord" USING btree (
  "Time" "pg_catalog"."timestamptz_ops" DESC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table AdvertisementClickRecord
-- ----------------------------
ALTER TABLE "public"."AdvertisementClickRecord" ADD CONSTRAINT "PK_AdvertisementClickRecord" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for Category
-- ----------------------------
SELECT setval('"public"."Category_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table Category
-- ----------------------------
CREATE INDEX "ParentId" ON "public"."Category" USING btree (
  "ParentId" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table Category
-- ----------------------------
ALTER TABLE "public"."Category" ADD CONSTRAINT "PK_Category" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for Comment
-- ----------------------------
SELECT setval('"public"."Comment_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table Comment
-- ----------------------------
CREATE INDEX "IX_Comment_PostId" ON "public"."Comment" USING btree (
  "PostId" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table Comment
-- ----------------------------
ALTER TABLE "public"."Comment" ADD CONSTRAINT "PK_Comment" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for Donate
-- ----------------------------
SELECT setval('"public"."Donate_Id_seq1"', 1, false);

-- ----------------------------
-- Primary Key structure for table Donate
-- ----------------------------
ALTER TABLE "public"."Donate" ADD CONSTRAINT "PK_Donate" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for FastShare
-- ----------------------------
SELECT setval('"public"."FastShare_Id_seq1"', 1, false);

-- ----------------------------
-- Primary Key structure for table FastShare
-- ----------------------------
ALTER TABLE "public"."FastShare" ADD CONSTRAINT "PK_FastShare" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for InternalMessage
-- ----------------------------
SELECT setval('"public"."InternalMessage_Id_seq1"', 1, false);

-- ----------------------------
-- Primary Key structure for table InternalMessage
-- ----------------------------
ALTER TABLE "public"."InternalMessage" ADD CONSTRAINT "PK_InternalMessage" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for LeaveMessage
-- ----------------------------
SELECT setval('"public"."LeaveMessage_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table LeaveMessage
-- ----------------------------
CREATE INDEX "IX_Date" ON "public"."LeaveMessage" USING btree (
  "PostDate" "pg_catalog"."timestamptz_ops" DESC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table LeaveMessage
-- ----------------------------
ALTER TABLE "public"."LeaveMessage" ADD CONSTRAINT "PK_LeaveMessage" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for LinkLoopback
-- ----------------------------
SELECT setval('"public"."LinkLoopback_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table LinkLoopback
-- ----------------------------
CREATE INDEX "LinkId" ON "public"."LinkLoopback" USING btree (
  "LinkId" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table LinkLoopback
-- ----------------------------
ALTER TABLE "public"."LinkLoopback" ADD CONSTRAINT "PK_LinkLoopback" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for Links
-- ----------------------------
SELECT setval('"public"."Links_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table Links
-- ----------------------------
CREATE INDEX "Recommend" ON "public"."Links" USING btree (
  "Recommend" "pg_catalog"."bool_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table Links
-- ----------------------------
ALTER TABLE "public"."Links" ADD CONSTRAINT "PK_Links" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for LoginRecord
-- ----------------------------
SELECT setval('"public"."LoginRecord_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table LoginRecord
-- ----------------------------
CREATE INDEX "IX_LoginRecord_UserInfoId" ON "public"."LoginRecord" USING btree (
  "UserInfoId" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table LoginRecord
-- ----------------------------
ALTER TABLE "public"."LoginRecord" ADD CONSTRAINT "PK_LoginRecord" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for Menu
-- ----------------------------
SELECT setval('"public"."Menu_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table Menu
-- ----------------------------
CREATE INDEX "Menu_ParentId_idx" ON "public"."Menu" USING btree (
  "ParentId" "pg_catalog"."int4_ops" ASC NULLS FIRST
);
CREATE INDEX "Sort" ON "public"."Menu" USING btree (
  "Sort" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table Menu
-- ----------------------------
ALTER TABLE "public"."Menu" ADD CONSTRAINT "PK_Menu" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for Misc
-- ----------------------------
SELECT setval('"public"."Misc_Id_seq1"', 1, false);

-- ----------------------------
-- Primary Key structure for table Misc
-- ----------------------------
ALTER TABLE "public"."Misc" ADD CONSTRAINT "PK_Misc" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for Notice
-- ----------------------------
SELECT setval('"public"."Notice_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table Notice
-- ----------------------------
CREATE INDEX "ModifyDate" ON "public"."Notice" USING btree (
  "ModifyDate" "pg_catalog"."timestamptz_ops" DESC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table Notice
-- ----------------------------
ALTER TABLE "public"."Notice" ADD CONSTRAINT "PK_Notice" PRIMARY KEY ("Id");

-- ----------------------------
-- Primary Key structure for table PerformanceCounter
-- ----------------------------
ALTER TABLE "public"."PerformanceCounter" ADD CONSTRAINT "PK_PerformanceCounter" PRIMARY KEY ("Time");

-- ----------------------------
-- Auto increment value for Post
-- ----------------------------
SELECT setval('"public"."Post_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table Post
-- ----------------------------
CREATE INDEX "AverageViewCount" ON "public"."Post" USING btree (
  "AverageViewCount" "pg_catalog"."float8_ops" DESC NULLS LAST
);
CREATE INDEX "IX_Post_CategoryId" ON "public"."Post" USING btree (
  "CategoryId" "pg_catalog"."int4_ops" ASC NULLS LAST
);
CREATE INDEX "Post_ModifyDate_idx" ON "public"."Post" USING btree (
  "ModifyDate" "pg_catalog"."timestamptz_ops" DESC NULLS FIRST
);
CREATE INDEX "TotalViewCount" ON "public"."Post" USING btree (
  "TotalViewCount" "pg_catalog"."int4_ops" DESC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table Post
-- ----------------------------
ALTER TABLE "public"."Post" ADD CONSTRAINT "PK_Post" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for PostHistoryVersion
-- ----------------------------
SELECT setval('"public"."PostHistoryVersion_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table PostHistoryVersion
-- ----------------------------
CREATE INDEX "IX_PostHistoryVersion_CategoryId" ON "public"."PostHistoryVersion" USING btree (
  "CategoryId" "pg_catalog"."int4_ops" ASC NULLS LAST
);
CREATE INDEX "IX_PostHistoryVersion_PostId" ON "public"."PostHistoryVersion" USING btree (
  "PostId" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table PostHistoryVersion
-- ----------------------------
ALTER TABLE "public"."PostHistoryVersion" ADD CONSTRAINT "PK_PostHistoryVersion" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for PostMergeRequest
-- ----------------------------
SELECT setval('"public"."PostMergeRequest_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table PostMergeRequest
-- ----------------------------
CREATE INDEX "PostId" ON "public"."PostMergeRequest" USING btree (
  "PostId" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table PostMergeRequest
-- ----------------------------
ALTER TABLE "public"."PostMergeRequest" ADD CONSTRAINT "PK_PostMergeRequest" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for PostTag
-- ----------------------------
SELECT setval('"public"."PostTag_Id_seq"', 1, false);

-- ----------------------------
-- Indexes structure for table PostTag
-- ----------------------------
CREATE INDEX "PostTag_Count_idx" ON "public"."PostTag" USING btree (
  "Count" "pg_catalog"."int4_ops" DESC NULLS LAST
);
CREATE UNIQUE INDEX "PostTag_Name_idx" ON "public"."PostTag" USING btree (
  "Name" COLLATE "pg_catalog"."default" "pg_catalog"."text_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table PostTag
-- ----------------------------
ALTER TABLE "public"."PostTag" ADD CONSTRAINT "PostTag_pkey" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for PostVisitRecord
-- ----------------------------
SELECT setval('"public"."PostVisitRecord_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table PostVisitRecord
-- ----------------------------
CREATE INDEX "PostVisitRecord_PostId_idx" ON "public"."PostVisitRecord" USING btree (
  "PostId" "pg_catalog"."int4_ops" ASC NULLS FIRST
);
CREATE INDEX "PostVisitRecord_Time_idx" ON "public"."PostVisitRecord" USING btree (
  "Time" "pg_catalog"."timestamptz_ops" DESC NULLS FIRST
);

-- ----------------------------
-- Primary Key structure for table PostVisitRecord
-- ----------------------------
ALTER TABLE "public"."PostVisitRecord" ADD CONSTRAINT "PK_PostVisitRecord" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for PostVisitRecordStats
-- ----------------------------
SELECT setval('"public"."PostVisitRecordStats_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table PostVisitRecordStats
-- ----------------------------
CREATE INDEX "IX_PostVisitRecordStats_PostId" ON "public"."PostVisitRecordStats" USING btree (
  "PostId" "pg_catalog"."int4_ops" ASC NULLS LAST
);
CREATE INDEX "PostVisitRecordStats_Date_idx" ON "public"."PostVisitRecordStats" USING btree (
  "Date" "pg_catalog"."timestamp_ops" DESC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table PostVisitRecordStats
-- ----------------------------
ALTER TABLE "public"."PostVisitRecordStats" ADD CONSTRAINT "PostVisitRecordStats_pkey" PRIMARY KEY ("Id");

-- ----------------------------
-- Indexes structure for table RequestLogDetail
-- ----------------------------
CREATE INDEX "RequestLogDetail_Time_idx" ON "public"."RequestLogDetail" USING btree (
  "Time" "pg_catalog"."timestamp_ops" DESC NULLS FIRST
);

-- ----------------------------
-- Primary Key structure for table RequestLogDetail
-- ----------------------------
ALTER TABLE "public"."RequestLogDetail" ADD CONSTRAINT "RequestLogDetail_pkey" PRIMARY KEY ("Id", "Time");

-- ----------------------------
-- Auto increment value for SearchDetails
-- ----------------------------
SELECT setval('"public"."SearchDetails_Id_seq1"', 1, false);

-- ----------------------------
-- Indexes structure for table SearchDetails
-- ----------------------------
CREATE INDEX "SearchTime" ON "public"."SearchDetails" USING btree (
  "SearchTime" "pg_catalog"."timestamptz_ops" DESC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table SearchDetails
-- ----------------------------
ALTER TABLE "public"."SearchDetails" ADD CONSTRAINT "PK_SearchDetails" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for Seminar
-- ----------------------------
SELECT setval('"public"."Seminar_Id_seq1"', 1, false);

-- ----------------------------
-- Primary Key structure for table Seminar
-- ----------------------------
ALTER TABLE "public"."Seminar" ADD CONSTRAINT "PK_Seminar" PRIMARY KEY ("Id");

-- ----------------------------
-- Indexes structure for table SeminarPost
-- ----------------------------
CREATE INDEX "IX_SeminarPost_Post_Id" ON "public"."SeminarPost" USING btree (
  "PostId" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table SeminarPost
-- ----------------------------
ALTER TABLE "public"."SeminarPost" ADD CONSTRAINT "PK_SeminarPost" PRIMARY KEY ("PostId", "SeminarId");

-- ----------------------------
-- Indexes structure for table SeminarPostHistoryVersion
-- ----------------------------
CREATE INDEX "IX_SeminarPostHistoryVersion_PostHistoryVersion_Id" ON "public"."SeminarPostHistoryVersion" USING btree (
  "PostHistoryVersionId" "pg_catalog"."int4_ops" ASC NULLS LAST
);

-- ----------------------------
-- Primary Key structure for table SeminarPostHistoryVersion
-- ----------------------------
ALTER TABLE "public"."SeminarPostHistoryVersion" ADD CONSTRAINT "PK_SeminarPostHistoryVersion" PRIMARY KEY ("PostHistoryVersionId", "SeminarId");

-- ----------------------------
-- Auto increment value for SystemSetting
-- ----------------------------
SELECT setval('"public"."SystemSetting_Id_seq1"', 1, false);

-- ----------------------------
-- Primary Key structure for table SystemSetting
-- ----------------------------
ALTER TABLE "public"."SystemSetting" ADD CONSTRAINT "PK_SystemSetting" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for UserInfo
-- ----------------------------
SELECT setval('"public"."UserInfo_Id_seq1"', 1, false);

-- ----------------------------
-- Primary Key structure for table UserInfo
-- ----------------------------
ALTER TABLE "public"."UserInfo" ADD CONSTRAINT "PK_UserInfo" PRIMARY KEY ("Id");

-- ----------------------------
-- Auto increment value for Variables
-- ----------------------------
SELECT setval('"public"."Variables_Id_seq1"', 1, false);

-- ----------------------------
-- Primary Key structure for table Variables
-- ----------------------------
ALTER TABLE "public"."Variables" ADD CONSTRAINT "PK_Variables" PRIMARY KEY ("Id");

-- ----------------------------
-- Foreign Keys structure for table AdvertisementClickRecord
-- ----------------------------
ALTER TABLE "public"."AdvertisementClickRecord" ADD CONSTRAINT "FK_AdvertisementClickRecord_Advertisement_AdvertisementId" FOREIGN KEY ("AdvertisementId") REFERENCES "public"."Advertisement" ("Id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table Category
-- ----------------------------
ALTER TABLE "public"."Category" ADD CONSTRAINT "FK_Category_Category_ParentId" FOREIGN KEY ("ParentId") REFERENCES "public"."Category" ("Id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table Comment
-- ----------------------------
ALTER TABLE "public"."Comment" ADD CONSTRAINT "Comment_PostId_fkey" FOREIGN KEY ("PostId") REFERENCES "public"."Post" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Keys structure for table LinkLoopback
-- ----------------------------
ALTER TABLE "public"."LinkLoopback" ADD CONSTRAINT "LinkLoopback_LinkId_fkey" FOREIGN KEY ("LinkId") REFERENCES "public"."Links" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Keys structure for table Menu
-- ----------------------------
ALTER TABLE "public"."Menu" ADD CONSTRAINT "Menu_ParentId_fkey" FOREIGN KEY ("ParentId") REFERENCES "public"."Menu" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Keys structure for table Post
-- ----------------------------
ALTER TABLE "public"."Post" ADD CONSTRAINT "Post_CategoryId_fkey" FOREIGN KEY ("CategoryId") REFERENCES "public"."Category" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Keys structure for table PostHistoryVersion
-- ----------------------------
ALTER TABLE "public"."PostHistoryVersion" ADD CONSTRAINT "PostHistoryVersion_CategoryId_fkey" FOREIGN KEY ("CategoryId") REFERENCES "public"."Category" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;
ALTER TABLE "public"."PostHistoryVersion" ADD CONSTRAINT "PostHistoryVersion_PostId_fkey" FOREIGN KEY ("PostId") REFERENCES "public"."Post" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Keys structure for table PostMergeRequest
-- ----------------------------
ALTER TABLE "public"."PostMergeRequest" ADD CONSTRAINT "PostMergeRequest_PostId_fkey" FOREIGN KEY ("PostId") REFERENCES "public"."Post" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Keys structure for table PostVisitRecord
-- ----------------------------
ALTER TABLE "public"."PostVisitRecord" ADD CONSTRAINT "PostVisitRecord_PostId_fkey" FOREIGN KEY ("PostId") REFERENCES "public"."Post" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Keys structure for table PostVisitRecordStats
-- ----------------------------
ALTER TABLE "public"."PostVisitRecordStats" ADD CONSTRAINT "FK_PostVisitRecordStats_Post_PostId" FOREIGN KEY ("PostId") REFERENCES "public"."Post" ("Id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- ----------------------------
-- Foreign Keys structure for table SeminarPost
-- ----------------------------
ALTER TABLE "public"."SeminarPost" ADD CONSTRAINT "SeminarPost_PostId_fkey" FOREIGN KEY ("PostId") REFERENCES "public"."Post" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;
ALTER TABLE "public"."SeminarPost" ADD CONSTRAINT "SeminarPost_SeminarId_fkey" FOREIGN KEY ("SeminarId") REFERENCES "public"."Seminar" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;

-- ----------------------------
-- Foreign Keys structure for table SeminarPostHistoryVersion
-- ----------------------------
ALTER TABLE "public"."SeminarPostHistoryVersion" ADD CONSTRAINT "SeminarPostHistoryVersion_PostHistoryVersionId_fkey" FOREIGN KEY ("PostHistoryVersionId") REFERENCES "public"."PostHistoryVersion" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;
ALTER TABLE "public"."SeminarPostHistoryVersion" ADD CONSTRAINT "SeminarPostHistoryVersion_SeminarId_fkey" FOREIGN KEY ("SeminarId") REFERENCES "public"."Seminar" ("Id") ON DELETE CASCADE ON UPDATE RESTRICT;
